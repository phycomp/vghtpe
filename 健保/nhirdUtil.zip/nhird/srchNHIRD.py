def srchNhirdICD():
  from pandas import DataFrame
  from streamlit import empty as stEmpty, sidebar, info as stInfo, radio as stRadio, dataframe, slider as stSlider, write as stWrite, columns as stColumns, text_input#, dataframe as stDataframe#, number_input
  from dbUtil import runQuery
  #from streamlit.components.v1 import html, declare_component
  #tblNHIRD=('CD', 'DD')#, 'OO', 'DO')
  #nhirdTBL=sidebar.radio('', tblNHIRD, key='NHIRD')
  #stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between}</style>', unsafe_allow_html=True)
  opts = ['ICD9', 'ICD10', 2]

  plchldr = stEmpty()  # makes placeholder, can all a st func to fill
  plchldr.multiselect("Select column", opts, key="decimal")
  customOpt = text_input("Add opt")

  if customOpt.isdecimal():
      opts = sorted([int(x) for x in opts] + [int(customOpt)])
      srchClmns=plchldr.multiselect("Select opt", [str(x) + "nm" for x in opts], key="decimal") # update widget declared above
      cnt=0
      for clmn in srchClmns:
        cnt+=1
        text_input(clmn, clmn, key=srchClmn+cnt)
  elif customOpt: stError("Not a decimal value")
def srchPthlgyTxt():
  from pandas import DataFrame
  from streamlit import empty as stEmpty, sidebar, info as stInfo, radio as stRadio, dataframe, slider as stSlider, write as stWrite, columns as stColumns#, dataframe as stDataframe#, number_input
  from dbMnpl.strmltPGconn import runQuery
  tblBDC=("BDCRADMI", "BDCRCPAR", "BDCRITAS", "BDCRCCTA", "BDCRPHLM", "BDCRSPEI", "BDCRAFBS", "BDCRCPAV", "BDCRLAUT", "BDCRCIEV", "BDCREBUS", "BDCRPLRL", "BDCRSPII", "BDCRASCI", "BDCRCPLK", "BDCRLCTL", "BDCRCKUB", "BDCREKGG", "BDCRPRCD", "BDCRSPOT", "BDCRASPR", "BDCRCRBB", "BDCRLDCB", "BDCRCLDV", "BDCREUTA", "BDCRPSGN", "BDCRTBNA", "BDCRBCFS", "BDCRCRBL", "BDCRLNAS", "BDCRCLSV", "BDCRFBSC", "BDCRPSGY", "BDCRTEEC", "BDCRBDCRB", "BDCRCRBR", "BDCRLUNG", "BDCRCLTV", "BDCRFFDM", "BDCRRADI", "BDCRTPCY", "BDCRBFBR", "BDCRCRTV", "BDCRMDEC", "BDCRCNBA", "BDCRFUNG", "BDCRRDCB", "BDCRUGIP", "BDCRBRBR", "BDCRCSFC", "BDCRMPST", "BDCRCODR", "BDCRHEST", "BDCRSBIO", "BDCRURIN", "BDCRBRWA", "BDCRCXOB", "BDCROPER", "BDCRCOPA", "BDCRHLAG", "BDCRSGNA", "BDCRWAUT", "BDCRCADC", "BDCRCXOL", "BDCRPALO", "BDCRCOPO", "BDCRIMMU", "BDCRCAPB", "BDCRCXOR", "BDCRPASS", "BDCRSOAP", "BDCRCPAL", "BDCRIMPR", "BDCRCAPP", "BDCRCYTO", "BDCRPATH", "BDCRSONO", "BDCRCPAP", "BDCRINAL", "BDCRCAPV", "BDCRDBAL", "BDCRPFTC", "BDCRSPAL")
  #stWrite('<style>div.row-widget.stRadio>div{flex-direction:row}</style>', unsafe_allow_html=True)
  stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between}</style>', unsafe_allow_html=True)
  bdcTbl=sidebar.radio('病理文本', tblBDC)
  leftPane, midPane, rightPane=stColumns([1,1,1])
  #noPthlgy=stSlider('文本數', 1, 100, step=10)
  noPthlgy=midPane.slider('文本數', 1, 100, step=10)
  #placeholder=stEmpty()
  pthlgyTxt=rightPane.text_input('',  'keyword<-->KEYWORD', 10)
  #icd碼=placeholder.text_input('', '250', 10)
  pthlgyCtgry=['全部文本', '個別文本']
  ctgryPthlgy=leftPane.radio('', pthlgyCtgry, key='病理文本')
  #ctgryPthlgy=stRadio('', pthlgyCtgry, key='病理文本')
  pthlgyRslt=[]
  if ctgryPthlgy==pthlgyCtgry[0]:
    for bdc in tblBDC:
      print('bdc= ', bdc)
      try:
        #qrySQL=f'''select chartid, sdate, mrn1, mrn2, outcome from "BDC_TECH"."{bdc}" where mrn1~*'{pthlgyTxt}' or mrn2~*'{pthlgyTxt}' limit {noPthlgy};'''
        qrySQL=f'''select chartid, mrn1, mrn2, sdate, outcome from "BDC_TECH"."{bdc}" where to_tsvector(outcome)@@to_tsquery('{pthlgyTxt}') limit {noPthlgy};'''
        print('qrySQL', qrySQL)
        pthlgyRslt+=runQuery(qrySQL, db='bdtest')
      except: pass
    print('lenPthlgyRslt= ', len(pthlgyRslt))
  else:
    qrySQL=f'''select chartid, mrn1, mrn2, sdate, outcome from "BDC_TECH"."{bdcTbl}" where outcome~'{pthlgyTxt}'limit {noPthlgy};'''
    pthlgyRslt=runQuery(qrySQL, db='bdtest')
  病理DF=DataFrame(data=pthlgyRslt)
  病理DF
  #dataframe()
#__all__=['srchPthlgyTxt', 'srchNhirdICD']
