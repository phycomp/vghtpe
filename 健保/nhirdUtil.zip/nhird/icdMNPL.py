def icdDset():
  from pandas import read_csv
  #import requests
  #import streamlit
  from streamlit import text_input, title as stTitle, markdown as stMarkdown, sidebar, cache_data as stCache, table as stTable, radio as stRadio, write as stWrite    #already_started_server,
  from streamlit import session_state, code as stCode, dataframe

  stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
  #pd.set_option('display.max_colwidth', -1)

  # Start the Jina server
  #if not hasattr(streamlit, 'already_started_server'):
  #    # Hack the fact that Python modules (like st) only load once to
  #    # keep track of whether this file already ran.
  #    already_started_server = True
  #    os.system('python app.py -t query_restful')

  # Create name to code mapper dict
  CLMN=['code', 'name']
  try:
    dfICD= session_state['dfICD']
  except:
    session_state['dfICD']=dfICD= read_csv('data/icd10.csv', sep="\\[SEP\\]", names=CLMN)
  clmn=stRadio('CLMN', CLMN)
  #codeMapper = {}
  #for index, row in dfICD.iterrows():
  #   codeMapper[row['name']] = row['code']
  with sidebar:
    dataframe(dfICD)
    #codeMapper
  #stCode([sd.codeMapper])
  stTitle('ICD10 Entity Linker')
  stMarkdown('Find the nearest ICD10 code for condition')
  #top_k = sidebar.slider('Max no. of results', 1, 20, 10)

  #def call(method, url, payload=None, headers={'Content-Type': 'application/json'}):
  #    return getattr(getattr(requests, method)(url, data=json.dumps(payload), headers=headers), 'json')()
  #dfICD = pd.read_csv('data/icd10.csv', sep="\[SEP\]", names=['code', 'name'])
  #sidebar.dfICD

  #@stCache    #(suppress_st_warning=True)
  #def rtrvRSLT(query, top_k=3):
  #    output = call('post', 'http://0.0.0.0:45678/api/search', payload={'top_k': top_k, 'mode': 'search',  'data': [f'text:{query}']})
  #    DataFrame(output)
  #    matches=dfICD.query(f'name.str.contains("{query}")==True')
  #    matches = dfICD[dfICD["name"] == query ] #& (df["Column2"== quantity)
  #
  #    #matches = output[['name']==query]    #['search']['docs'][0]['matches']
  #    return matches#{code_mapper[match['text'].strip()]:match['text'] for match in matches}


  query = text_input('Query', 'Enteropathic arthropathies, right hip')
  if clmn:
    #rslt = rtrvRSLT(query, top_k=top_k)
    #rslt[[clmn]==]
    matches=dfICD.query(f'{clmn}.str.contains("{query}")==True')
    dataframe(matches)
    #rslt[['code', 'name']]

  #DataFrame(result)
  #df = pd.DataFrame(list(result.items()), columns=['Code', 'Name'])
  #df.Name = df.Name.str.replace('\\n','')
  #df.index += 1
  # df = df.to_html(escape=False)
  #stMarkdown('**Relevant Codes**')
  # st.write(df, unsafe_allow_html=True)
  #stTable(df)
#icdDset()
