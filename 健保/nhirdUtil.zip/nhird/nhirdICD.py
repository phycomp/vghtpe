from dbMnpl.strmltPGconn import runQuery
from pandas import DataFrame
from plotly.graph_objs import Figure, Histogram, Bar, Layout
from streamlit.components.v1 import html as stHtml#, declare_components
from streamlit import dataframe, plotly_chart, columns as stColumn, help as stHelp, session_state, sidebar, write as stWrite, empty as stEmpty, error as stError, text_input
def srchICD():

    fig=Figure()
    ann=sidebar.radio('',  ('年度','年月'), key='ann') #AnnReport
    icd=sidebar.slider("ICD碼", 3, 5)
    qrySQL=f'''select left("ACODE_ICD9_1", {icd}), count("ACODE_ICD9_1") from "BDC_TECH"."tmpl2CD" group by 1 order by 2 desc limit 100;'''
    #topICD=['250', '401', '715', '414', 'E11', '402', '571', 'I11', 'I25', '600', '721', 'N18', '780', 'I10', '162', '710', '174', '585', '296', '290', '530', 'C50', '714', '427', '365', 'N40', 'E13', '434', '366', 'C34', '692', 'M19', '153', '155', '523', '272', '185', 'M47', 'M06', '729', 'F03', 'H40', '300', '477', '362', 'V42', '345', '627', '437', 'Z00', '564', 'B18', 'K73', '295', 'H25', '493', 'C22', '533', 'C61', 'C18', '151', 'E78', 'M15', 'K05', '496', '521', 'V72', '722', '242', 'V70', 'Z51', 'I49', '611', 'M32', '332', 'Z94', '428', 'I67', '193', '424', 'G40', '375', 'K21', '202', 'H35', 'J45', '786', '154', 'I48', 'K20', 'M79', '274', 'I66', '583', '599', 'G47', 'M35', 'K02', '346', '491']
      #print('annRslt:', annRslt)
    #for icd in topICD:
    #for line in qrySQL.split('\n'):
      #Icd, icdAmnt=line.split('|')
      ##rdInfo=stRadio('', [Icd])
      ##annRslt.append([rdInfo, int(icdAmnt)])
      #print('stRadio=', rdInfo)
    #where left("ACODE_ICD9_1", {icd})='{icd}' 
    import matplotlib
    from matplotlib.pyplot import gcf
    from plotly.offline import plot as offlinePlot
    #annRslt=rtrvICD(icdCODE)
    annRslt=runQuery(qrySQL, db='bdtest')
    annDF=DataFrame(annRslt)
    topICD=annDF[0]
    trace=Bar(x=annDF[0], y=annDF[1], name='ICD碼')
    fig.add_trace(trace)
    plotly_chart(fig)
    def rtrvICD():    #icd, codeICD
      codeICD=session_state['icdCODE']
      icd=session_state['icd']
      print('real codeICD, icd', codeICD, icd)
      if ann=='年度': qrySQL='''left("FEE_YM", 4)'''
      else: qrySQL='''"FEE_YM"'''
      qrySQL=f'''select {qrySQL}, count(*) from "BDC_TECH"."tmpl2CD" where left("ACODE_ICD9_1", {icd})='{codeICD}' group by 1 ;'''
      FIG=Figure()
      annRslt=runQuery(qrySQL, db='bdtest')
      annDF=DataFrame(annRslt)
      trace=Bar(x=annDF[0], y=annDF[1], name='ICD碼')
      FIG.add_trace(trace)
      #return runQuery(qrySQL, db='bdtest')
    左, 右=stColumn((1,3))
    with 左:
      session_state['icd']=icd
      icdCODE=leftClmn.radio('', topICD, key='icdCODE', on_change=rtrvICD)#, args=[icd, icdCODE])
    with 右:
      plotly_chart(FIG, title=icdCODE)
    #with leftClmn.radio('', topICD):
    #session_state['topICD']=topICD
    #topICD=session_state['topICD']
    #if not hasattr(session_state, 'icdCODE'): session_state['icdCODE']=topICD[0]
    #else: session_state['icdCODE']=icdCODE
    #if icdCODE:
    #  FIG=Figure()
    #  annRslt=rtrvICD(icd, icdCODE)
    #  annDF=DataFrame(annRslt)
    #  trace=Bar(x=annDF[0], y=annDF[1], name='ICD碼')
    #  FIG.add_trace(trace)
    #  rghtClmn.plotly_chart(FIG, title=icdCODE)
__all__=['srchICD']
