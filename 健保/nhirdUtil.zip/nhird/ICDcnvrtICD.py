def ICD9cnvrtICD10():
  from streamlit import dataframe as stDataframe, write as stWrite, text_input#, number_input empty as stEmpty, 
  from streamlit import session_state
  from re import search
  from pandas import DataFrame
  from dbUtil import runQuery
  #'ICD9轉ICD10'
  #number_input('number_input', 10, 100, 15)
  #placeholder=stEmpty() #placeholder.text('ICD碼')
  icd碼=text_input('ICD9碼', 250, 10, 'some', label_visibility="collapsed")   #label_visibility='collapsed' label='ICD9碼', visible
  #轉碼=stRadio('', ['轉'])
  #icd10=text_input('', 'ICD10', 40)
  stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between}</style>', unsafe_allow_html=True)
  if icd碼:
    N = r"\d{3}\.?\d{0,2}"
    E = r"E\d{3}\.?\d?"
    V = r"V\d{2}\.?\d{0,2}"
    icd9Regex = "|".join([N, E, V])
    ICD10Regexp=r'[A-TV-Z][0-9][0-9AB]\.?[0-9A-TV-Z]{0,4}'
    isICD9=isICD10=None
    if search(ICD10Regexp, icd碼): isICD10=True # else True
    if search(icd9Regex, icd碼): isICD9=True # else True
    if isICD9:
      qrySQL=f'''select "ICD-10-CM", "ICD-10-CM英文名稱", "ICD-10-CM中文名稱" from "ICD" where "ICD-9-CM"~'{icd碼}';'''
    elif isICD10:
      qrySQL=f'''select "ICD-9-CM", "ICD-9-CM英文名稱", "ICD-9-CM中文名稱" from "ICD" where "ICD-10-CM"~'{icd碼}';'''
    else:
      qrySQL=f'''select * from "ICD" where "ICD-9-CM英文名稱"~'{icd碼}' or "ICD-9-CM中文名稱"~'{icd碼}' or "ICD-10-CM英文名稱"~'{icd碼}' or "ICD-10-CM中文名稱"~'{icd碼}';'''
    #print(qrySQL)
    #print('annRslt', annRslt)
    try:
      annDF=session_state[icd碼]
    except:
      annRslt=runQuery(qrySQL, db='icd')
      session_state[icd碼]=annDF=annDF=DataFrame(annRslt)
    #annDF
    stDataframe(annDF) #annDF.values
__all__=['ICD9cnvrtICD10']
