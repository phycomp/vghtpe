def srchLBDT():
  from pandas import DataFrame
  from streamlit import empty as stEmpty, sidebar, info as stInfo, radio as stRadio, dataframe, slider as stSlider, write as stWrite, columns as stColumns#, dataframe as stDataframe#, number_input
  from dbMnpl.strmltPGconn import runQuery
  from plotly.graph_objs import Figure, Histogram, Bar, Layout
  from streamlit import plotly_chart
  tblSYMs=("RTRISKF", "RTTROP", "RTCRP", "RTWBC", "RTNH3", "RTMCH", "RTALKP", "RTPI", "RTBILIT", "RTLDH", "RTBAND", "RTHGB", "RTRBC", "RTDB", "RTEOS", "RTCREA", "RTMCV", "RTHDLC", "RTUA", "RTLAC", "RTBASO", "RTPLATE", "RTIRON", "RTSEG", "RTNA", "RTCK", "RTRDW", "RTUROBI", "RTLDLC", "RTCL", "RTAST", "RTLYM", "RTTG", "RTTP", "RTCA", "RTBUN", "RTGGT", "RTALT", "RTALB", "RTAPOA1", "RTGRAVIT", "RTGLU", "RTK", "RTHCT", "RTCKMB", "RTMONO", "RTWBCPUS", "RTALC", "RTAMYL", "RTMCHC", "RTLIPA", "RTCHOL", "RTCO2", "RTPH")
  stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between}</style>', unsafe_allow_html=True)
  sym=sidebar.radio('SYMBLs', tblSYMs)
  ann=sidebar.text_input('startDate', 2010)
  Ann=sidebar.text_input('endDate', 2020)
  if sym and ann and Ann:
    print('sym, ann, Ann', sym, ann, Ann)
    qrySQL=f'''select "RSRTSYM","RSPFKEY",string_agg("cmbValue", '|' order by "RSDATE") from isc8381."ageGndrSymblPfkeyDemo" where "RSRTSYM"='{sym}' and left("RSDATE", 4)>'{ann}' and left("RSDATE", 4)<'{Ann}' group by 1,2 limit 1;'''
    #and "PSEX"='1' and "AGE">=10 and "AGE"<20
    print('qrySQL', qrySQL)
    lbdtRslt=runQuery(qrySQL, db='postgres')
    if lbdtRslt:
      print('lenlbdtRslt', len(lbdtRslt))
      sym, pfkey, rsvalue=lbdtRslt[0]    #
      #print('rsvalue', rsvalue)
      fig=Figure()
      from re import findall
      lwr, mdl, ppr=[], [], []
      for nrml, rsvl in findall('([\W|\w])\$(\d*?\.?\d*?)[|#]', rsvalue):   #findall('\w\$\d\+\.?(\d\+)?', rsvalue):
        if nrml=='L': lwr.append(rsvl)
        elif nrml=='H': ppr.append(rsvl)
        else: mdl.append(rsvl)
        #print(nrml, rsvl, end=', ')
      lwrTrace=Bar(x=lwr, name='LWR')
      pprTrace=Bar(x=ppr, name='UPPER')
      mdlTrace=Bar(x=mdl, name='MDL')
      #traces=Histogram()
      fig.add_trace(lwrTrace)
      fig.add_trace(pprTrace)
      fig.add_trace(mdlTrace)
      plotly_chart(fig)
    #dataframe(DataFrame(data=lbdtRslt))
  """
  if ctgryPthlgy==pthlgyCtgry[0]:
      #qrySQL=f'''select chartid, sdate, outcome from "BDC_TECH"."{bdc}" where to_tsvector(outcome)@@to_tsquery('{pthlgyTxt}') limit {noPthlgy};'''
      print('lenPthlgyRslt= ', len(pthlgyRslt))
  else:
    qrySQL=f'''select chartid, sdate, outcome from "BDC_TECH"."{bdcTbl}" where outcome~'{pthlgyTxt}'limit {noPthlgy};'''
    pthlgyRslt=runQuery(qrySQL, db='bdtest')
  """
__all__=['srchLBDT']
