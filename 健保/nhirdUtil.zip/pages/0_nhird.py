from streamlit import sidebar, radio as stRadio, markdown as stMarkdown, container as stContainer, write as stWrite, text_input, session_state
from dbUtil import runQuery

def rtrvNHIRD(nhirdTBL, ann):
  rslt=[]
  for annl in range(1,5):
    qrySQL=f'select {qryDATE}, count(*), count(distinct "ID") from nhird."tmpl2{nhirdTBL}201{annl}" group by 1;'
  #qrySQL=f'select {qrySQL}, sum(num_of_visit), sum(num_of_people) from "COUNT_{nhirdTBL}" group by 1;'
    rslt+=runQuery(qrySQL, db='nhird')
  return rslt

def rtrvBDC(bdcTBL):
  if ann=='年度':
    qrySQL="left(sdate, 4)"
  else:
    qrySQL="sdate"
  qrySQL=f'select {qrySQL}, sum(n_report), sum(n_people) from "BDC_TECH"."{bdcTBL}" group by 1;'
  cntnr.write(bdcTBL) #BDC表格 bdcTBL)
  return runQuery(qrySQL, db='bdprod')
  #annDF=DataFrame(annRslt)
  #stHelp(annDF)
  #kmfExp.survival_function_

MENU, 表單=[], ['ICD', 'ICD9轉ICD10', '健保資料庫', '病理文本', 'dfICD', 'RTSYM', '全文檢索', '搜索健保資料庫']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #srch=text_input('搜尋', '')
  #vwrOpt=stRadio('MENU', MENU, key='MENU')
if menu==len(表單):
  pass
#elif menu==MENU[1]:
  tblName='sutra'
#elif menu==MENU[0]:
elif menu==MENU[-1]:
  from nhird.srchNHIRD import srchNhirdICD
  srchNhirdICD()
elif menu==MENU[-2]:
  from nhird.srchNHIRD import srchPthlgyTxt
  srchPthlgyTxt()
elif menu==MENU[-3]:
  from nhird.srchLBDT import srchLBDT
  srchLBDT()
elif menu==MENU[-4]:
  from nhird.icdMNPL import icdDset
  icdDset()
elif menu==MENU[3]:  #'病理文本'
  from pandas import DataFrame
  from plotly.graph_objs import Figure, Histogram, Bar, Layout
  from streamlit import plotly_chart
  tblBDC=("BDCCADMI", "BDCCCPAR", "BDCCITAS", "BDCCCCTA", "BDCCPHLM", "BDCCSPEI", "BDCCAFBS", "BDCCCPAV", "BDCCLAUT", "BDCCCIEV", "BDCCEBUS", "BDCCPLRL", "BDCCSPII", "BDCCASCI", "BDCCCPLK", "BDCCLCTL", "BDCCCKUB", "BDCCEKGG", "BDCCPRCD", "BDCCSPOT", "BDCCASPR", "BDCCCRBB", "BDCCLDCB", "BDCCCLDV", "BDCCEUTA", "BDCCPSGN", "BDCCTBNA", "BDCCBCFS", "BDCCCRBL", "BDCCLNAS", "BDCCCLSV", "BDCCFBSC", "BDCCPSGY", "BDCCTEEC", "BDCCBDCCB", "BDCCCRBR", "BDCCLUNG", "BDCCCLTV", "BDCCFFDM", "BDCCRADI", "BDCCTPCY", "BDCCBFBR", "BDCCCRTV", "BDCCMDEC", "BDCCCNBA", "BDCCFUNG", "BDCCRDCB", "BDCCUGIP", "BDCCBRBR", "BDCCCSFC", "BDCCMPST", "BDCCCODR", "BDCCHEST", "BDCCSBIO", "BDCCURIN", "BDCCBRWA", "BDCCCXOB", "BDCCOPER", "BDCCCOPA", "BDCCHLAG", "BDCCSGNA", "BDCCWAUT", "BDCCCADC", "BDCCCXOL", "BDCCPALO", "BDCCCOPO", "BDCCIMMU", "BDCCCAPB", "BDCCCXOR", "BDCCPASS", "BDCCSOAP", "BDCCCPAL", "BDCCIMPR", "BDCCCAPP", "BDCCCYTO", "BDCCPATH", "BDCCSONO", "BDCCCPAP", "BDCCINAL", "BDCCCAPV", "BDCCDBAL", "BDCCPFTC", "BDCCSPAL") #"BDCCDERS", "BDCCSMRY", 
  cntnr=stContainer()
  #stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between}</style>', unsafe_allow_html=True)
  with sidebar:
    ann=stRadio('',  ('年度','年月'), key='ann', horizontal=True, index=0) #AnnReport
    bdcTBL=stRadio('', tblBDC, key='病理文本', horizontal=True, index=0)
  fig=Figure()
  annRslt=rtrvBDC(bdcTBL)
  annDF=DataFrame(annRslt)
  trace=Bar(x=annDF[0], y=annDF[1], name='文本')
  Trace=Bar(x=annDF[0], y=annDF[2], name='歸戶')
  #traces=Histogram()
  fig.add_trace(trace)
  fig.add_trace(Trace)
  plotly_chart(fig)
elif menu==MENU[2]:  #'健保資料庫'
  from pandas import DataFrame
  from plotly.graph_objects import Figure, Layout, Bar, Line, Histogram#
  #from plotly.graph_objects import Scatter
  #from plotly.graph_objs.scatter import Line
  #from plotly.graph_objects.layout.shape import Line
  #from plotly.graph_objects.layout.shape import Line
  from streamlit import plotly_chart
  #import plotly.express as px
  from plotly.express import bar, line
  tblNHIRD=('CD', 'DD', 'OO', 'DO')
  #stWrite('<style>div.row-widget.stRadio>div{flex-direction:row}</style>', unsafe_allow_html=True)
  with sidebar:
    nhirdTBL=stRadio('', tblNHIRD, key='NHIRD', horizontal=True, index=0)
    ann=stRadio('',  ('年度','年月'), key='ann', horizontal=True, index=0) #AnnReport
  layout=Layout(xaxis={'type':'date'}) #14 days 'tick0': x[0], , 'dtick': 86400000.0 * 14, 'tickmode':'linear'
  fig=Figure(layout=layout)
  if ann:
    qryDATE='''left("FEE_YM", 4)''' if ann=='年度' else '''left("FEE_YM", 6)'''
    try:
      annDF=session_state[qryDATE]
    except:
      annRslt=rtrvNHIRD(nhirdTBL, ann)
      CLMN=['date', '總數', '歸戶']
      annDF=DataFrame(annRslt, columns=CLMN)    #, index=False
      session_state[qryDATE]=annDF
    annDF
    #trace=Bar(x=annDF['date'], y=annDF['總數'], name='總數')    #, mode="lines"
    #Trace=Bar(x=annDF['date'], y=annDF['歸戶'], name='歸戶')  #, layout=layout, mode="lines"
    #trace=Bar(y=annDF['歸戶'], x=annDF['date'], name='歸戶') #, y='歸戶',template='plotly_white'
    #Trace=Bar(y=annDF['總數'], x=annDF['date'], name='總數') #, y='歸戶',template='plotly_white' , x=annDF['date']Histogram
    #fig=bar(annDF, x="date", y="總數")  #, color='variable'
    fig=bar(annDF, x="date", y=['總數', '歸戶'])  #, color='variable'
    #fig.update_layout(xaxis=dict(tickformat="%Y%m"))
    #Trace=Histogram(annDF, x='date', y='總數'), #,template='plotly_white'
    #fig.add_trace(trace)
    #fig.add_trace(Trace)
    fig.update_layout(barmode='relative', xaxis=dict(tickformat="%Y%m"))    #
    #'stack', 'group', 'overlay', 'relative'
    #traces=Histogram()
    #px.line(x='date')
    #fig.add_shape(type="line", xref="x", yref="y", line=dict(color="LightSeaGreen", width=3))
    #fig = px.line(dfm, x="dates", y="value", color='variable')
    #fig.update_traces(xaxis='x', selector=dict(type='bar'))
    #trace=bar(annDF[['date', '總數']], x='date', y='總數')
    #Trace=bar(annDF[['date', '歸戶']], x='date', y='歸戶')
    #fig.update_layout(barmode='group') #bargap = 0.2, autosize=True,xaxis_range=[start_date, end_date]
    plotly_chart(fig)
elif menu==MENU[1]:  #'健保資料庫'
  from nhird.ICDcnvrtICD import ICD9cnvrtICD10
  ICD9cnvrtICD10()
elif menu==MENU[0]:  #'ICD'
  from nhird.srchNHIRD import srchNhirdICD
  srchNhirdICD()
#stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between}</style>', unsafe_allow_html=True)
#stWrite('<style>div[role="radiogroup"]>:first-child{display:none !important}</style>', unsafe_allow_html=True)
