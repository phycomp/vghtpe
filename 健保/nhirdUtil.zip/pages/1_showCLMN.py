from dbUtil import dbCLMN, runQuery
from stUtil import rndrCode
CLMN=dbCLMN(tblSchm='public', tblName='PBASINFO', db='pbas')
rndrCode(['CLMN', CLMN])
#def dbCLMN(tblSchm='public', tblName=None, db=None): #, mode=None
#qrySQL=f'select {qryDATE}, count(*), count(distinct "ID") from nhird."tmpl2{nhirdTBL}201{annl}" group by 1;'
#qrySQL=f'select {qrySQL}, sum(num_of_visit), sum(num_of_people) from "COUNT_{nhirdTBL}" group by 1;'
#rslt+=runQuery(qrySQL, db='nhird')
#nhird
#postgres

qrySQL="select column_name from information_schema.columns WHERE table_schema = 'postgres' AND table_name = 'PBASINFO';"
#qrySQL='select * from nhird."tmpl2CD" limit 1;'
rslt=runQuery(qrySQL, db='pbas')
rndrCode(['qrySQL', rslt])
