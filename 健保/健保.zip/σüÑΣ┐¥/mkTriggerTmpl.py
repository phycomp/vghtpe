#!/usr/bin/env python
from sys import argv
tmpl=open('triggerTmpl.sql').read()
FILES=['CD', 'OO', 'DO', 'DD']
iTer=argv[1]
tblTrigger='CREATE TRIGGER insertTBLtrigger BEFORE INSERT ON %s."%s" FOR EACH ROW EXECUTE PROCEDURE TBLinsertTrigger();'
for fname in FILES:
	fout=open('%sTrigger.sql'%fname, 'w')
	ouTbl='tmpl%s%s'%(iTer, fname)
	dataOut=tmpl.replace('fullTBL', ouTbl)
	dataOut=dataOut.replace('TBL', fname)
	fout.write(dataOut)
	print(tblTrigger.replace('ON %s."%s"', 'ON nhicd."%s"'%ouTbl).replace('TBL', fname))
