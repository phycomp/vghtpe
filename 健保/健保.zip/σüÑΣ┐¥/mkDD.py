create or replace function "mkNcrmntDD"(in "tblName" varchar default 'BILDRGSC', in "nhirdTbl" varchar default 'DD', in "dfltSchm" varchar default 'nhird', in "flshSchm" boolean default false) RETURNS void AS $nhird$
from plpy import cursor, execute, notice
from sys import exc_info
from re import search
#tblName=['BILDRGSN', 'BILDRGSC']
#annYear=[]
schm=dfltSchm if dfltSchm.islower() else '"%s"'%dfltSchm
notice(schm)
createSchema='create schema if not exists %s;'%schm	#drop schema if exists %s; 
notice(createSchema)
#execute(createSchema)

createDD = """CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(34) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ID" varchar(10) NULL, "ID_BIRTHDAY" varchar(8) NULL, "GAVE_KIND" varchar(1) NULL, "TRAC_EVEN" varchar(1) NULL, "CARD_SEQ_NO" varchar(4) NULL, "FUNC_TYPE" varchar(2) NULL, "IN_DATE" varchar(8) NULL, "OUT_DATE" varchar(8) NULL, "APPL_BEG_DATE" varchar(8) NULL, "APPL_END_DATE" varchar(8) NULL, "E_BED_DAY" numeric(8) NULL, "S_BED_DAY" numeric(8) NULL, "PRSN_ID" varchar(10) NULL, "DRG_CODE" varchar(5) NULL, "EXT_CODE_1" varchar(6) NULL, "EXT_CODE_2" varchar(6) NULL, "TRAN_CODE" varchar(1) NULL, "ICD9CM_CODE" varchar(8) NULL, "ICD9CM_CODE_1" varchar(8) NULL, "ICD9CM_CODE_2" varchar(8) NULL, "ICD9CM_CODE_3" varchar(8) NULL, "ICD9CM_CODE_4" varchar(8) NULL, "ICD_OP_CODE" varchar(8) NULL, "ICD_OP_CODE_1" varchar(8) NULL, "ICD_OP_CODE_2" varchar(8) NULL, "ICD_OP_CODE_3" varchar(8) NULL, "ICD_OP_CODE_4" varchar(8) NULL, "DIAG_AMT" numeric(8) NULL, "ROOM_AMT" numeric(8) NULL, "MEAL_AMT" numeric(8) NULL, "AMIN_AMT" numeric(8) NULL, "RADO_AMT" numeric(8) NULL, "THRP_AMT" numeric(8) NULL, "SGRY_AMT" numeric(8) NULL, "PHSC_AMT" numeric(8) NULL, "BLOD_AMT" numeric(8) NULL, "HD_AMT" numeric(8) NULL, "ANE_AMT" numeric(8) NULL, "METR_AMT" numeric(8) NULL, "DRUG_AMT" numeric(8) NULL, "DSVC_AMT" numeric(8) NULL, "NRTP_AMT" numeric(8) NULL, "INJT_AMT" numeric(8) NULL, "BABY_AMT" numeric(8) NULL, "CHARG_AMT" numeric(8) NULL, "MED_AMT" numeric(8) NULL, "PART_AMT" numeric(8) NULL, "APPL_AMT" numeric(8) NULL, "EB_APPL30_AMT" numeric(8) NULL, "EB_PART30_AMT" numeric(8) NULL, "EB_APPL60_AMT" numeric(8) NULL, "EB_PART60_AMT" numeric(8) NULL, "EB_APPL61_AMT" numeric(8) NULL, "EB_PART61_AMT" numeric(8) NULL, "SB_APPL30_AMT" numeric(8) NULL, "SB_PART30_AMT" numeric(8) NULL, "SB_APPL90_AMT" numeric(8) NULL, "SB_PART90_AMT" numeric(8) NULL, "SB_APPL180_AMT" numeric(8) NULL, "SB_PART180_AMT" numeric(8) NULL, "SB_APPL181_AMT" numeric(8) NULL, "SB_PART181_AMT" numeric(8) NULL, "PART_MARK" varchar(3) NULL, "ID_SEX" varchar(1) NULL, "EXM_RESULT_DRG_1" varchar(5) NULL, "EXM_RESULT_MDC_1" varchar(2) NULL, "TW_DRGS" varchar(5) NULL, "APPL_CAUSE_MARK" varchar(1) NULL, "TW_DRGS_SUIT_MARK" varchar(1) NULL, "PAT_SOURCE" varchar(1) NULL, "ORDER_NUM" numeric(8) NULL, "BABYBIRD" varchar(8) NULL, "TW_DRGS_PAY_TYPE" varchar(1) NULL, "CHILD_MARK" varchar(1) NULL, "ICD6" varchar(8) NULL, "ICD7" varchar(8) NULL, "ICD8" varchar(8) NULL, "ICD9" varchar(8) NULL, "ICD10" varchar(8) NULL, "ICD11" varchar(8) NULL, "ICD12" varchar(8) NULL, "ICD13" varchar(8) NULL, "ICD14" varchar(8) NULL, "ICD15" varchar(8) NULL, "ICD16" varchar(8) NULL, "ICD17" varchar(8) NULL, "ICD18" varchar(8) NULL, "ICD19" varchar(8) NULL, "ICD20" varchar(8) NULL, "OPD6" varchar(8) NULL, "OPD7" varchar(8) NULL, "OPD8" varchar(8) NULL, "OPD9" varchar(8) NULL, "OPD10" varchar(8) NULL, "OPD11" varchar(8) NULL, "OPD12" varchar(8) NULL, "OPD13" varchar(8) NULL, "OPD14" varchar(8) NULL, "OPD15" varchar(8) NULL, "OPD16" varchar(8) NULL, "OPD17" varchar(8) NULL, "OPD18" varchar(8) NULL, "OPD19" varchar(8) NULL, "OPD20" varchar(8) NULL, "FINKEY" varchar(4) NULL, "BHISTNO" varchar(10) NULL, "BPSECT" varchar(4) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "PRSN_UUID" varchar(36) NULL) PARTITION BY RANGE("FEE_YM");"""%(schm, nhirdTbl)	#DROP TABLE if exists %s."%s";
notice(createDD)
execute(createDD)

def insrtDD(schm, nhirdTbl, tblName):
	try:
		for idx in [tblName]:
			DDinsert="""insert into %s."%s" select "DISYYMM"::smallint+191100, "BRELAY", NULL, NULL, "BCASEFLG", "SEQNO", "BIDNO", "BIRTHDAY", "BSICK", "BCARACDT", "BNHISEQ", "NHISECT", "BREGDT", "TDISDATE", "COEBGN", "COEEND", "EDAYTOT", "LDAYTOT", "DOCIDNO", trim("BDRGCOD"), trim("ECOD1"), trim("ECOD2"), "BGO", trim("ICD1"), trim("ICD2"), trim("ICD3"), trim("ICD4"), trim("ICD5"), trim("OPD1"), trim("OPD2"), trim("OPD3"), trim("OPD4"), trim("OPD5"), "SUBDIAG", "SUBWARD", "SUBDIET", "SUBEXAM", "SUBXRAY", "SUBTRET", "SUBOPER", "SUBPHSY", "SUBBLOD", "SUBKIDN", "SUBANES", "SUBMATE", "SUBDRUG", "SUBDRGS", "SUBPSY", "SUBSHUT", "SUBINFT", NULL, "PATTOTAL", "SELTOTAL", "APPTOTAL", "E30PATOT", "E30SETOT", "E60PATOT", "E60SETOT", "EOTPATOT", "EOTSETOT", "L30PATOT", "L30SETOT", "L90PATOT", "L90SETOT", "L180PTOT", "L180STOT", "LOTPATOT", "LOTSETOT", "BNHSLFG1", NULL, NULL, NULL, trim("TWDRG"), "NFITDRG", NULL, "BGIN", "OESEQNO", trim("BABYBIRD"), trim("DRGTYP"), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "FINKEY", "BHISTNO", "BPSECT" from %s where "DISYYMM"~'\d{5}' and right("DISYYMM", 2)<='12';"""%(schm, nhirdTbl, idx)
			notice(DDinsert)
			execute(DDinsert)
	except:
		errmsg=exc_info()[1]
		notice('spidata', errmsg.spidata)	#errmsg.spidata-> 'spidata', 'sqlstate', 'with_traceback'
		excptMsg=errmsg.spidata[1]
		notice('excptMsg', excptMsg)	#errmsg.spidata-> 'spidata', 'sqlstate', 'with_traceback'
		ann=search('\d{4}', excptMsg).group(0)
		#annYear.append(ann)
		startVal, endVal='%s01'%ann, '%s13'%ann
		prttnTbl='CREATE TABLE if not exists %s."%s%s" PARTITION OF %s."%s" FOR VALUES FROM (%s) TO (%s);'%(schm, nhirdTbl, ann, schm, nhirdTbl, startVal, endVal)
		notice(prttnTbl)
		execute(prttnTbl)
		insrtDD(schm, nhirdTbl, tblName)
insrtDD(schm, nhirdTbl, tblName)

updateDD="""update %s."%s"set "OUT_DATE"=NULL where "OUT_DATE"='';
update %s."%s"set "OUT_DATE"="OUT_DATE"::integer+19110000 where "OUT_DATE"~'\d{7}';
update %s."%s" set "ID_BIRTHDAY"="ID_BIRTHDAY"::integer+19110000 where "ID_BIRTHDAY"~'\d{7}';
update %s."%s" set "BABYBIRD"="BABYBIRD"::integer+19110000 where "BABYBIRD"~'\d{7}';
update %s."%s" set "APPL_BEG_DATE"="APPL_BEG_DATE"::integer+19110000 where "APPL_BEG_DATE"~'\d{7}';
update %s."%s" set "APPL_END_DATE"="APPL_END_DATE"::integer+19110000 where "APPL_END_DATE"~'\d{7}';
update %s."%s" set "IN_DATE"="IN_DATE"::integer+19110000 where "IN_DATE"~'\d{7}';
update %s."%s" set "ID_SEX"="PSEX" from "PBASINFO" where "ID"=trim("PIDNO");"""%(schm, nhirdTbl, schm, nhirdTbl, schm, nhirdTbl, schm, nhirdTbl, schm, nhirdTbl, schm, nhirdTbl, schm, nhirdTbl, schm, nhirdTbl)
#delete from %s."%s" where right("FEE_YM",2)>'12';
#delete from %s."%s" where "FEE_YM"='191100';
#update %s."%s" set "FEE_YM"=("FEE_YM"::integer+191100)::varchar where "FEE_YM"~'\d{5}';
#update %s."%s" set "FEE_YM"="FEE_YM"::smallint+191100;
notice(updateDD)
execute(updateDD)

outputDD="""copy (select "FEE_YM", "APPL_TYPE", NULL "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "ID_UUID" "ID", left("ID_BIRTHDAY",6) "ID_BIRTHDAY", "GAVE_KIND", "TRAC_EVEN", "CARD_SEQ_NO", "FUNC_TYPE", "IN_DATE", "OUT_DATE", "APPL_BEG_DATE", "APPL_END_DATE", "E_BED_DAY", "S_BED_DAY", "PRSN_UUID" "PRSN_ID", "DRG_CODE", "EXT_CODE_1", "EXT_CODE_2", "TRAN_CODE", "ICD9CM_CODE", "ICD9CM_CODE_1", "ICD9CM_CODE_2", "ICD9CM_CODE_3", "ICD9CM_CODE_4", "ICD_OP_CODE", "ICD_OP_CODE_1", "ICD_OP_CODE_2", "ICD_OP_CODE_3", "ICD_OP_CODE_4", "DIAG_AMT", "ROOM_AMT", "MEAL_AMT", "AMIN_AMT", "RADO_AMT", "THRP_AMT", "SGRY_AMT", "PHSC_AMT", "BLOD_AMT", "HD_AMT", "ANE_AMT", "METR_AMT", "DRUG_AMT", "DSVC_AMT", "NRTP_AMT", "INJT_AMT", "BABY_AMT", "CHARG_AMT", "MED_AMT", "PART_AMT", "APPL_AMT", "EB_APPL30_AMT", "EB_PART30_AMT", "EB_APPL60_AMT", "EB_PART60_AMT", "EB_APPL61_AMT", "EB_PART61_AMT", "SB_APPL30_AMT", "SB_PART30_AMT", "SB_APPL90_AMT", "SB_PART90_AMT", "SB_APPL180_AMT", "SB_PART180_AMT", "SB_APPL181_AMT", "SB_PART181_AMT", "PART_MARK", "ID_SEX", "EXM_RESULT_DRG_1", "EXM_RESULT_MDC_1", "TW_DRGS", "APPL_CAUSE_MARK", "TW_DRGS_SUIT_MARK", "PAT_SOURCE", "ORDER_NUM", left("BABYBIRD",6) "BABYBIRD", "TW_DRGS_PAY_TYPE", "CHILD_MARK", "ICD6", "ICD7", "ICD8", "ICD9", "ICD10", "ICD11", "ICD12", "ICD13", "ICD14", "ICD15", "ICD16", "ICD17", "ICD18", "ICD19", "ICD20", "OPD6", "OPD7", "OPD8", "OPD9", "OPD10", "OPD11", "OPD12", "OPD13", "OPD14", "OPD15", "OPD16", "OPD17", "OPD18", "OPD19", "OPD20", "FINKEY", "HIST_UUID" "BHISTNO", "BPSECT"from %s."%s" limit 1000)to '/tmp/NcrmntDD.csv' with(format csv, header);"""%(schm, nhirdTbl)
notice(outputDD)
execute(outputDD)

cmd="""update %s."%s" set "HIST_UUID"="UUID" from "MAPPING_PHISTNUM" where "BHISTNO"="PHISTNUM";
update %s."%s"o set "ID_UUID"="UUID" from "MAPPING_PIDNO" where "ID"="PIDNO";
update %s."%s" set "PRSN_UUID"="UUID" from "MAPPING_VUOPERID_VUIDNO" where "VUIDNO"="PRSN_ID";"""%(schm, nhirdTbl, schm, nhirdTbl, schm, nhirdTbl)
notice(cmd)
execute(cmd)

$nhird$ LANGUAGE plpython3u;
