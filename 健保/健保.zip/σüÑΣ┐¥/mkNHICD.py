create or replace function "mkNHICD"(in tbl varchar default 'CD', in dflt_schm varchar default 'nhicd', in flsh_schm boolean default false, in nhicd_type varchar default 'CD') RETURNS void AS $nhicd$ 
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

schm=dflt_schm if dflt_schm.islower() else '"%s"'%dflt_schm
notice(schm)
nhicd_type
NHICD={'CD':{
'tblName':['DTLFA099', 'DTLFDEH', 'DTLFAM00', 'DTLFAM01', 'DTLFAM02', 'DTLFAM03', 'DTLFAM04', 'DTLFAM05', 'DTLFAM06', 'DTLFAM07', 'DTLFAM08'],
'createTbl':'CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(10) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "CURE_ITEM_NO1" varchar(2) NULL, "CURE_ITEM_NO2" varchar(2) NULL, "CURE_ITEM_NO3" varchar(2) NULL, "CURE_ITEM_NO4" varchar(2) NULL, "FUNC_TYPE" varchar(2) NULL, "FUNC_DATE" varchar(8) NULL, "TREAT_END_DATE" varchar(10) NULL, "ID_BIRTHDAY" varchar(8) NULL, "ID" varchar(10) NULL, "CARD_SEQ_NO" varchar(4) NULL, "GAVE_KIND" varchar(1) NULL, "PART_NO" varchar(3) NULL, "ACODE_ICD9_1" varchar(8) NULL, "ACODE_ICD9_2" varchar(8) NULL, "ACODE_ICD9_3" varchar(8) NULL, "ICD_OP_CODE" varchar(8) NULL, "DRUG_DAY" numeric(8) NULL, "MED_TYPE" varchar(1) NULL, "PRSN_ID" varchar(10) NULL, "PHAR_ID" varchar(10) NULL, "DRUG_AMT" numeric(8) NULL, "TREAT_AMT" numeric(8) NULL, "TREAT_CODE" varchar(12) NULL, "DIAG_AMT" numeric(8) NULL, "DSVC_NO" varchar(12) NULL, "DSVC_AMT" numeric(8) NULL, "CASE_PAY_CODE" varchar(2) NULL, "T_AMT" numeric(8) NULL, "PART_AMT" numeric(8) NULL, "T_APPL_AMT" numeric(8) NULL, "ID_SEX" varchar(1) NULL, "TRAN_IN_HOSP_ID" varchar(10) NULL, "PAT_TRAN_OUT" varchar(1) NULL, "APPL_CAUSE_MARK" varchar(1) NULL, "ICD_OP_CODE2" varchar(8) NULL, "CHR_DAYS" varchar(2) NULL, "ARNHIST" varchar(10) NULL, "ARNSECT" varchar(3) NULL, "HOSP_UUID" varchar(36) NULL, "PRSN_UUID" varchar(36) NULL, "PHAR_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "ARNHIST_UUID" varchar(36) NULL, "TRANIN_UUID" varchar(36) NULL) PARTITION BY RANGE("FEE_YM");'%(schm, tbl),
'insertTbl':"""insert into %s."%s" select trim("YYYMM")::smallint+191100, trim("APPLTYP"), trim("HOSID2"), NULL, trim("ARNHMANO"), trim("ARNICNO1"), trim("ARNHSUB1"), trim("ARNHSUB2"), trim("ARNHSUB3"), trim("ARNHSUB4"), trim("ARSEC"), case when trim("ARNDATE")<>'' then "ARNDATE"::integer+19110000 else NULL end, case when trim("ARNHENDY")='' then NULL else trim("ARNHENDY")::integer+19110000 end, case when trim("ARNHBIDT")='' then NULL else trim("ARNHBIDT")::integer+19110000 end, trim("ARNHPAID"), trim("ARNHICNO"), trim("ARNHSICK"), trim("ARNHOPD"), trim("ARNHIC9"), trim("ARNHIC92"), trim("ARNHIC93"), trim("ARNHOR"), "ARNHDUR", trim("ARNHRX"), trim("ARNHDOCT"), trim("ARNHDUGR"), "DRUG", "EXEC", trim("ARNHICD"), "DIAGSFE", trim("ARNHUICD"), "DRUGSFE", trim("RESERVC2"), "TOTAL", "SELPAY", "APPTOT", NULL, case when trim("ARNHTRID")='N' then NULL else trim("ARNHTRID") end, case when trim("ARNHOUT")='N' then NULL else trim("ARNHOUT") end, NULL, trim("ARNHOR2"), trim("ARNHSTOT"), trim("ARNHIST"), trim("ARNSECT") from "%s";"""%(schm, tbl, idx),
'updateTbl':'update %s."%s" set ("ID_BIRTHDAY","ID_SEX")=("PBIRTHDT","PSEX") from "PBASINFO" where "ARNHIST"="PHISTNUM";'%(schm, tbl),
'outputTbl':"""copy (select "FEE_YM", "APPL_TYPE", NULL "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "CURE_ITEM_NO1", "CURE_ITEM_NO2", "CURE_ITEM_NO3", "CURE_ITEM_NO4", "FUNC_TYPE", "FUNC_DATE", "TREAT_END_DATE", left("ID_BIRTHDAY",6) "ID_BIRTHDAY", "ID_UUID" "ID", "CARD_SEQ_NO", "GAVE_KIND", "PART_NO", "ACODE_ICD9_1", "ACODE_ICD9_2", "ACODE_ICD9_3", "ICD_OP_CODE", "DRUG_DAY", "MED_TYPE", "PRSN_UUID" "PRSN_ID", "PHAR_UUID" "PHAR_ID", "DRUG_AMT", "TREAT_AMT", "TREAT_CODE", "DIAG_AMT", "DSVC_NO", "DSVC_AMT", "CASE_PAY_CODE", "T_AMT", "PART_AMT", "T_APPL_AMT", "ID_SEX", "TRANIN_UUID" "TRAN_IN_HOSP_ID", "PAT_TRAN_OUT", "APPL_CAUSE_MARK", "ICD_OP_CODE2", "CHR_DAYS", "ARNHIST_UUID" "ARNHIST", "ARNSECT" from %s."%s" limit 1000) to '/tmp/CD.csv' WITH CSV HEADER;"""%(schm, tbl)},
'OO':{
'tblName':['DTLFA099', 'DTLFDEH', 'DTLFAM00', 'DTLFAM01', 'DTLFAM02', 'DTLFAM03', 'DTLFAM04', 'DTLFAM05', 'DTLFAM06', 'DTLFAM07', 'DTLFAM08'],
'createTbl':'CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(10) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "CURE_ITEM_NO1" varchar(2) NULL, "CURE_ITEM_NO2" varchar(2) NULL, "CURE_ITEM_NO3" varchar(2) NULL, "CURE_ITEM_NO4" varchar(2) NULL, "FUNC_TYPE" varchar(2) NULL, "FUNC_DATE" varchar(8) NULL, "TREAT_END_DATE" varchar(10) NULL, "ID_BIRTHDAY" varchar(8) NULL, "ID" varchar(10) NULL, "CARD_SEQ_NO" varchar(4) NULL, "GAVE_KIND" varchar(1) NULL, "PART_NO" varchar(3) NULL, "ACODE_ICD9_1" varchar(8) NULL, "ACODE_ICD9_2" varchar(8) NULL, "ACODE_ICD9_3" varchar(8) NULL, "ICD_OP_CODE" varchar(8) NULL, "DRUG_DAY" numeric(8) NULL, "MED_TYPE" varchar(1) NULL, "PRSN_ID" varchar(10) NULL, "PHAR_ID" varchar(10) NULL, "DRUG_AMT" numeric(8) NULL, "TREAT_AMT" numeric(8) NULL, "TREAT_CODE" varchar(12) NULL, "DIAG_AMT" numeric(8) NULL, "DSVC_NO" varchar(12) NULL, "DSVC_AMT" numeric(8) NULL, "CASE_PAY_CODE" varchar(2) NULL, "T_AMT" numeric(8) NULL, "PART_AMT" numeric(8) NULL, "T_APPL_AMT" numeric(8) NULL, "ID_SEX" varchar(1) NULL, "TRAN_IN_HOSP_ID" varchar(10) NULL, "PAT_TRAN_OUT" varchar(1) NULL, "APPL_CAUSE_MARK" varchar(1) NULL, "ICD_OP_CODE2" varchar(8) NULL, "CHR_DAYS" varchar(2) NULL, "ARNHIST" varchar(10) NULL, "ARNSECT" varchar(3) NULL, "HOSP_UUID" varchar(36) NULL, "PRSN_UUID" varchar(36) NULL, "PHAR_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "ARNHIST_UUID" varchar(36) NULL, "TRANIN_UUID" varchar(36) NULL) PARTITION BY RANGE("FEE_YM");'%(schm, tbl),
'insertTbl':"""insert into %s."%s" select trim("YYYMM")::smallint+191100, trim("APPLTYP"), trim("HOSID2"), NULL, trim("ARNHMANO"), trim("ARNICNO1"), trim("ARNHSUB1"), trim("ARNHSUB2"), trim("ARNHSUB3"), trim("ARNHSUB4"), trim("ARSEC"), case when trim("ARNDATE")<>'' then "ARNDATE"::integer+19110000 else NULL end, case when trim("ARNHENDY")='' then NULL else trim("ARNHENDY")::integer+19110000 end, case when trim("ARNHBIDT")='' then NULL else trim("ARNHBIDT")::integer+19110000 end, trim("ARNHPAID"), trim("ARNHICNO"), trim("ARNHSICK"), trim("ARNHOPD"), trim("ARNHIC9"), trim("ARNHIC92"), trim("ARNHIC93"), trim("ARNHOR"), "ARNHDUR", trim("ARNHRX"), trim("ARNHDOCT"), trim("ARNHDUGR"), "DRUG", "EXEC", trim("ARNHICD"), "DIAGSFE", trim("ARNHUICD"), "DRUGSFE", trim("RESERVC2"), "TOTAL", "SELPAY", "APPTOT", NULL, case when trim("ARNHTRID")='N' then NULL else trim("ARNHTRID") end, case when trim("ARNHOUT")='N' then NULL else trim("ARNHOUT") end, NULL, trim("ARNHOR2"), trim("ARNHSTOT"), trim("ARNHIST"), trim("ARNSECT") from "%s";"""%(schm, tbl, idx),
'updateTbl':'update %s."%s" set ("ID_BIRTHDAY","ID_SEX")=("PBIRTHDT","PSEX") from "PBASINFO" where "ARNHIST"="PHISTNUM";'%(schm, tbl),
'outputTbl':"""copy (select "FEE_YM", "APPL_TYPE", NULL "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "CURE_ITEM_NO1", "CURE_ITEM_NO2", "CURE_ITEM_NO3", "CURE_ITEM_NO4", "FUNC_TYPE", "FUNC_DATE", "TREAT_END_DATE", left("ID_BIRTHDAY",6) "ID_BIRTHDAY", "ID_UUID" "ID", "CARD_SEQ_NO", "GAVE_KIND", "PART_NO", "ACODE_ICD9_1", "ACODE_ICD9_2", "ACODE_ICD9_3", "ICD_OP_CODE", "DRUG_DAY", "MED_TYPE", "PRSN_UUID" "PRSN_ID", "PHAR_UUID" "PHAR_ID", "DRUG_AMT", "TREAT_AMT", "TREAT_CODE", "DIAG_AMT", "DSVC_NO", "DSVC_AMT", "CASE_PAY_CODE", "T_AMT", "PART_AMT", "T_APPL_AMT", "ID_SEX", "TRANIN_UUID" "TRAN_IN_HOSP_ID", "PAT_TRAN_OUT", "APPL_CAUSE_MARK", "ICD_OP_CODE2", "CHR_DAYS", "ARNHIST_UUID" "ARNHIST", "ARNSECT" from %s."%s" limit 1000) to '/tmp/CD.csv' WITH CSV HEADER;"""%(schm, tbl)},


#tblName=
nhicdInfo=NHICD.get(nhicd_type)
tblName=nhicdInfo.get('tblName')
createTbl=nhicdInfo.get('createTbl')
insertTbl=nhicdInfo.get('insertTbl')
updateTbl=nhicdInfo.get('updateTbl')
createTbl=
annYear=[]
if flsh_schm:
	dropSchema='DROP SCHEMA IF EXISTS %s CASCADE;'%schm 
	notice(dropSchema)
	execute(dropSchema)
createSchema='create schema if not exists %s;'%schm
notice(createSchema)
execute(createSchema)

if flsh_schm:
	dropCD='DROP TABLE IF EXISTS %s."%s" CASCADE;'%(schm, tbl)
	notice(dropCD)
	execute(dropCD)

createCD='CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(10) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "CURE_ITEM_NO1" varchar(2) NULL, "CURE_ITEM_NO2" varchar(2) NULL, "CURE_ITEM_NO3" varchar(2) NULL, "CURE_ITEM_NO4" varchar(2) NULL, "FUNC_TYPE" varchar(2) NULL, "FUNC_DATE" varchar(8) NULL, "TREAT_END_DATE" varchar(10) NULL, "ID_BIRTHDAY" varchar(8) NULL, "ID" varchar(10) NULL, "CARD_SEQ_NO" varchar(4) NULL, "GAVE_KIND" varchar(1) NULL, "PART_NO" varchar(3) NULL, "ACODE_ICD9_1" varchar(8) NULL, "ACODE_ICD9_2" varchar(8) NULL, "ACODE_ICD9_3" varchar(8) NULL, "ICD_OP_CODE" varchar(8) NULL, "DRUG_DAY" numeric(8) NULL, "MED_TYPE" varchar(1) NULL, "PRSN_ID" varchar(10) NULL, "PHAR_ID" varchar(10) NULL, "DRUG_AMT" numeric(8) NULL, "TREAT_AMT" numeric(8) NULL, "TREAT_CODE" varchar(12) NULL, "DIAG_AMT" numeric(8) NULL, "DSVC_NO" varchar(12) NULL, "DSVC_AMT" numeric(8) NULL, "CASE_PAY_CODE" varchar(2) NULL, "T_AMT" numeric(8) NULL, "PART_AMT" numeric(8) NULL, "T_APPL_AMT" numeric(8) NULL, "ID_SEX" varchar(1) NULL, "TRAN_IN_HOSP_ID" varchar(10) NULL, "PAT_TRAN_OUT" varchar(1) NULL, "APPL_CAUSE_MARK" varchar(1) NULL, "ICD_OP_CODE2" varchar(8) NULL, "CHR_DAYS" varchar(2) NULL, "ARNHIST" varchar(10) NULL, "ARNSECT" varchar(3) NULL, "HOSP_UUID" varchar(36) NULL, "PRSN_UUID" varchar(36) NULL, "PHAR_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "ARNHIST_UUID" varchar(36) NULL, "TRANIN_UUID" varchar(36) NULL) PARTITION BY RANGE("FEE_YM");'%(schm, tbl)
notice(createCD)
execute(createCD)

def insrtCD(schm, tbl, tblName):
	nonlocal annYear
	try:
		for idx in tblName:
			insertCD="""insert into %s."%s" select trim("YYYMM")::smallint+191100, trim("APPLTYP"), trim("HOSID2"), NULL, trim("ARNHMANO"), trim("ARNICNO1"), trim("ARNHSUB1"), trim("ARNHSUB2"), trim("ARNHSUB3"), trim("ARNHSUB4"), trim("ARSEC"), case when trim("ARNDATE")<>'' then "ARNDATE"::integer+19110000 else NULL end, case when trim("ARNHENDY")='' then NULL else trim("ARNHENDY")::integer+19110000 end, case when trim("ARNHBIDT")='' then NULL else trim("ARNHBIDT")::integer+19110000 end, trim("ARNHPAID"), trim("ARNHICNO"), trim("ARNHSICK"), trim("ARNHOPD"), trim("ARNHIC9"), trim("ARNHIC92"), trim("ARNHIC93"), trim("ARNHOR"), "ARNHDUR", trim("ARNHRX"), trim("ARNHDOCT"), trim("ARNHDUGR"), "DRUG", "EXEC", trim("ARNHICD"), "DIAGSFE", trim("ARNHUICD"), "DRUGSFE", trim("RESERVC2"), "TOTAL", "SELPAY", "APPTOT", NULL, case when trim("ARNHTRID")='N' then NULL else trim("ARNHTRID") end, case when trim("ARNHOUT")='N' then NULL else trim("ARNHOUT") end, NULL, trim("ARNHOR2"), trim("ARNHSTOT"), trim("ARNHIST"), trim("ARNSECT") from "%s";"""%(schm, tbl, idx)
			notice(insertCD)
			execute(insertCD)
	except:
		errmsg=exc_info()[1]
		excptMsg=errmsg.spidata[1]
		notice(excptMsg)	#errmsg.spidata->'spidata', 'sqlstate', 'with_traceback'
		ann=search('\d{4}', excptMsg).group(0)
		startVal, endVal='%s01'%ann, '%s13'%ann
		prttnTbl='CREATE TABLE if not exists %s."%s%s" PARTITION OF %s."%s" FOR VALUES FROM (%s) TO (%s);'%(schm, tbl, ann, schm, tbl, startVal, endVal)
		annYear.append(ann)
		notice(prttnTbl)
		execute(prttnTbl)
		insrtCD(schm, tbl, tblName)
insrtCD(schm, tbl, tblName)

updateCD='update %s."%s" set ("ID_BIRTHDAY","ID_SEX")=("PBIRTHDT","PSEX") from "PBASINFO" where "ARNHIST"="PHISTNUM";'%(schm, tbl)
notice(updateCD)
execute(updateCD)
#update %s."%s" set "TREAT_END_DATE"=case when "TREAT_END_DATE"<>'''' then "TREAT_END_DATE"::integer+19110000 else NULL end;
#update %s."%s" set "ID_BIRTHDAY"=case when "ID_BIRTHDAY"<>'''' then "ID_BIRTHDAY"::integer+19110000 else NULL end;
#update %s."%s" set "FUNC_DATE"=case when "FUNC_DATE"<>'''' then "FUNC_DATE"::integer+19110000 else NULL end;
#update %s."%s" set "FEE_YM"=("FEE_YM"::smallint+191100)::varchar;

outputCD="""copy (select "FEE_YM", "APPL_TYPE", NULL "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "CURE_ITEM_NO1", "CURE_ITEM_NO2", "CURE_ITEM_NO3", "CURE_ITEM_NO4", "FUNC_TYPE", "FUNC_DATE", "TREAT_END_DATE", left("ID_BIRTHDAY",6) "ID_BIRTHDAY", "ID_UUID" "ID", "CARD_SEQ_NO", "GAVE_KIND", "PART_NO", "ACODE_ICD9_1", "ACODE_ICD9_2", "ACODE_ICD9_3", "ICD_OP_CODE", "DRUG_DAY", "MED_TYPE", "PRSN_UUID" "PRSN_ID", "PHAR_UUID" "PHAR_ID", "DRUG_AMT", "TREAT_AMT", "TREAT_CODE", "DIAG_AMT", "DSVC_NO", "DSVC_AMT", "CASE_PAY_CODE", "T_AMT", "PART_AMT", "T_APPL_AMT", "ID_SEX", "TRANIN_UUID" "TRAN_IN_HOSP_ID", "PAT_TRAN_OUT", "APPL_CAUSE_MARK", "ICD_OP_CODE2", "CHR_DAYS", "ARNHIST_UUID" "ARNHIST", "ARNSECT" from %s."%s" limit 1000) to '/tmp/CD.csv' WITH CSV HEADER;"""%(schm, tbl)
notice(outputCD)
execute(outputCD)

for ann in annYear:
	if flsh_schm:
		dropViewCD='DROP VIEW IF EXISTS %s."vldBday%s%s";'%(schm, tbl, ann)
		notice(dropViewCD)
		execute(dropViewCD)
	vldViewCD="""create or replace view %s."vldBday%s%s" as select * from %s."%s%s" where right("ID_BIRTHDAY",4)<='1231';"""%(schm, tbl, ann, schm, tbl, ann)
	notice(vldViewCD)
	execute(vldViewCD)

$nhicd$ LANGUAGE plpython3u
