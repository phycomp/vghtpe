create or replace function "mkNcrmntLBDT7"(in "rsltTbl" varchar default 'RESULT', in "nhirdTbl" varchar default 'tmplLBDT', in "dfltSchm" varchar default 'nhird', in "flshSchm" boolean default false) RETURNS void AS $LBDT$ 
from plpy import cursor, execute, notice
from sys import exc_info
from re import search
schm=dfltSchm if dfltSchm.islower() else f'"{dfltSchm}"'
dropCreateSchema=f'drop schema if exists {schm}; create schema if not exists {schm};'
notice(dropCreateSchema)
#execute(dropCreateSchema)

cmbTbl=f'''{schm}."{nhirdTbl}CMB"'''
if flshSchm:
	dropCMB=f'''DROP TABLE if exists {cmbTbl};'''
	notice(dropCMB)
	execute(dropCMB)
#DROP TABLE if exists %s."%s"; 
prttnRslt=f'''{schm}."{nhirdTbl}"'''
orgHIST, orgSYM, orgPFKEY, orgNORMAL, orgDATE, orgVALUE="RSHISTNO", "RSRTSYM", "RSPFKEY", "RSNORMAL", "RSDATE", "RSVALUE"
#orgHIST, orgREQ, orgSEQ, orgSYM, orgPFKEY, orgNORMAL, orgDATE, orgVALUE="RSHISTNO", "RSREQNO", "RSSEQCN", "RSRTSYM", "RSPFKEY", "RSNORMAL", "RSDATE", "RSVALUE"
#histClmn, reqClmn, seqClmn, symClmn, pfkeyClmn, normalClmn, dateClmn, valueClmn="HISTNO", "REQNO", "SEQCN", "RTSYM", "PFKEY", "NORMAL", "RSDATE", "VALUE"
createLBDT=f'CREATE TABLE if not exists {prttnRslt}("{orgHIST}" varchar(10), "{orgSYM}" varchar(8), "{orgPFKEY}" varchar(8), "{orgNORMAL}" varchar(1), "{orgDATE}" integer, "{orgVALUE}" text) PARTITION BY RANGE("{orgDATE}");'#, "PFPROCED" varchar(32), "PFRSINIT" varchar(12), "PFRSTTL" varchar(32), "PFRSTTLC" varchar(64), "PFRSUNIT" varchar(12), "PFREFER" varchar(40)#, schm, nhirdTbl)
notice(createLBDT)
execute(createLBDT)
orgnlRslt=f'''{schm}."{rsltTbl}"'''
def lbdtPrttn(prttnRslt, orgnlRslt):
	try:
		#insertLBDT=f"""insert into {schm}."{nhirdTbl}" select trim(R."RSHISTNO"), R."RSREQNO", R."RSSEQCN", R."RSRTSYM", R."RSPFKEY", R."RSNORMAL", replace("RSDATE"::varchar,'-','')::integer, R."RSVALUE" from {tbl} R inner JOIN "PFRSLT" PR on R."RSPFKEY"=PR."PFKEY" and R."RSRTSYM"=PR."PFRSYMBL" where "RSSTATUS"<='68' and "RSSTATUS">='64' and "PFRSTYPE"='N';"""#, PR."PFREFER", PR."PFPROCED", PR."PFRSINIT", PR."PFRSTTL", PR."PFRSTTLC", PR."PFRSUNIT", char_length(trim(PR."PFRSUNIT"))<>0
		nsrtLBDT=f'''insert into {prttnRslt} select "{orgHIST}" , "{orgSYM}" , "{orgPFKEY}" , "{orgNORMAL}" , replace("{orgDATE}"::varchar,'-','')::integer, "{orgVALUE}" from {orgnlRslt};'''
		notice(nsrtLBDT)
		execute(nsrtLBDT)
		#insertLBDT=f"""insert into {schm}."{nhirdTbl}cmb" select cmb."HISTNO", cmb."RSRTSYM", cmb."PFKEY", string_agg(concat(cmb."RSDATE", '$',cmb."RSVALUE", '$', cmb."RSNORMAL"), '#'order by cmb."RSDATE")from cmb where cmb."RSRTSYM"!~'COMENT' group by (cmb."HISTNO", cmb."RSRTSYM", cmb."PFKEY") order by 1 from (select trim(R."RSHISTNO") "HISTNO", R."RSREQNO" "REQNO", R."RSSEQCN" "SEQCN", R."RSRTSYM" "RSRTSYM", R."RSPFKEY" "PFKEY", R."RSNORMAL" "RSNORMAL", replace("RSDATE"::varchar,'-','')::integer "RSDATE", R."RSVALUE" "RSVALUE" from {tbl} R inner JOIN "PFRSLT" PR on R."RSPFKEY"=PR."PFKEY" and R."RSRTSYM"=PR."PFRSYMBL" where "RSSTATUS"<='68' and "RSSTATUS">='64' and "PFRSTYPE"='N')cmb;"""#, PR."PFREFER", PR."PFPROCED", PR."PFRSINIT", PR."PFRSTTL", PR."PFRSTTLC", PR."PFRSUNIT", char_length(trim(PR."PFRSUNIT"))<>0
		#notice(insertLBDT)
		#execute(insertLBDT)
	except:
		errmsg=exc_info()[1]
		notice('errmsg',errmsg)#, 'args', 'spidata', 'sqlstate', 'with_traceback'
		excptMsg=errmsg.spidata[1]
		notice('excptMsg=', excptMsg)
		ann=search('\d{4}', excptMsg).group(0)
		startVal, endVal=f'{ann}0101', f'{ann}1301'
		#execute('select a[1] from regexp_match(errmsg2, ''\d{4}'')a;'
		annRslt=f'''{schm}."{nhirdTbl}{ann}"'''
		annSQL=f'CREATE TABLE if not exists {annRslt} PARTITION OF {prttnRslt} FOR VALUES FROM ({startVal}) TO ({endVal});'
		notice(annSQL)
		execute(annSQL)
		lbdtPrttn(prttnRslt, orgnlRslt)
lbdtPrttn(prttnRslt, orgnlRslt)
cmbUnit, cmbRefer, cmbValue="PFRSUNIT", "PFREFER", "cmbValue"
def cmbInsrt(cmbTbl, orgnlRslt):
	try:
		insertCMB=f"""insert into {cmbTbl} select cmb."{orgHIST}", cmb."{orgSYM}", cmb."{orgPFKEY}", string_agg(concat(cmb."{orgDATE}", '$',cmb."{orgVALUE}", '$', cmb."{orgNORMAL}"), '#'order by cmb."{orgDATE}") "cmbValue" from (select trim(R."{orgHIST}") "{orgHIST}", trim(R."{orgSYM}") "{orgSYM}", R."{orgPFKEY}", R."{orgNORMAL}", replace("RSDATE"::varchar,'-','')::integer "{orgDATE}", R."{orgVALUE}", PR."PFRSUNIT", PR."PFREFER" from {orgnlRslt} R JOIN "PFRSLT" PR on R."{orgPFKEY}"=PR."PFKEY" and trim(R."{orgSYM}")=PR."PFRSYMBL" where "PFRSTYPE"='N')cmb where cmb."{orgSYM}"!~'COMENT' group by (cmb."{orgHIST}", cmb."{orgSYM}", cmb."{orgPFKEY}") order by 1 ;"""
		notice(insertCMB)
		execute(insertCMB)
	except:
		errmsg=exc_info()[1]
		notice('errmsg',errmsg)#, 'args', 'spidata', 'sqlstate', 'with_traceback'
		excptMsg=errmsg.spidata[1]
		notice('excptMsg=', excptMsg)
		ann=search('\d{4}', excptMsg).group(0)
		startVal, endVal=f'{ann}0101', f'{ann}1301'
		#execute('select a[1] from regexp_match(errmsg2, ''\d{4}'')a;'
		annCMB=f'''{schm}."{nhirdTbl}cmb{ann}"'''
		annSQL=f'CREATE TABLE if not exists {annCMB} PARTITION OF {cmbTbl} FOR VALUES FROM ({startVal}) TO ({endVal});'
		notice(annSQL)
		execute(annSQL)
		cmbInsrt(cmbTbl, orgnlRslt)
createLBDT=f'CREATE TABLE if not exists {cmbTbl}("{orgHIST}" varchar(10), "{orgSYM}" varchar(8), "{orgPFKEY}" varchar(8), "{cmbValue}" text);'
notice(createLBDT)
execute(createLBDT)
cmbInsrt(cmbTbl, orgnlRslt)
#create table ("HISTNO", "RSRTSYM" ,"PFKEY", "comboVALUE"
#outputLBDT="""copy (select * from {schm}."{nhirdTbl}" limit 1000) to '/tmp/LBDT.csv' with(format csv, header);"""
#notice(outputLBDT)
#execute(outputLBDT)

$LBDT$ LANGUAGE plpython3u;

/*
'''
PFILE
	PFNATNA
	PFNATNAC
	PFUNIT1
	PFPROCED
	PFNHICD

PFRSLT
 PFKEY    | character varying(8)  | 
 PFRSYMBL | character varying(8)  | 
 PFRSEQ   | character varying(3)  | 
 PFRSUBSQ | character varying(3)  | 
 PFPROCED | character varying(32) | 
 PFRSTYPE | character varying(1)  | 
 PFRSINIT | character varying(12) | 
 PFRSTTL  | character varying(32) | 
 PFRSTTLC | character varying(64) | 
 PFRSUNIT | character varying(12) | 
 PFREFER  | character varying(40) | 
*/
