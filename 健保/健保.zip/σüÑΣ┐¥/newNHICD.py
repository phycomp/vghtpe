create or replace function "newNHICD"(in "ICD9" varchar default '36232', in "ICD10" varchar default 'H3223', in "reICD10" varchar default 'None', in seqno varchar default '10001', in "dfltSchm" varchar default 'isc8381', in "flshSchm" boolean default false) RETURNS void AS $nhicd$ 
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

setSrchPth="""set search_path=%s,"BDC_BASE",public;"""%dfltSchm
notice(setSrchPth)
execute(setSrchPth)

schm=dfltSchm if dfltSchm.islower() else '"%s"'%dfltSchm
notice(schm)
if flshSchm:
	dropSchema='DROP SCHEMA IF EXISTS %s CASCADE;'%schm 
	notice(dropSchema)
	execute(dropSchema)
createSchema='create schema if not exists %s;'%schm
notice(createSchema)
#execute(createSchema)

if flshSchm:
	dropCD='DROP TABLE IF EXISTS %s."%s" CASCADE;'%(schm, tbl)
	notice(dropCD)
	execute(dropCD)

dstnct6Clmn='dstnct6Clmn'
crtCDvsOO='CREATE TABLE if not exists %s."%s"("tblType" varchar(6) NULL, "ARNHIST" varchar(10) NULL, "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL) ;'%(schm, dstnct6Clmn)
notice(crtCDvsOO)
notice(ICD9)
aICD9=','.join(ICD9.split('|'))	#CD-->ACODE_ICD9_1, ACODE_ICD9_2, ACODE_ICD9_3
ageCnstrnt='''("FUNC_DATE"::date-"ID_BIRTHDAY"::date)::smallint/365>20'''
hospCnstrnt=""""HOSP_ID"='0601160016'"""

CDvsOO="""insert into %s."%s" select distinct c."ARNHIST", c."FEE_YM", c."APPL_TYPE", c."APPL_DATE", c."CASE_TYPE", c."SEQ_NO" from "CD"inner join"OO"o on c."FEE_YM"=o."FEE_YM" and c."APPL_TYPE"=o."APPL_TYPE" and c."APPL_DATE"=o."APPL_DATE" and c."CASE_TYPE"=o."CASE_TYPE" and c."SEQ_NO"=o."SEQ_NO" where %s and %s and "ACODE_ICD9_1"in(%s) and "ACODE_ICD9_2"in(%s) and "ACODE_ICD9_3"in(%s);"""%(schm, dstnctCDvsOO, ageCnstrnt, hospCnstrnt, ICD9, ICD9, ICD9)	#'36231', '36232', '36235', '36236', '36263', '36511', '36560', '3659'
notice(CDvsOO)
#execute(CDvsOO)
updtCDvsOO="""update %s."%s" set "tblType"=CDvsOO' where "tblType"is null;"""%(schm, dstnct6Clmn)
notice(updtCDvsOO)
#execute(updtCDvsOO)

trgtCD='%sCD'%seqno
crtTrgtCD='CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(10) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "CURE_ITEM_NO1" varchar(2) NULL, "CURE_ITEM_NO2" varchar(2) NULL, "CURE_ITEM_NO3" varchar(2) NULL, "CURE_ITEM_NO4" varchar(2) NULL, "FUNC_TYPE" varchar(2) NULL, "FUNC_DATE" varchar(8) NULL, "TREAT_END_DATE" varchar(10) NULL, "ID_BIRTHDAY" varchar(8) NULL, "ID" varchar(10) NULL, "CARD_SEQ_NO" varchar(4) NULL, "GAVE_KIND" varchar(1) NULL, "PART_NO" varchar(3) NULL, "ACODE_ICD9_1" varchar(8) NULL, "ACODE_ICD9_2" varchar(8) NULL, "ACODE_ICD9_3" varchar(8) NULL, "ICD_OP_CODE" varchar(8) NULL, "DRUG_DAY" numeric(8) NULL, "MED_TYPE" varchar(1) NULL, "PRSN_ID" varchar(10) NULL, "PHAR_ID" varchar(10) NULL, "DRUG_AMT" numeric(8) NULL, "TREAT_AMT" numeric(8) NULL, "TREAT_CODE" varchar(12) NULL, "DIAG_AMT" numeric(8) NULL, "DSVC_NO" varchar(12) NULL, "DSVC_AMT" numeric(8) NULL, "CASE_PAY_CODE" varchar(2) NULL, "T_AMT" numeric(8) NULL, "PART_AMT" numeric(8) NULL, "T_APPL_AMT" numeric(8) NULL, "ID_SEX" varchar(1) NULL, "TRAN_IN_HOSP_ID" varchar(10) NULL, "PAT_TRAN_OUT" varchar(1) NULL, "APPL_CAUSE_MARK" varchar(1) NULL, "ICD_OP_CODE2" varchar(8) NULL, "CHR_DAYS" varchar(2) NULL, "ARNHIST" varchar(10) NULL, "ARNSECT" varchar(3) NULL, "HOSP_UUID" varchar(36) NULL, "PRSN_UUID" varchar(36) NULL, "PHAR_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "ARNHIST_UUID" varchar(36) NULL, "TRANIN_UUID" varchar(36) NULL) ;'%(schm, trgtCD)
notice(crtTrgtCD)
#execute(crtTrgtCD)

insrtTrgtCD="""insert into %s."%s" select c.* from "CD"inner join %s."%s"m on c."FEE_YM"=m."FEE_YM" and c."APPL_TYPE"=m."APPL_TYPE" and c."APPL_DATE"=m."APPL_DATE" and c."CASE_TYPE"=m."CASE_TYPE" and c."SEQ_NO"=m."SEQ_NO" and c.ARNHIST"=m.ARNHIST and "tblType"='CDvsOO';"""%(schm, trgtCD, schm, dstnct6Clmn)
notice(insrtTrgtCD)
#execute(insrtTrgtCD)

trgtOO='%sOO'%seqno
crtTrgtOO='drop table if exists %s."%s"; CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(1) NULL, "APPL_DATE" varchar(1) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ORDER_TYPE" varchar(1) NULL, "DRUG_NO" varchar(12) NULL, "DRUG_USE" numeric(7,2) NULL, "DRUG_FRE" varchar(18) NULL, "UNIT_PRICE" numeric(10,2) NULL, "TOTAL_QTY" numeric(7,1) NULL, "TOTAL_AMT" numeric(9) NULL, "REL_MODE" varchar(1) NULL, "EXE_S_DATE" varchar(16) NULL, "EXE_E_DATE" varchar(16) NULL, "PAY_RATE" varchar(3) NULL, "CURE_PATH" varchar(6) NULL, "ORDER_SEQ_NO" varchar(5) NULL, "CHR_MARK" varchar(1) NULL, "DRUG_PATH" varchar(15) NULL, "DRUG_DAY" varchar(2) NULL, "ARNHPAID" varchar(10) NULL, "ARNHROUT" varchar(4) NULL, "ARDDFLAG" varchar(1) NULL, "PFCATG2" varchar(2) NULL, "ARNHIPCD" varchar(8) NULL, "ARNHPNAM" varchar(32) NULL, "ARNHIREQ" varchar(7) NULL, "ARNHIST" varchar(10) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "HOSP_UUID" varchar(36) NULL, "DRUGFRE_UUID" varchar(44) NULL) ;'%(schm, trgtOO)
notice(crtTrgtOO)
#execute(crtTrgtOO)

insrtTrgtOO="""insert into %s."%s" select o.* from "OO"o inner join %s."%s"m on c."FEE_YM"=m."FEE_YM" and c."APPL_TYPE"=m."APPL_TYPE" and c."APPL_DATE"=m."APPL_DATE" and c."CASE_TYPE"=m."CASE_TYPE" and c."SEQ_NO"=m."SEQ_NO" and c.ARNHIST"=m.ARNHIST and "tblType"='DDvsDO';"""%(schm, trgtOO, schm, dstnctDDvsDO)
notice(insrtTrgtOO)
#execute(insrtTrgtOO)

ICD10=','.join(ICD10.split('|'))	#DD-->ICD9CM_CODE, ICD9CM_CODE_1, ICD9CM_CODE_2, ICD9CM_CODE_3, ICD9CM_CODE_4
notice(ICD10)
crtDDvsDO="""insert into %s."%s" select distinct d."ARNHIST", d."FEE_YM", d."APPL_TYPE", d."APPL_DATE", d."CASE_TYPE", d."SEQ_NO" from "DD"d inner join "DO"o on d."FEE_YM"=o."FEE_YM" and d."APPL_TYPE"=o."APPL_TYPE" and d."APPL_DATE"=o."APPL_DATE" and d."CASE_TYPE"=o."CASE_TYPE" and d."SEQ_NO"=o."SEQ_NO" where %s and %s and "ICD9CM_CODE"in(%s) and "ICD9CM_CODE_1"in(%s) and "ICD9CM_CODE_2"in(%s) and "ICD9CM_CODE_3"in(%s) and "ICD9CM_CODE_4"in(%s) ;"""%(schm, dstnctDDvsDO, ageCnstrnt, hospCnstrnt, ICD10, ICD10, ICD10, ICD10)	#'H34231' 'H34232' 'H34233' 'H34239' 'H3410' 'H3411' 'H3412' 'H3413' 'H34831' 'H34832' 'H34833' 'H34839' 'H34131' 'H34132' 'H34133' 'H34139' 'H409' 'H4089' 'H4011' 'H40[3456][0123]' 'H401[2345][1239]'
if reICD10!="None":
	reICD10Pttrn=''
	for reicd10 in reICD10.split('|'):
		reICD10Pttrn+=""""ICD9CM_CODE"~'%s' and "ICD9CM_CODE_1"~'%s' and "ICD9CM_CODE_2"~'%s' and "ICD9CM_CODE_3"~'%s' and "ICD9CM_CODE_4"~'%s' """%(reicd10, reicd10, reicd10, reicd10, reicd10)
	crtDDvsDO="""insert into %s."%s" select 'DDvsDO', distinct d."ARNHIST", d."FEE_YM", d."APPL_TYPE", d."APPL_DATE", d."CASE_TYPE", d."SEQ_NO" from "DD"d inner join "DO"o on d."FEE_YM"=o."FEE_YM" and d."APPL_TYPE"=o."APPL_TYPE" and d."APPL_DATE"=o."APPL_DATE" and d."CASE_TYPE"=o."CASE_TYPE" and d."SEQ_NO"=o."SEQ_NO" where %s and %s and "ICD9CM_CODE"in(%s) and "ICD9CM_CODE_1"in(%s) and "ICD9CM_CODE_2"in(%s) and "ICD9CM_CODE_3"in(%s) and "ICD9CM_CODE_4"in(%s) and %s;"""%(schm, dstnctDDvsDO, ageCnstrnt, hospCnstrnt, ICD10, ICD10, ICD10, ICD10, reICD10Pttrn)
notice(crtDDvsDO)
#execute(crtDDvsDO)
updtDDvsDO="""update %s."%s" set "tblType"=DDvsDO' where "tblType"is null;"""%(schm, dstnct6Clmn)
notice(updtDDvsDO)
#execute(updtDDvsDO)

trgtDD='%sDD'%seqno
crtTrgtDD="""CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(34) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ID" varchar(10) NULL, "ID_BIRTHDAY" varchar(8) NULL, "GAVE_KIND" varchar(1) NULL, "TRAC_EVEN" varchar(1) NULL, "CARD_SEQ_NO" varchar(4) NULL, "FUNC_TYPE" varchar(2) NULL, "IN_DATE" varchar(8) NULL, "OUT_DATE" varchar(8) NULL, "APPL_BEG_DATE" varchar(8) NULL, "APPL_END_DATE" varchar(8) NULL, "E_BED_DAY" numeric(8) NULL, "S_BED_DAY" numeric(8) NULL, "PRSN_ID" varchar(10) NULL, "DRG_CODE" varchar(5) NULL, "EXT_CODE_1" varchar(6) NULL, "EXT_CODE_2" varchar(6) NULL, "TRAN_CODE" varchar(1) NULL, "ICD9CM_CODE" varchar(8) NULL, "ICD9CM_CODE_1" varchar(8) NULL, "ICD9CM_CODE_2" varchar(8) NULL, "ICD9CM_CODE_3" varchar(8) NULL, "ICD9CM_CODE_4" varchar(8) NULL, "ICD_OP_CODE" varchar(8) NULL, "ICD_OP_CODE_1" varchar(8) NULL, "ICD_OP_CODE_2" varchar(8) NULL, "ICD_OP_CODE_3" varchar(8) NULL, "ICD_OP_CODE_4" varchar(8) NULL, "DIAG_AMT" numeric(8) NULL, "ROOM_AMT" numeric(8) NULL, "MEAL_AMT" numeric(8) NULL, "AMIN_AMT" numeric(8) NULL, "RADO_AMT" numeric(8) NULL, "THRP_AMT" numeric(8) NULL, "SGRY_AMT" numeric(8) NULL, "PHSC_AMT" numeric(8) NULL, "BLOD_AMT" numeric(8) NULL, "HD_AMT" numeric(8) NULL, "ANE_AMT" numeric(8) NULL, "METR_AMT" numeric(8) NULL, "DRUG_AMT" numeric(8) NULL, "DSVC_AMT" numeric(8) NULL, "NRTP_AMT" numeric(8) NULL, "INJT_AMT" numeric(8) NULL, "BABY_AMT" numeric(8) NULL, "CHARG_AMT" numeric(8) NULL, "MED_AMT" numeric(8) NULL, "PART_AMT" numeric(8) NULL, "APPL_AMT" numeric(8) NULL, "EB_APPL30_AMT" numeric(8) NULL, "EB_PART30_AMT" numeric(8) NULL, "EB_APPL60_AMT" numeric(8) NULL, "EB_PART60_AMT" numeric(8) NULL, "EB_APPL61_AMT" numeric(8) NULL, "EB_PART61_AMT" numeric(8) NULL, "SB_APPL30_AMT" numeric(8) NULL, "SB_PART30_AMT" numeric(8) NULL, "SB_APPL90_AMT" numeric(8) NULL, "SB_PART90_AMT" numeric(8) NULL, "SB_APPL180_AMT" numeric(8) NULL, "SB_PART180_AMT" numeric(8) NULL, "SB_APPL181_AMT" numeric(8) NULL, "SB_PART181_AMT" numeric(8) NULL, "PART_MARK" varchar(3) NULL, "ID_SEX" varchar(1) NULL, "EXM_RESULT_DRG_1" varchar(5) NULL, "EXM_RESULT_MDC_1" varchar(2) NULL, "TW_DRGS" varchar(5) NULL, "APPL_CAUSE_MARK" varchar(1) NULL, "TW_DRGS_SUIT_MARK" varchar(1) NULL, "PAT_SOURCE" varchar(1) NULL, "ORDER_NUM" numeric(8) NULL, "BABYBIRD" varchar(8) NULL, "TW_DRGS_PAY_TYPE" varchar(1) NULL, "CHILD_MARK" varchar(1) NULL, "ICD6" varchar(8) NULL, "ICD7" varchar(8) NULL, "ICD8" varchar(8) NULL, "ICD9" varchar(8) NULL, "ICD10" varchar(8) NULL, "ICD11" varchar(8) NULL, "ICD12" varchar(8) NULL, "ICD13" varchar(8) NULL, "ICD14" varchar(8) NULL, "ICD15" varchar(8) NULL, "ICD16" varchar(8) NULL, "ICD17" varchar(8) NULL, "ICD18" varchar(8) NULL, "ICD19" varchar(8) NULL, "ICD20" varchar(8) NULL, "OPD6" varchar(8) NULL, "OPD7" varchar(8) NULL, "OPD8" varchar(8) NULL, "OPD9" varchar(8) NULL, "OPD10" varchar(8) NULL, "OPD11" varchar(8) NULL, "OPD12" varchar(8) NULL, "OPD13" varchar(8) NULL, "OPD14" varchar(8) NULL, "OPD15" varchar(8) NULL, "OPD16" varchar(8) NULL, "OPD17" varchar(8) NULL, "OPD18" varchar(8) NULL, "OPD19" varchar(8) NULL, "OPD20" varchar(8) NULL, "FINKEY" varchar(4) NULL, "BHISTNO" varchar(10) NULL, "BPSECT" varchar(4) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "PRSN_UUID" varchar(36) NULL) ;"""%(schm, trgtDD)
notice(crtTrgtDD)
#execute(crtTrgtDD)

insrtTrgtDD="""insert into %s."%s" select c.* from "DD"inner join %s."%s"m on c."FEE_YM"=m."FEE_YM" and c."APPL_TYPE"=m."APPL_TYPE" and c."APPL_DATE"=m."APPL_DATE" and c."CASE_TYPE"=m."CASE_TYPE" and c."SEQ_NO"=m."SEQ_NO" and c.ARNHIST"=m.ARNHIST and "tblType"='DDvsDO';"""%(schm, trgtDD, schm, dstnct6Clmn)
notice(insrtTrgtDD)
#execute(insrtTrgtDD)

trgtDO='%sDO'%seqno
crtTrgtDO="""CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(10) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ORDER_TYPE" varchar(1) NULL, "ORDER_CODE" varchar(12) NULL, "PAY_RATE" numeric(8) NULL, "ORDER_QTY" numeric(8) NULL, "ORDER_PRICE" numeric(10,2) NULL, "ORDER_AMT" numeric(8) NULL, "EXE_S_DATE" varchar(8) NULL, "EXE_E_DATE" varchar(8) NULL, "DRUG_FRE" varchar(22) NULL, "DRUG_PATH" varchar(22) NULL, "TW_DRGS_CALCU" numeric(18) NULL, "CURE_PATH" varchar(47) NULL, "ORDER_SEQ_NO" varchar(5) NULL, "DRUG_USE" varchar(6) NULL, "CON_FUNC_TYPE" varchar(15) NULL, "BED_NO" varchar(15) NULL, "PART_ACCO_DATA" varchar(28) NULL, "BIDNO" varchar(10) NULL, "BOROPTMB" varchar(4) NULL, "BOROPTME" varchar(4) NULL, "PFKEY" varchar(8) NULL, "BHISTNO" varchar(10) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "DRUGFRE_UUID" varchar(44) NULL) ;"""%(schm, trgtDO)
notice(crtTrgtDO)
#execute(crtTrgtDO)

insrtTrgtOO="""insert into %s."%s" select o.* from "DO"o inner join "%s"m on c."FEE_YM"=m."FEE_YM" and c."APPL_TYPE"=m."APPL_TYPE" and c."APPL_DATE"=m."APPL_DATE" and c."CASE_TYPE"=m."CASE_TYPE" and c."SEQ_NO"=m."SEQ_NO" and c.ARNHIST"=m.ARNHIST and "tblType"='DDvsDO';"""%(schm, trgtDO, schm, dstnct6Clmn)
notice(insrtTrgtOO)
#execute(insrtTrgtOO)
$nhicd$ LANGUAGE plpython3u
