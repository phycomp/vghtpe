CREATE OR REPLACE FUNCTION "cmbSplt4"(in cmb_strng varchar, OUT frstStrng varchar, OUT scndStrng varchar, OUT thrdStrng varchar, OUT frthStrng varchar) RETURNS record AS $cmbSplt$
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

frstStrng, scndStrng, thrdStrng, frthStrng = cmb_strng.split('#')
frstStrng = search('RT(\w+?)\d+\w?', frstStrng).group(1)
scndStrng = search('([12]\d{3}-\d{2}-\d{2})\s.*?', scndStrng).group(0)
return frstStrng, scndStrng, thrdStrng, frthStrng
$cmbSplt$ LANGUAGE plpython3u 
