create or replace function "mkSample10K"(in "dfltSchm" varchar default 'nhicd', in "flshSchm" boolean default false) RETURNS void AS $nhicd$ 
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

schm=dfltSchm if dfltSchm.islower() else '"%s"'%dfltSchm
CD10K='tmplCD10K'

createCD='CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(10) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "CURE_ITEM_NO1" varchar(2) NULL, "CURE_ITEM_NO2" varchar(2) NULL, "CURE_ITEM_NO3" varchar(2) NULL, "CURE_ITEM_NO4" varchar(2) NULL, "FUNC_TYPE" varchar(2) NULL, "FUNC_DATE" varchar(8) NULL, "TREAT_END_DATE" varchar(10) NULL, "ID_BIRTHDAY" varchar(8) NULL, "ID" varchar(10) NULL, "CARD_SEQ_NO" varchar(4) NULL, "GAVE_KIND" varchar(1) NULL, "PART_NO" varchar(3) NULL, "ACODE_ICD9_1" varchar(8) NULL, "ACODE_ICD9_2" varchar(8) NULL, "ACODE_ICD9_3" varchar(8) NULL, "ICD_OP_CODE" varchar(8) NULL, "DRUG_DAY" numeric(8) NULL, "MED_TYPE" varchar(1) NULL, "PRSN_ID" varchar(10) NULL, "PHAR_ID" varchar(10) NULL, "DRUG_AMT" numeric(8) NULL, "TREAT_AMT" numeric(8) NULL, "TREAT_CODE" varchar(12) NULL, "DIAG_AMT" numeric(8) NULL, "DSVC_NO" varchar(12) NULL, "DSVC_AMT" numeric(8) NULL, "CASE_PAY_CODE" varchar(2) NULL, "T_AMT" numeric(8) NULL, "PART_AMT" numeric(8) NULL, "T_APPL_AMT" numeric(8) NULL, "ID_SEX" varchar(1) NULL, "TRAN_IN_HOSP_ID" varchar(10) NULL, "PAT_TRAN_OUT" varchar(1) NULL, "APPL_CAUSE_MARK" varchar(1) NULL, "ICD_OP_CODE2" varchar(8) NULL, "CHR_DAYS" varchar(2) NULL, "ARNHIST" varchar(10) NULL, "ARNSECT" varchar(3) NULL, "HOSP_UUID" varchar(36) NULL, "PRSN_UUID" varchar(36) NULL, "PHAR_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "ARNHIST_UUID" varchar(36) NULL, "TRANIN_UUID" varchar(36) NULL);'%(schm, CD10K)
notice(createCD)
#execute(createCD)

insrtCD10K="""insert into %s."%s" select c.* from %s."%s"c join nhicd."IDCD_10K"i where "FEE_YM">='201601' and "FEE_YM"<='201906' and "HIST"="ARNHIST";"""%(schm, CD10K, schm, 'tmpl2CD')
notice(insrtCD10K)
#execute(insrtCD10K)

OO10K='tmplOO10K'
createOO='CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(1) NULL, "APPL_DATE" varchar(1) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ORDER_TYPE" varchar(1) NULL, "DRUG_NO" varchar(12) NULL, "DRUG_USE" numeric(7,2) NULL, "DRUG_FRE" varchar(18) NULL, "UNIT_PRICE" numeric(10,2) NULL, "TOTAL_QTY" numeric(7,1) NULL, "TOTAL_AMT" numeric(9) NULL, "REL_MODE" varchar(1) NULL, "EXE_S_DATE" varchar(16) NULL, "EXE_E_DATE" varchar(16) NULL, "PAY_RATE" varchar(3) NULL, "CURE_PATH" varchar(6) NULL, "ORDER_SEQ_NO" varchar(5) NULL, "CHR_MARK" varchar(1) NULL, "DRUG_PATH" varchar(15) NULL, "DRUG_DAY" varchar(2) NULL, "ARNHPAID" varchar(10) NULL, "ARNHROUT" varchar(4) NULL, "ARDDFLAG" varchar(1) NULL, "PFCATG2" varchar(2) NULL, "ARNHIPCD" varchar(8) NULL, "ARNHPNAM" varchar(32) NULL, "ARNHIREQ" varchar(7) NULL, "ARNHIST" varchar(10) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "HOSP_UUID" varchar(36) NULL, "DRUGFRE_UUID" varchar(44) NULL);'%(schm, OO10K)
notice(createOO)
#execute(createOO)

insrtOO10K="""insert into %s."%s" select o.* from %s."%s"o join nhicd."IDCD_10K"i where "FEE_YM">='201601' and "FEE_YM"<='201906' and "HIST"="ARNHIST";"""%(schm, OO10K, schm, 'tmpl2OO')
notice(insrtOO10K)
#execute(insrtOO10K)

DD10K='tmplDD10K'
createDD = """CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(34) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ID" varchar(10) NULL, "ID_BIRTHDAY" varchar(8) NULL, "GAVE_KIND" varchar(1) NULL, "TRAC_EVEN" varchar(1) NULL, "CARD_SEQ_NO" varchar(4) NULL, "FUNC_TYPE" varchar(2) NULL, "IN_DATE" varchar(8) NULL, "OUT_DATE" varchar(8) NULL, "APPL_BEG_DATE" varchar(8) NULL, "APPL_END_DATE" varchar(8) NULL, "E_BED_DAY" numeric(8) NULL, "S_BED_DAY" numeric(8) NULL, "PRSN_ID" varchar(10) NULL, "DRG_CODE" varchar(5) NULL, "EXT_CODE_1" varchar(6) NULL, "EXT_CODE_2" varchar(6) NULL, "TRAN_CODE" varchar(1) NULL, "ICD9CM_CODE" varchar(8) NULL, "ICD9CM_CODE_1" varchar(8) NULL, "ICD9CM_CODE_2" varchar(8) NULL, "ICD9CM_CODE_3" varchar(8) NULL, "ICD9CM_CODE_4" varchar(8) NULL, "ICD_OP_CODE" varchar(8) NULL, "ICD_OP_CODE_1" varchar(8) NULL, "ICD_OP_CODE_2" varchar(8) NULL, "ICD_OP_CODE_3" varchar(8) NULL, "ICD_OP_CODE_4" varchar(8) NULL, "DIAG_AMT" numeric(8) NULL, "ROOM_AMT" numeric(8) NULL, "MEAL_AMT" numeric(8) NULL, "AMIN_AMT" numeric(8) NULL, "RADO_AMT" numeric(8) NULL, "THRP_AMT" numeric(8) NULL, "SGRY_AMT" numeric(8) NULL, "PHSC_AMT" numeric(8) NULL, "BLOD_AMT" numeric(8) NULL, "HD_AMT" numeric(8) NULL, "ANE_AMT" numeric(8) NULL, "METR_AMT" numeric(8) NULL, "DRUG_AMT" numeric(8) NULL, "DSVC_AMT" numeric(8) NULL, "NRTP_AMT" numeric(8) NULL, "INJT_AMT" numeric(8) NULL, "BABY_AMT" numeric(8) NULL, "CHARG_AMT" numeric(8) NULL, "MED_AMT" numeric(8) NULL, "PART_AMT" numeric(8) NULL, "APPL_AMT" numeric(8) NULL, "EB_APPL30_AMT" numeric(8) NULL, "EB_PART30_AMT" numeric(8) NULL, "EB_APPL60_AMT" numeric(8) NULL, "EB_PART60_AMT" numeric(8) NULL, "EB_APPL61_AMT" numeric(8) NULL, "EB_PART61_AMT" numeric(8) NULL, "SB_APPL30_AMT" numeric(8) NULL, "SB_PART30_AMT" numeric(8) NULL, "SB_APPL90_AMT" numeric(8) NULL, "SB_PART90_AMT" numeric(8) NULL, "SB_APPL180_AMT" numeric(8) NULL, "SB_PART180_AMT" numeric(8) NULL, "SB_APPL181_AMT" numeric(8) NULL, "SB_PART181_AMT" numeric(8) NULL, "PART_MARK" varchar(3) NULL, "ID_SEX" varchar(1) NULL, "EXM_RESULT_DRG_1" varchar(5) NULL, "EXM_RESULT_MDC_1" varchar(2) NULL, "TW_DRGS" varchar(5) NULL, "APPL_CAUSE_MARK" varchar(1) NULL, "TW_DRGS_SUIT_MARK" varchar(1) NULL, "PAT_SOURCE" varchar(1) NULL, "ORDER_NUM" numeric(8) NULL, "BABYBIRD" varchar(8) NULL, "TW_DRGS_PAY_TYPE" varchar(1) NULL, "CHILD_MARK" varchar(1) NULL, "ICD6" varchar(8) NULL, "ICD7" varchar(8) NULL, "ICD8" varchar(8) NULL, "ICD9" varchar(8) NULL, "ICD10" varchar(8) NULL, "ICD11" varchar(8) NULL, "ICD12" varchar(8) NULL, "ICD13" varchar(8) NULL, "ICD14" varchar(8) NULL, "ICD15" varchar(8) NULL, "ICD16" varchar(8) NULL, "ICD17" varchar(8) NULL, "ICD18" varchar(8) NULL, "ICD19" varchar(8) NULL, "ICD20" varchar(8) NULL, "OPD6" varchar(8) NULL, "OPD7" varchar(8) NULL, "OPD8" varchar(8) NULL, "OPD9" varchar(8) NULL, "OPD10" varchar(8) NULL, "OPD11" varchar(8) NULL, "OPD12" varchar(8) NULL, "OPD13" varchar(8) NULL, "OPD14" varchar(8) NULL, "OPD15" varchar(8) NULL, "OPD16" varchar(8) NULL, "OPD17" varchar(8) NULL, "OPD18" varchar(8) NULL, "OPD19" varchar(8) NULL, "OPD20" varchar(8) NULL, "FINKEY" varchar(4) NULL, "BHISTNO" varchar(10) NULL, "BPSECT" varchar(4) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "PRSN_UUID" varchar(36) NULL);"""%(schm, DD10K)	#DROP TABLE if exists %s."%s"; 
notice(createDD)
#execute(createDD)

insrtDD10K="""insert into %s."%s" select o.* from %s."%s"o join nhicd."IDCD_10K"i where "FEE_YM">='201601' and "FEE_YM"<='201906' and "BHISTNO"="ARNHIST";"""%(schm, DD10K, schm, 'tmpl2DD')
notice(insrtDD10K)
#execute(insrtDD10K)

DO10K='tmplDO10K'
createDO="""CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(10) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ORDER_TYPE" varchar(1) NULL, "ORDER_CODE" varchar(12) NULL, "PAY_RATE" numeric(8) NULL, "ORDER_QTY" numeric(8) NULL, "ORDER_PRICE" numeric(10,2) NULL, "ORDER_AMT" numeric(8) NULL, "EXE_S_DATE" varchar(8) NULL, "EXE_E_DATE" varchar(8) NULL, "DRUG_FRE" varchar(22) NULL, "DRUG_PATH" varchar(22) NULL, "TW_DRGS_CALCU" numeric(18) NULL, "CURE_PATH" varchar(47) NULL, "ORDER_SEQ_NO" varchar(5) NULL, "DRUG_USE" varchar(6) NULL, "CON_FUNC_TYPE" varchar(15) NULL, "BED_NO" varchar(15) NULL, "PART_ACCO_DATA" varchar(28) NULL, "BIDNO" varchar(10) NULL, "BOROPTMB" varchar(4) NULL, "BOROPTME" varchar(4) NULL, "PFKEY" varchar(8) NULL, "BHISTNO" varchar(10) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "DRUGFRE_UUID" varchar(44) NULL);"""%(schm, DO10K)
#DROP TABLE if exists %s."%s"; schm, tbl, 
notice(createDO)
#execute(createDO)

insrtDO10K="""insert into %s."%s" select o.* from %s."%s"o join nhicd."IDCD_10K"i where "FEE_YM">='201601' and "FEE_YM"<='201906' and "BHISTNO"="ARNHIST";"""%(schm, DO10K, schm, 'tmpl2DO')
notice(insrtDO10K)
#execute(insrtDO10K)

outputCD="""\copy (select "FEE_YM", "APPL_TYPE", NULL "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "CURE_ITEM_NO1", "CURE_ITEM_NO2", "CURE_ITEM_NO3", "CURE_ITEM_NO4", "FUNC_TYPE", "FUNC_DATE", "TREAT_END_DATE", left("ID_BIRTHDAY",6) "ID_BIRTHDAY", "ID_UUID" "ID", "CARD_SEQ_NO", "GAVE_KIND", "PART_NO", "ACODE_ICD9_1", "ACODE_ICD9_2", "ACODE_ICD9_3", "ICD_OP_CODE", "DRUG_DAY", "MED_TYPE", "PRSN_UUID" "PRSN_ID", "PHAR_UUID" "PHAR_ID", "DRUG_AMT", "TREAT_AMT", "TREAT_CODE", "DIAG_AMT", "DSVC_NO", "DSVC_AMT", "CASE_PAY_CODE", "T_AMT", "PART_AMT", "T_APPL_AMT", "ID_SEX", "TRANIN_UUID" "TRAN_IN_HOSP_ID", "PAT_TRAN_OUT", "APPL_CAUSE_MARK", "ICD_OP_CODE2", "CHR_DAYS", "ARNHIST_UUID" "ARNHIST", "ARNSECT" from %s."%s") to /tmp/CD.csv WITH CSV HEADER;"""%(schm, CD10K)
notice(outputCD)
#execute(outputCD)

outputOO="""\copy (select "FEE_YM", "APPL_TYPE", "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "ORDER_TYPE", "DRUG_NO", "DRUG_USE", case when char_length("DRUGFRE_UUID")=44 then "DRUGFRE_UUID" else "DRUG_FRE" end "DRUG_FRE", "UNIT_PRICE", "TOTAL_QTY", "TOTAL_AMT", "REL_MODE", "EXE_S_DATE", "EXE_E_DATE", "PAY_RATE", "CURE_PATH", "ORDER_SEQ_NO", "CHR_MARK", "DRUG_PATH", "DRUG_DAY", "ID_UUID" "ARNHPAID", "ARNHROUT", "ARDDFLAG", "PFCATG2", "ARNHIPCD", "ARNHPNAM", "ARNHIREQ", "HIST_UUID" "ARNHIST" from %s."%s") to /tmp/OO.csv with(format csv, header);"""%(schm, OO10K)
notice(outputOO)
#execute(outputOO)

outputDD="""\copy (select "FEE_YM", "APPL_TYPE", NULL "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "ID_UUID" "ID", left("ID_BIRTHDAY",6) "ID_BIRTHDAY", "GAVE_KIND", "TRAC_EVEN", "CARD_SEQ_NO", "FUNC_TYPE", "IN_DATE", "OUT_DATE", "APPL_BEG_DATE", "APPL_END_DATE", "E_BED_DAY", "S_BED_DAY", "PRSN_UUID" "PRSN_ID", "DRG_CODE", "EXT_CODE_1", "EXT_CODE_2", "TRAN_CODE", "ICD9CM_CODE", "ICD9CM_CODE_1", "ICD9CM_CODE_2", "ICD9CM_CODE_3", "ICD9CM_CODE_4", "ICD_OP_CODE", "ICD_OP_CODE_1", "ICD_OP_CODE_2", "ICD_OP_CODE_3", "ICD_OP_CODE_4", "DIAG_AMT", "ROOM_AMT", "MEAL_AMT", "AMIN_AMT", "RADO_AMT", "THRP_AMT", "SGRY_AMT", "PHSC_AMT", "BLOD_AMT", "HD_AMT", "ANE_AMT", "METR_AMT", "DRUG_AMT", "DSVC_AMT", "NRTP_AMT", "INJT_AMT", "BABY_AMT", "CHARG_AMT", "MED_AMT", "PART_AMT", "APPL_AMT", "EB_APPL30_AMT", "EB_PART30_AMT", "EB_APPL60_AMT", "EB_PART60_AMT", "EB_APPL61_AMT", "EB_PART61_AMT", "SB_APPL30_AMT", "SB_PART30_AMT", "SB_APPL90_AMT", "SB_PART90_AMT", "SB_APPL180_AMT", "SB_PART180_AMT", "SB_APPL181_AMT", "SB_PART181_AMT", "PART_MARK", "ID_SEX", "EXM_RESULT_DRG_1", "EXM_RESULT_MDC_1", "TW_DRGS", "APPL_CAUSE_MARK", "TW_DRGS_SUIT_MARK", "PAT_SOURCE", "ORDER_NUM", left("BABYBIRD",6) "BABYBIRD", "TW_DRGS_PAY_TYPE", "CHILD_MARK", "ICD6", "ICD7", "ICD8", "ICD9", "ICD10", "ICD11", "ICD12", "ICD13", "ICD14", "ICD15", "ICD16", "ICD17", "ICD18", "ICD19", "ICD20", "OPD6", "OPD7", "OPD8", "OPD9", "OPD10", "OPD11", "OPD12", "OPD13", "OPD14", "OPD15", "OPD16", "OPD17", "OPD18", "OPD19", "OPD20", "FINKEY", "HIST_UUID" "BHISTNO", "BPSECT"from %s."%s" limit 1000)to /tmp/DD.csv with(format csv, header);"""%(schm, DD10K)
notice(outputDD)
#execute(outputDD)

outputDO = """\copy (select "FEE_YM", "APPL_TYPE", NULL "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "ORDER_TYPE", "ORDER_CODE", "PAY_RATE", "ORDER_QTY", "ORDER_PRICE", "ORDER_AMT", "EXE_S_DATE", "EXE_E_DATE", "DRUGFRE_UUID" "DRUG_FRE", "DRUG_PATH", "TW_DRGS_CALCU", "CURE_PATH", "ORDER_SEQ_NO", "DRUG_USE", "CON_FUNC_TYPE", "BED_NO", "PART_ACCO_DATA", "ID_UUID" "BIDNO", "BOROPTMB", "BOROPTME", "PFKEY", "HIST_UUID" "BHISTNO" from %s."%s") to /tmp/DO.csv with(format csv, header);"""%(schm, DO10K)
notice(outputDO)
#execute(outputDO)

$nhicd$ LANGUAGE plpython3u;
