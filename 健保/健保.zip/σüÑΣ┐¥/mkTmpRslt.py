create function "mkTmpRslt"(in "RsltTbl" varchar default 'Rslt2')returns void  AS $report$
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

notice(RsltTbl)
$report$ LANGUAGE plpython3u
