create or replace function "miscRprt"(in "tbl10K" varchar default 'smpl10K', in "dfltSchm" varchar default 'report', in "RsltTbl" varchar default 'RESULT2', in "flshSchm" boolean default false) RETURNS void AS $report$ 
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

schm=dfltSchm if dfltSchm.islower() else '"%s"'%dfltSchm
if flshSchm:
	dropTbl='drop schema if exists %s;'%schm
	notice(dropSchema)
	execute(dropSchema)

createSchema='create schema if not exists %s;'%schm
notice(createSchema)
#execute(createSchema)


mkID="""insert INTO %s."%s" select btrim("PHISTNUM"), btrim("PIDNO"), btrim("PSEX"), btrim("PBIRTHDT"), btrim("PPATZIP"), btrim("PFSTVDT"), btrim("PPBLOOD") from  "PBASINFO" p join "OLAP"."cd10kHIST" c on c."idHIST"=trim(p."PHISTNUM");"""%(schm, tbl10K)
notice(mkID)
#execute(mkID)

select count(distinct "ID") from "OLAP"."newtmplCD_1617";
update "OLAP"."newtmplCD" set "ID_BIRTHDAY"=("ID_BIRTHDAY"::integer+19110000)::varchar;
update "OLAP"."newtmplCD" n set "TRANIN_UUID"=h."tranInHOSP_UUID" from "OLAP"."tranInHOSP" h where n."TRAN_IN_HOSP_ID"=h."tranInHOSP";
update "OLAP"."newtmplCD" n set "PAT_TRAN_OUT"=NULL where "PAT_TRAN_OUT"='N';
TNUM");

mkCD1617="""insert into %s."%s" select c.* from "OLAP"."tmplCD3" c join "OLAP"."cd10kHIST" h on h."idHIST"=c."ARNHIST" where left("FEE_YM",4)in('2016', '2017');"""%(schm, tbl10K)
select "ARNHIST", "ID", "ID_BIRTHDAY" from (select row_number() over (order by "ID_BIRTHDAY")"AID",  f.* from "OLAP"."newtmplCD_1617"f where left("ID_BIRTHDAY",4)='1975') t where t."AID"<=2;
notice(mkCD1617)
#execute(createSchema)

createPthlgy="""create table if not exists %s."%s"(
	"RprtCatgy" varchar(4),
	"HISTNO" varchar(10), 
	"PFKEY" varchar(10),
	"rprtDate" varchar(8),
	"SYMBL" varchar(8),
	"VALUE" varchar(1800)
);"""%(schm, miscTbl)
notice(createPthlgy)
#execute(createPthlgy)

#insrtTbl="""insert into %s."%s" select "RSHISTNO", "RSREQNO", left(regexp_replace("RSTMSTMP"::varchar, '-','','g'), 8) "TMSTMP", "RSRTSYM", "RSVALUE" FROM "%s" where ("RSRTSYM">='RTDIAG01' AND "RSRTSYM" <='RTDIAG12') OR ("RSRTSYM" >='RTDESP01' AND "RSRTSYM" <='RTDESP80');"""%(schm, miscTbl, RsltTbl)
#substr("RSRTSYM",1,6) in('RTDESP','RTDIAG')

insrtTbl="""insert into %s."%s" select "PFCATGY", "RSHISTNO", "RSPFKEY", left(regexp_replace("RSDATE"::varchar, '-','','g'), 8) "rprtDate", "RSRTSYM", "RSVALUE" FROM "%s"inner join "DATA"."PFILE"p on "PFCATGY"<>'' and "RSPFKEY"="PFKEY"and "RSSTATUS">='62' and "RSSTATUS"<='68';"""%(schm, miscTbl, RsltTbl)	# where "RSPFKEY"~'^701' 
notice(insrtTbl)
#execute(insrtTbl)

MiscTbl=miscTbl[0].upper()+miscTbl[1:]
aggMiscTbl='agg'+MiscTbl
if flshSchm:
	dropTbl="""drop table if exists %s."%s";"""%(schm, aggMiscTbl)
	notice(dropTbl)
	#execute(dropTbl)
	
createAgg="""create table if not exists %s."%s"(
	"RprtCatgy" varchar(4),
	"HISTNO" varchar(10), 
	"rprtDate" varchar(8),
	"aggPFKEY" text,
	"aggSYMBL" text,
	"aggVALUE" text
);"""%(schm, aggMiscTbl)
notice(createAgg)
#execute(createAgg)

insrtAgg="""insert into %s."%s" select "RprtCatgy", "HISTNO", "rprtDate", string_agg("PFKEY", '-'order by "PFKEY"), string_agg("SYMBL", '-'order by "SYMBL"),string_agg("VALUE",chr(10))from %s."%s"group by ("RprtCatgy", "HISTNO", "rprtDate" ) order by 1,2,3;"""%(schm, aggMiscTbl, schm, miscTbl)	#-- "SEQCN", "SEQNO", "PFKEY", "SEQCN", "SEQNO", "PFKEY", 
notice(insrtAgg)
#execute(insrtAgg)

annMiscRprt='ann'+MiscTbl
if flshSchm:
	dropAnn="""drop table %s."%s";"""%(schm, annMiscRprt)
	notice(dropAnn)
	execute(dropAnn)

createAnn="""create table if not exists %s."%s"(
	"RprtCatgy" varchar(4),
	"rprtDate" varchar(6),
	"annHISTNO" numeric(5,0),
	"annMiscRprt" numeric(5,0)
);"""%(schm, annMiscRprt)
notice(createAnn)
execute(createAnn)

insrtAnn="""insert into %s."%s" select "RprtCatgy", left(a."rprtDate",  6), count(distinct "HISTNO"), count("aggVALUE")from %s."%s"a group by 1,2 order by 1,2;"""%(schm, annMiscRprt, schm, aggMiscTbl)
notice(insrtAnn)
execute(insrtAnn)

$report$ LANGUAGE plpython3u
