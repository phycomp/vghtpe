create or replace function "dvdLbdtVL"(in "lbdtValue" varchar default 'mrgSymblPfkey') RETURNS void AS $LBDT$ 
#, in "rslt" varchar default 'PfkeySymbl', in "RSLT" varchar default 'pfkeySymbl', in "dfltSchm" varchar default 'isc8381', in "flshSchm" boolean default false)
from plpy import cursor, execute, notice
from sys import exc_info
from re import findall
def lbdtValueRank(lbdtValue):
  lwr, mdl, ppr=[], [], []
  for vlLBDT in findall('([\w|\s]\$\d\d*?\.\d\d*?)', lbdtValue): #(\w\$\d\d*?\.\d\d*?)
      valueRank, value=vlLBDT.split('$')
      if valueRank==' ': mdl.append(value)
      elif valueRank=='H': ppr.append(value)
      elif valueRank=='L': lwr.append(value)
  return lwr, mdl, ppr

$LBDT$ LANGUAGE plpython3u;
