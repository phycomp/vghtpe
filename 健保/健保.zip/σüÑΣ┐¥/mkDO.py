create or replace function "mkDO2"(in tbl varchar default 'tmplDO', in dflt_schm varchar default 'nhicd') RETURNS void AS $nhicd$
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

#tblName=['BILNH92X', 'BILNH93X', 'BILNH94X', 'BILNH95X', 'BILNH96X', 'BILNH97X', 'BILNH98X', 'BILNHI0X', 'BILNHI1X', 'BILNHI2X', 'BILNHI3X', 'BILNHI4X', 'BILNHI7X', 'BILNHI8X', 'BILNHI9X']#'demoBILNHI4X'
tblName=['BILNH92X', 'BILNH93X', 'BILNHT93', 'BILNH94X', 'BILNH94X01', 'BILNH95X', 'BILNH96X', 'BILNH97X', 'BILNH97X01', 'BILNH98X', 'BILNHI0X', 'BILNHI1X', 'BILNHI2X', 'BILNHI3X', 'BILNHI4X', 'BILNHI7X', 'BILNHI8X', 'BILNHI9X', 'BILNHIT1', 'BILNHIT2', 'BILNHIT6', 'BILNHIT9', 'BILNHITX']

annYear=[]
schm=dflt_schm if dflt_schm.islower() else '"%s"'%dflt_schm
notice(schm)
createSchema='create schema if not exists %s;'%schm	#drop schema if exists %s; 
notice(createSchema)
#execute(createSchema)

createDO="""CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(10) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ORDER_TYPE" varchar(1) NULL, "ORDER_CODE" varchar(12) NULL, "PAY_RATE" numeric(8) NULL, "ORDER_QTY" numeric(8) NULL, "ORDER_PRICE" numeric(10,2) NULL, "ORDER_AMT" numeric(8) NULL, "EXE_S_DATE" varchar(8) NULL, "EXE_E_DATE" varchar(8) NULL, "DRUG_FRE" varchar(22) NULL, "DRUG_PATH" varchar(22) NULL, "TW_DRGS_CALCU" numeric(18) NULL, "CURE_PATH" varchar(47) NULL, "ORDER_SEQ_NO" varchar(5) NULL, "DRUG_USE" varchar(6) NULL, "CON_FUNC_TYPE" varchar(15) NULL, "BED_NO" varchar(15) NULL, "PART_ACCO_DATA" varchar(28) NULL, "BIDNO" varchar(10) NULL, "BOROPTMB" varchar(4) NULL, "BOROPTME" varchar(4) NULL, "PFKEY" varchar(8) NULL, "BHISTNO" varchar(10) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "DRUGFRE_UUID" varchar(44) NULL) PARTITION BY RANGE("FEE_YM");"""%(schm, tbl)
#DROP TABLE if exists %s."%s"; schm, tbl, 
notice(createDO)
execute(createDO)

def insrtDO(schm, tbl, tblName):
	try:
		for idx in tblName:
			DOinsert="""insert into %s."%s" select replace("DISYYMM", '''', '')::smallint+191100, trim("BRELAY"), NULL, NULL, trim("BCASEFLG"), trim("SEQNO"), trim("OETYP"), trim("BORNHICD"), "BORPERT", "APPLYUSE", "CORNHPUN", "APPLYAMT", case when trim("CORDATE1")<>'' then "CORDATE1"::integer+19110000 else NULL end, case when trim("CORDATE2")<>'' then "CORDATE2"::integer+19110000 else NULL end, NULL, trim("NHIFREQ"), NULL, NULL, trim("OESEQNO"), trim("BDGDOS"), NULL, NULL, NULL, trim("BIDNO"), trim("BOROPTMB"), trim("BOROPTME"), trim("PFKEY"), NULL from "%s" where "DISYYMM"~'\d{5}' and right("DISYYMM", 2)<='12';"""%(schm, tbl, idx) 
			notice(DOinsert)
			execute(DOinsert)
	except:
		errmsg=exc_info()[1]
		#errmsg.spidata->'spidata', 'sqlstate', 'with_traceback'
		excptMsg=errmsg.spidata[1]
		notice(excptMsg)
		ann=search('\d{4}', excptMsg).group(0)
		annYear.append(ann)
		startVal, endVal='%s01'%ann, '%s13'%ann
		#execute('select a[1] from regexp_match(errmsg2, '\d{4}')a;'
		prttnTbl='CREATE TABLE if not exists %s."%s%s" PARTITION OF %s."%s" FOR VALUES FROM (%s) TO (%s);'%(schm, tbl, ann, schm, tbl, startVal, endVal)
		notice(prttnTbl)
		execute(prttnTbl)
		insrtDO(schm, tbl, tblName)
insrtDO(schm, tbl, tblName)


drugfreTbl='DrugFre'
createDrugFre="""create table if not exists %s."%s"("DRUG_FRE" varchar(10), "DRUGFRE_UUID" varchar(36));"""%(schm, drugfreTbl)
notice(createDrugFre)
execute(createDrugFre)

updateDO = """update  %s."%s" set "DRUG_FRE"="DRUG_PATH";
update  %s."%s" set "DRUG_PATH"=NULL;
update %s."%s" set ("EXE_S_DATE", "EXE_E_DATE")=(case when btrim("EXE_S_DATE")<>'''' then "EXE_S_DATE"::integer+19110000 else NULL end, case when btrim("EXE_E_DATE")<>'''' then "EXE_S_DATE"::integer+19110000 else NULL end);
update %s."%s" set "BHISTNO"="PHISTNUM" from "PBASINFO" where "BIDNO"=trim("PIDNO");
update %s."tmpl2DO"o set "ID_UUID"="UUID" from "MAPPING_PIDNO" where "ID"="PIDNO";
update %s."%s" set "ORDER_PRICE"="ORDER_PRICE"/100.;"""%(schm, tbl, schm, tbl, schm, tbl, schm, tbl, schm, tbl)

updtDO="""insert into nhicd."DrugFre" ("DRUG_FRE") select distinct left(trim(o."DRUG_FRE"),10) from nhicd."tmpl2OO"o where trim("DRUG_FRE")<>'';
update %s."%s"o set "DRUGFRE_UUID" = concat( d."DRUGFRE_UUID", right( o."DRUG_FRE",7) ) from "DrugFre"d where char_length(o."DRUG_FRE")=17 and left(o."DRUG_FRE",10)=d."DRUG_FRE";
"""%(schm, trgtOO, schm, drugfreTbl, schm, trgtOO, schm, )
notice(updtDO)
execute(updtDO)
#update nhicd."DrugFre" set "DRUGFRE_UUID"=uuid_generate_v1() where "DRUG_FRE";
#insert into nhicd."" ("DRUG_FRE","DRUGFRE_UUID")select distinct trim(left(o."DRUG_FRE",10)),uuid_generate_v1() from nhicd."tmpl2OO"o where trim("DRUG_FRE")<>'';
#update "tmplDO10K" set "DRUGFRE_UUID"=d."DRUGFRE_UUID" from "DRUGFRE" d where "DRUGFRE"="DRUG_FRE";
#update %s."%s"set ("DRUG_FRE", "DRUG_USE", "CASE_TYPE", "SEQ_NO", "ORDER_CODE", "CURE_PATH") = (btrim("DRUG_FRE"), btrim("DRUG_USE"), btrim("CASE_TYPE"), btrim("SEQ_NO"), btrim("ORDER_CODE"), btrim("CURE_PATH"));
notice(updateDO)
execute(updateDO)

outputDO = """\copy (select "FEE_YM", "APPL_TYPE", NULL "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "ORDER_TYPE", "ORDER_CODE", "PAY_RATE", "ORDER_QTY", "ORDER_PRICE", "ORDER_AMT", "EXE_S_DATE", "EXE_E_DATE", "DRUGFRE_UUID" "DRUG_FRE", "DRUG_PATH", "TW_DRGS_CALCU", "CURE_PATH", "ORDER_SEQ_NO", "DRUG_USE", "CON_FUNC_TYPE", "BED_NO", "PART_ACCO_DATA", "ID_UUID" "BIDNO", "BOROPTMB", "BOROPTME", "PFKEY", "HIST_UUID" "BHISTNO" from %s."%s" limit 1000) to '/tmp/DO.csv' with(format csv, header);"""%(schm, tbl)
notice(outputDO)
execute(outputDO)

for ann in annYear:
	cmd="""update %s."%s%s"o set ("BHISTNO","HIST_UUID","ID_UUID")=(c."BHISTNO",c."HIST_UUID",c."ID_UUID") from %s."%s%s"c where o."CASE_TYPE"=c."CASE_TYPE"and o."SEQ_NO"=c."SEQ_NO"and o."FEE_YM"=c."FEE_YM";"""%(schm, tbl, ann, schm, tbl, ann)
	notice(cmd)
	execute(cmd)

$nhicd$ LANGUAGE plpython3u;
