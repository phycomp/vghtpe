create or replace function "mkOO3"(in "nhirdTbl" varchar default 'tmpl3OO', in "dfltSchm" varchar default 'nhird', in "flshSchm" boolean default false) RETURNS void AS $nhird$ 
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

tblName=['ORDFAM00', 'ORDFAM01', 'ORDFAM02', 'ORDFAM03', 'ORDFAM04', 'ORDFAM05', 'ORDFAM06', 'ORDFAM07', 'ORDFAM08']#'demoORDFAM07'
annYear=[]
schm=dfltSchm if dfltSchm.islower() else '"%s"'%dfltSchm
notice(schm)
createSchema='create schema if not exists %s;'%schm	#drop schema if exists %s; 
notice(createSchema)
#execute(createSchema)

createOO='DROP TABLE if exists %s."%s" cascade; CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(1) NULL, "APPL_DATE" varchar(1) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ORDER_TYPE" varchar(1) NULL, "DRUG_NO" varchar(12) NULL, "DRUG_USE" numeric(7,2) NULL, "DRUG_FRE" varchar(18) NULL, "UNIT_PRICE" numeric(10,2) NULL, "TOTAL_QTY" numeric(7,1) NULL, "TOTAL_AMT" numeric(9) NULL, "REL_MODE" varchar(1) NULL, "EXE_S_DATE" varchar(16) NULL, "EXE_E_DATE" varchar(16) NULL, "PAY_RATE" varchar(3) NULL, "CURE_PATH" varchar(6) NULL, "ORDER_SEQ_NO" varchar(5) NULL, "CHR_MARK" varchar(1) NULL, "DRUG_PATH" varchar(15) NULL, "DRUG_DAY" varchar(2) NULL, "ARNHPAID" varchar(10) NULL, "ARNHROUT" varchar(4) NULL, "ARDDFLAG" varchar(1) NULL, "PFCATG2" varchar(2) NULL, "ARNHIPCD" varchar(8) NULL, "ARNHPNAM" varchar(32) NULL, "ARNHIREQ" varchar(7) NULL, "ARNHIST" varchar(10) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "HOSP_UUID" varchar(36) NULL, "DRUGFRE_UUID" varchar(44) NULL) PARTITION BY RANGE("FEE_YM");'%(schm, nhirdTbl, schm, nhirdTbl)
notice(createOO)
execute(createOO)

def insrtOO(schm, nhirdTbl, tblName):
	try:
		for idx in tblName:
			insertOO='insert into %s."%s" select "YYYMM"::smallint+191100, "APPLTYP", NULL, NULL, "ARNHMANO", "ARNICNO1", "DDDFLAG", trim("ARNHICD"), "ARNHDOSE", trim("ARNHFQCY"), "ARNHIFE", "ARNHIQTY", "ARNHIPF1", trim("ARNHRX"), NULL, NULL, trim("ARNHADD"), trim("ARNHDENT"), "OESEQNO", "ARNYESNO", NULL, "DRUGDAYS", trim("ARNHPAID"), trim("ARNHROUT"), trim("ARDDFLAG"), trim("PFCATG2"), trim("ARNHIPCD"), trim("ARNHPNAM"), trim("ARNHIREQ"), NULL from "%s";'%(schm, nhirdTbl, idx)
			notice(insertOO)
			execute(insertOO)
	except:
		errmsg=exc_info()[1]
		excptMsg=errmsg.spidata[1]
		notice(excptMsg)	#errmsg.spidata->'spidata', 'sqlstate', 'with_traceback'
		ann=search('\d{4}', excptMsg).group(0)
		annYear.append(ann)
		startVal, endVal='%s01'%ann, '%s13'%ann
		#execute('select a[1] from regexp_match(errmsg2, '\d{4}')a;'
		prttnTbl='CREATE TABLE if not exists %s."%s%s" PARTITION OF %s."%s" FOR VALUES FROM (%s) TO (%s);'%(schm, nhirdTbl, ann, schm, nhirdTbl, startVal, endVal)
		notice(prttnTbl)
		execute(prttnTbl)
		insrtOO(schm, nhirdTbl, tblName)
insrtOO(schm, nhirdTbl, tblName)

updateOO="""update %s."%s" set "ARNHIST"="PHISTNUM" from "PBASINFO" where "ARNHPAID"="PIDNO";
update %s."%s" set "ID_UUID"="UUID" from "MAPPING_PIDNO" where "ARNHPAID"="PIDNO";
update %s."%s" set "DRUG_DAY"="DRUG_DAY"::smallint;
update %s."%s"o set "DRUGFRE_UUID"=concat(d."DRUGFRE_UUID", (right(o."DRUG_FRE",7)::integer+19110000)::varchar) from %s."DrugFre"d where left(o."DRUG_FRE",10)=d."DRUG_FRE"  and o."DRUG_FRE"~'\d{7}';
"""%(schm, nhirdTbl, schm, nhirdTbl, schm, nhirdTbl, schm, nhirdTbl)
#update %s."%s" o set ("ARNHIST","HIST_UUID","ID_UUID")=(i."HIST",i."HIST_UUID",i."ID_UUID") from "OLAP"."fullIDENT5" i where "ARNHPAID"=i."ID";
#update %s."%s" set "DRUGFRE_UUID"=case when char_length("DRUGFRE_UUID")=44 then "DRUGFRE_UUID"else"DRUG_FRE"end;
notice(updateOO)
execute(updateOO)

outputOO="""copy (select "FEE_YM", "APPL_TYPE", "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "ORDER_TYPE", "DRUG_NO", "DRUG_USE", case when char_length("DRUGFRE_UUID")=44 then "DRUGFRE_UUID" else "DRUG_FRE" end "DRUG_FRE", "UNIT_PRICE", "TOTAL_QTY", "TOTAL_AMT", "REL_MODE", "EXE_S_DATE", "EXE_E_DATE", "PAY_RATE", "CURE_PATH", "ORDER_SEQ_NO", "CHR_MARK", "DRUG_PATH", "DRUG_DAY", "ID_UUID" "ARNHPAID", "ARNHROUT", "ARDDFLAG", "PFCATG2", "ARNHIPCD", "ARNHPNAM", "ARNHIREQ", "HIST_UUID" "ARNHIST" from %s."%s" limit 1000) to '/tmp/demoOO.csv' with(format csv, header);"""%(schm, nhirdTbl)
notice(outputOO)
execute(outputOO)

for ann in annYear:
	cmd="""update %s."%s%s"o  set ("ARNHIST","HIST_UUID", "ID_UUID")=(c."ARNHIST",c."ARNHIST_UUID", c."ID_UUID") from nhicd."tmpl2CD%s"c where o."CASE_TYPE"=c."CASE_TYPE"and o."SEQ_NO"=c."SEQ_NO"and o."FEE_YM"=c."FEE_YM";"""%(schm, nhirdTbl, ann, schm, nhirdTbl, ann)
	notice(cmd)
	execute(cmd)
#cmd="""update %s."%s" set "ID_UUID"="UUID" from "MAPPING_PIDNO" where "ARNHPAID"="PIDNO";"""%(schm, nhirdTbl)
#notice(cmd)
#execute(cmd)

$nhird$ LANGUAGE plpython3u
/*
update nhicd."tmpl2OO2011"o  set ("ARNHIST","HIST_UUID")=(c."ARNHIST",c."ARNHIST_UUID") from nhicd."tmpl2CD2011"c where o."CASE_TYPE"=c."CASE_TYPE"and o."SEQ_NO"=c."SEQ_NO"and o."FEE_YM"=c."FEE_YM";
*/
