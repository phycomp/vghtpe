create or replace function "mkPthlgyRprt"(in "pthlgyTbl" varchar default 'PthlgyRprt', in "dfltSchm" varchar default 'report', in "RsltTbl" varchar default 'RESULT2', in "flshSchm" boolean default false) RETURNS void AS $report$ 
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

schm=dfltSchm if dfltSchm.islower() else '"%s"'%dfltSchm
if flshSchm:
	dropSchm='drop schema if exists %s;'%schm
	notice(dropSchm)
	#execute(dropSchm)

createSchema='create schema if not exists %s;'%schm
notice(createSchema)
execute(createSchema)

createPthlgy="""create table if not exists %s."%s"(
	"HISTNO" varchar(10), 
	"REQNO" varchar(10),
	"pthlgyDate" varchar(8),
	"SYMBL" varchar(8),
	"VALUE" varchar(1800)
);"""%(schm, pthlgyTbl)
notice(createPthlgy)
execute(createPthlgy)

#insrtTbl="""insert into %s."%s" select "RSHISTNO", "RSREQNO", left(regexp_replace("RSTMSTMP"::varchar, '-','','g'), 8) "TMSTMP", "RSRTSYM", "RSVALUE" FROM "%s" where ("RSRTSYM">='RTDIAG01' AND "RSRTSYM" <='RTDIAG12') OR ("RSRTSYM" >='RTDESP01' AND "RSRTSYM" <='RTDESP80');"""%(schm, pthlgyTbl, RsltTbl)
#substr("RSRTSYM",1,6) in('RTDESP','RTDIAG')

insrtTbl="""insert into %s."%s" select "RSHISTNO", "RSREQNO", left(regexp_replace("RSDATE"::varchar, '-','','g'), 8) "TMSTMP", "RSRTSYM", "RSVALUE" FROM "%s" where "RSPFKEY"~'^701' and "RSSTATUS">='62' and "RSSTATUS"<='68';"""%(schm, pthlgyTbl, RsltTbl)
notice(insrtTbl)
execute(insrtTbl)

aggPthlgyTbl='agg'+pthlgyTbl
if flshSchm:
	dropTbl="""drop table if exists %s."%s";"""%(schm, aggPthlgyTbl)
	notice(dropTbl)
	execute(dropTbl)
	
createAgg="""create table if not exists %s."%s"(
	"HISTNO" varchar(10), 
	"REQNO" varchar(10),
	"pthlgyDate" varchar(8),
	"SYMBL" text,
	"VALUE" text
);"""%(schm, aggPthlgyTbl)
notice(createAgg)
execute(createAgg)

insrtAgg="""insert into %s."%s" select "HISTNO", "REQNO", "pthlgyDate", string_agg("SYMBL", '-'order by "SYMBL"),string_agg("VALUE",chr(10))from %s."%s"group by ("HISTNO", "REQNO", "pthlgyDate" ) order by 1;"""%(schm, aggPthlgyTbl, schm, pthlgyTbl)	#-- "SEQCN", "SEQNO", "PFKEY", "SEQCN", "SEQNO", "PFKEY", 
notice(insrtAgg)
execute(insrtAgg)

annPthlgyRprt='ann'+pthlgyTbl
if flshSchm:
	dropAnn="""drop table %s."%s";"""%(schm, annPthlgyRprt)
	notice(dropAnn)
	execute(dropAnn)

createAnn="""create table if not exists %s."%s"(
	"pthlgyDate" varchar(6),
	"HISTNO" numeric(10,0),
	"pthlgyRprt" numeric(10,0)
);"""%(schm, annPthlgyRprt)
notice(createAnn)
execute(createAnn)

insrtAnn="""insert into %s."%s" select left(a."pthlgyDate",  6), count(distinct "HISTNO"), count("VALUE")from %s."%s"a group by 1 order by 1;"""%(schm, annPthlgyRprt, schm, aggPthlgyTbl)
notice(insrtAnn)
execute(insrtAnn)

$report$ LANGUAGE plpython3u
