create or replace function "updtBrthdy"(in indate varchar, out outdate varchar) RETURNS varchar AS $nhicd$ 
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

if search('0000', indate):return indate[:4]+'0101'
else: return indate[:7]+'1'

$nhicd$ LANGUAGE plpython3u
