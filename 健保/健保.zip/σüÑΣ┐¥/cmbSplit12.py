CREATE OR REPLACE FUNCTION "cmbSplt12"(IN cmb_strng varchar, OUT first_strng1 varchar, OUT first_strng2 varchar, OUT first_strng3 varchar, OUT first_strng4 varchar, OUT last_strng1 varchar, OUT last_strng2 varchar, OUT last_strng3 varchar, OUT last_strng4 varchar, OUT highMean float4, OUT highStd float4, OUT lowMean float4, OUT lowStd float4) RETURNS record AS $cmbSplt$
from plpy import cursor, execute, notice
from re import search
#from numpy import array, std, mean, float as npfloat
from statistics import mean, stdev
def std_mean(cmb_strng):
	dataInfo=cmb_strng.split('@')
	highLevel, lowLevel=[], []
	for dinfo in dataInfo:
		value, level=dinfo.split('#')[-2:]
		if level=='H':
			try: highLevel.append(float(value))
			except:
				mtchPttrn=search('(\d+\.?\d+)$', value)
				if mtchPttrn:
					value=mtchPttrn.group(1)
					highLevel.append(float(value))
		elif level=='L':
			try: lowLevel.append(float(value))
			except:
				mtchPttrn=search('(\d+\.?\d+)$', value)
				if mtchPttrn:
					value=mtchPttrn.group(1)
					lowLevel.append(float(value))
	#aHigh, aLow=array(highLevel), array(lowLevel)#.astype(npfloat)
	#print(highLevel, lowLevel, aHigh, aLow, mean(aHigh), std(aHigh), mean(aLow), std(aLow))
	highMean, highStd=(mean(highLevel), stdev(highLevel))if len(highLevel)>1 else (None, None)
	lowMean, lowStd=(mean(lowLevel), stdev(lowLevel))if len(lowLevel)>1 else (None, None)
	#highMean, highStd, lowMean, lowStd=map(lambda x:str(x)[:7], (highMean, highStd, lowMean, lowStd))
	return dataInfo[0], dataInfo[-1], highMean, highStd, lowMean, lowStd
	#return dataInfo[0], dataInfo[-1], mean(aHigh), std(aHigh), mean(aLow), std(aLow)
	
def cmb_splt4(cmb_symbl):
	frstStrng, scndStrng, thrdStrng, frthStrng = cmb_symbl.split('#')
	frstStrng = search('RT(\w+?)\d+\w?', frstStrng).group(1)
	scndStrng = search('([12]\d{3}-\d{2}-\d{2})\s.*?', scndStrng).group(0)
	return frstStrng, scndStrng, thrdStrng, frthStrng
firstStrng, lastStrng, highMean, highStd, lowMean, lowStd=std_mean(cmb_strng)
first_strng1, first_strng2, first_strng3, first_strng4=cmb_splt4(firstStrng)
last_strng1, last_strng2, last_strng3, last_strng4=cmb_splt4(lastStrng)
return first_strng1, first_strng2, first_strng3, first_strng4, last_strng1, last_strng2, last_strng3, last_strng4, highMean, highStd, lowMean, lowStd
$cmbSplt$ LANGUAGE plpython3u
