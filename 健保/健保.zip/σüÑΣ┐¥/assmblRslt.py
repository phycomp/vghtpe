create or replace function "mkAssmblSYMBL"(in rslt_tbl varchar default 'RESULT2', in tbl varchar default 'asmIdSymbl', in dflt_schm varchar default 'mdctn', in flsh_schm boolean default false) RETURNS void AS $asmSymbl$
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

schm=dflt_schm if dflt_schm.islower() else '"%s"'%dflt_schm
notice(schm)
if flsh_schm:
	dropSchema='DROP SCHEMA IF EXISTS %s CASCADE;'%schm 
	notice(dropSchema)
	execute(dropSchema)
createSchema='create schema if not exists %s;'%schm
notice(createSchema)
execute(createSchema)

if flsh_schm:
	dropTbl='DROP TABLE IF EXISTS %s."%s" CASCADE;'%(schm, tbl)
	notice(dropTbl)
	execute(dropTbl)

createTbl='create table if not exists %s."%s"( "HISTNO" varchar(10) null, "REFER" varchar(40) null, "UNIT" varchar(12) null, "SYMBL" varchar(8) null, "PFKEY" varchar(8) null, "TMSTMP" timestamp null, "Value" text null, "Level" char(1) null);'%(schm, tbl)
notice(createTbl)
execute(createTbl)

insrtTbl='insert into %s."%s" select distinct r."RSHISTNO", s."PFREFER", s."PFRSUNIT", r."RSRTSYM", r."RSPFKEY", r."RSTMSTMP", r."RSVALUE", r."RSNORMAL" from "%s"r join "PFRSLT"s on s."PFKEY" =r."RSPFKEY" and "PFRSYMBL"="RSRTSYM";'%(schm, tbl, rslt_tbl)
#(select distinct "RSPFKEY" from "RESULT2" where "RSPFKEY"<>'');
notice(insrtTbl)
execute(insrtTbl)

dltTbl="""delete from %s."%s" where "Value"='-' or "REFER"='' or "UNIT"='';"""%(schm, tbl);
notice(dltTbl)
execute(dltTbl)

tbl2='%s2'%tbl
if flsh_schm:
	dropTbl2='drop table if exists %s."%s" cascade;'%(schm, tbl2)
	notice(dropTbl2)
	execute(dropTbl2)

createTbl2="""create table if not exists %s."%s"( "HISTNO" varchar(10) null, "REFER" varchar(40) null, "UNIT" varchar(12) null, "concatValue" text null, "firstSymbl" varchar(8) NULL, "firstDate" varchar(10) NULL, "firstValue" text NULL, "firstLevel" varchar(1) NULL, "lastSymbl" varchar(8) NULL, "lastDate" varchar(10) NULL, "lastValue" text NULL, "lastLevel" varchar(10) NULL, "highMean" float4 NULL, "highStd" float4 NULL, "lowMean" float4 NULL, "lowStd" float4 NULL, "symblValue" jsonb);"""%(schm, tbl2)
notice(createTbl2)
execute(createTbl2)

insrtTbl2="""insert into %s."%s" select "HISTNO", "REFER", lower("UNIT"), string_agg(concat("SYMBL", "PFKEY", '#', "TMSTMP", '#', "Value", '#', "Level"), '@'order by "TMSTMP") "concatValue" from %s."%s" group by 1,2,3 order by 1;"""%(schm, tbl2, schm, tbl)
notice(insrtTbl2)
execute(insrtTbl2)

updateTbl2="""update %s."%s" set("firstSymbl", "firstDate", "firstValue", "firstLevel", "lastSymbl", "lastDate", "lastValue", "lastLevel", "highMean", "highStd", "lowMean", "lowStd") =(select * from "cmbSplt12"("concatValue"));"""%(schm, tbl2)
#first_strng1, first_strng2, first_strng3, first_strng4, last_strng1, last_strng2, last_strng3, last_strng4, highMean, highStd, lowMean, lowStd
notice(updateTbl2)
execute(updateTbl2)
updateTbl2="""update %s."%s" set "symblValue"=json_build_object("firstSymbl", json_build_object('firstDate', "firstDate", 'firstValue', "firstValue", 'firstLevel', "firstLevel", 'lastDate', "lastDate", 'lastValue', "lastValue", 'lastLevel', "lastLevel", 'highMean', "highMean", 'highStd', "highStd", 'lowMean', "lowMean", 'lowStd', "lowStd"));"""%(schm, tbl2)
notice(updateTbl2)
execute(updateTbl2)

tbl3='%s3'%tbl
if flsh_schm:
	dropTbl3='drop table if exists %s."%s";'%(schm, tbl3)
	notice(dropTbl3)
	execute(dropTbl3)

createTbl3='create table if not exists %s."%s"( "HISTNO" varchar(10) null, "comboValue" jsonb);'%(schm, tbl3)
notice(createTbl3)
execute(createTbl3)

insrtTbl3='insert into %s."%s" select "HISTNO", jsonb_agg("symblValue")from %s."%s" group by 1;'%(schm, tbl3, schm, tbl2)
#insrtTbl3="""insert into %s."%s" select "HISTNO", json_object_agg('symblValue', "symblValue")from %s."%s" group by 1;"""%(schm, tbl3, schm, tbl2)
notice(insrtTbl3)
execute(insrtTbl3)

symblTbl="%sAllSymbl"%tbl
if flsh_schm:
	dropAllSymbl="""drop table if exists %s."%s";"""%(schm, symblTbl)
	notice(dropAllSymbl)
	execute(dropAllSymbl)

createAllSymbl="""create table if not exists %s."%s"("allSymbl" varchar(6) null);"""%(schm, symblTbl)
notice(createAllSymbl)
execute(createAllSymbl)

insrtAllSymbl="""insert into %s."%s" select distinct substring("SYMBL", 'RT(\w+)') from %s."%s";"""%(schm, symblTbl, schm, tbl)
notice(insrtAllSymbl)
execute(insrtAllSymbl)

$asmSymbl$ LANGUAGE plpython3u
