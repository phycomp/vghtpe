create or replace function "queryNHICD2"(in "ICD9" varchar default '36232', in "ICD10" varchar default 'H3223', in "reICD10" varchar default 'None', in seqno varchar default '10001', in "dfltSchm" varchar default 'isc8381', in "flshSchm" boolean default false) RETURNS void AS $nhicd$ 
from plpy import cursor, execute, notice
from sys import exc_info
from re import search

def mnpltnICD(icd, mode=None):
	icd=icd.split('|')
	icd=map(lambda x:"'%s'"%x, icd)
	if mode:
		pttrnICD=[]
		for pttrn in icd:
			pttrnICD.append('''"ACODE_ICD9_1"~%s or "ACODE_ICD9_2"~%s or "ACODE_ICD9_3"~%s'''%(pttrn,pttrn,pttrn))
		return 'or'.join(pttrnICD)
	icd=','.join(icd)
	return '''"ACODE_ICD9_1"in(%s) or "ACODE_ICD9_2"in(%s) or "ACODE_ICD9_3"in(%s) '''%(icd,icd,icd)
	#or "ACODE_ICD9_1"in(%s) or "ACODE_ICD9_2"in(%s) or "ACODE_ICD9_3"in(%s) 
#select "queryNHICD"('36231|36232|36235|36236|36263|36511|36560|3659', 'H34231|H34232|H34233', 'H40[3456][0123]|H401[2345][1239]');
schm=dfltSchm if dfltSchm.islower() else '"%s"'%dfltSchm

ICD9Pttrn=mnpltnICD(ICD9)	#','.join(ICD9.split('|'))
notice(ICD9Pttrn)
ICD10Pttrn=mnpltnICD(ICD10)	#,'.join(ICD10.split('|'))
notice(ICD10Pttrn)
reICD10Pttrn=mnpltnICD(reICD10, mode='RE')
notice(reICD10Pttrn)
#ICD9="'36231', '36232', '36235', '36236', '36263', '36511', '36560', '3659'"

#for ann in ['2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019']:
CD, OO='tmpl2CD', 'tmpl2OO'
trgtCD='%s%s'%(CD, seqno)

ageCnstrnt="""("FUNC_DATE"::date-"ID_BIRTHDAY"::date)::int/365>20""" 
crtTrgtCD='CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(10) NULL, "APPL_DATE" varchar(8) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "CURE_ITEM_NO1" varchar(2) NULL, "CURE_ITEM_NO2" varchar(2) NULL, "CURE_ITEM_NO3" varchar(2) NULL, "CURE_ITEM_NO4" varchar(2) NULL, "FUNC_TYPE" varchar(2) NULL, "FUNC_DATE" varchar(8) NULL, "TREAT_END_DATE" varchar(10) NULL, "ID_BIRTHDAY" varchar(8) NULL, "ID" varchar(10) NULL, "CARD_SEQ_NO" varchar(4) NULL, "GAVE_KIND" varchar(1) NULL, "PART_NO" varchar(3) NULL, "ACODE_ICD9_1" varchar(8) NULL, "ACODE_ICD9_2" varchar(8) NULL, "ACODE_ICD9_3" varchar(8) NULL, "ICD_OP_CODE" varchar(8) NULL, "DRUG_DAY" numeric(8) NULL, "MED_TYPE" varchar(1) NULL, "PRSN_ID" varchar(10) NULL, "PHAR_ID" varchar(10) NULL, "DRUG_AMT" numeric(8) NULL, "TREAT_AMT" numeric(8) NULL, "TREAT_CODE" varchar(12) NULL, "DIAG_AMT" numeric(8) NULL, "DSVC_NO" varchar(12) NULL, "DSVC_AMT" numeric(8) NULL, "CASE_PAY_CODE" varchar(2) NULL, "T_AMT" numeric(8) NULL, "PART_AMT" numeric(8) NULL, "T_APPL_AMT" numeric(8) NULL, "ID_SEX" varchar(1) NULL, "TRAN_IN_HOSP_ID" varchar(10) NULL, "PAT_TRAN_OUT" varchar(1) NULL, "APPL_CAUSE_MARK" varchar(1) NULL, "ICD_OP_CODE2" varchar(8) NULL, "CHR_DAYS" varchar(2) NULL, "ARNHIST" varchar(10) NULL, "ARNSECT" varchar(3) NULL, "HOSP_UUID" varchar(36) NULL, "PRSN_UUID" varchar(36) NULL, "PHAR_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "ARNHIST_UUID" varchar(36) NULL, "TRANIN_UUID" varchar(36) NULL) ;'%(schm, trgtCD)
notice(crtTrgtCD)
#execute(crtTrgtCD)

trgtOO='%s%s'%(OO, seqno)
crtTrgtOO='CREATE TABLE if not exists %s."%s" ( "FEE_YM" varchar(6) NULL, "APPL_TYPE" varchar(1) NULL, "HOSP_ID" varchar(1) NULL, "APPL_DATE" varchar(1) NULL, "CASE_TYPE" varchar(2) NULL, "SEQ_NO" varchar(6) NULL, "ORDER_TYPE" varchar(1) NULL, "DRUG_NO" varchar(12) NULL, "DRUG_USE" numeric(7,2) NULL, "DRUG_FRE" varchar(18) NULL, "UNIT_PRICE" numeric(10,2) NULL, "TOTAL_QTY" numeric(7,1) NULL, "TOTAL_AMT" numeric(9) NULL, "REL_MODE" varchar(1) NULL, "EXE_S_DATE" varchar(16) NULL, "EXE_E_DATE" varchar(16) NULL, "PAY_RATE" varchar(3) NULL, "CURE_PATH" varchar(6) NULL, "ORDER_SEQ_NO" varchar(5) NULL, "CHR_MARK" varchar(1) NULL, "DRUG_PATH" varchar(15) NULL, "DRUG_DAY" varchar(2) NULL, "ARNHPAID" varchar(10) NULL, "ARNHROUT" varchar(4) NULL, "ARDDFLAG" varchar(1) NULL, "PFCATG2" varchar(2) NULL, "ARNHIPCD" varchar(8) NULL, "ARNHPNAM" varchar(32) NULL, "ARNHIREQ" varchar(7) NULL, "ARNHIST" varchar(10) NULL, "HIST_UUID" varchar(36) NULL, "ID_UUID" varchar(36) NULL, "HOSP_UUID" varchar(36) NULL, "DRUGFRE_UUID" varchar(44) NULL) ;'%(schm, trgtOO)	#, schm, trgtOO)drop table if exists %s."%s"; 
notice(crtTrgtOO)
#execute(crtTrgtOO)

for ann in range(2011, 2020):
	annCD, annOO='%s%s'%(CD, ann), '%s%s'%(OO, ann)
	CDvsOO="""insert into %s."%s" select distinct c.* from "%s"c inner join "%s" o on c."FEE_YM"=o."FEE_YM" and c."CASE_TYPE"=o."CASE_TYPE" and c."SEQ_NO"=o."SEQ_NO" where %s and c."HOSP_ID"='0601160016' and(%s or %s or %s);"""%(schm, trgtCD, annCD, annOO, ageCnstrnt, ICD9Pttrn, ICD10Pttrn, reICD10Pttrn)
	notice(CDvsOO)
	#"ICD9CM_CODE_2"~'H40[3456][0123]' and "ICD9CM_CODE_3"~'H40[3456][0123]' 
	#execute(CDvsOO)
	CDvsOO="""insert into %s."%s" select distinct o.* from "%s"c inner join "%s" o on c."FEE_YM"=o."FEE_YM" and c."CASE_TYPE"=o."CASE_TYPE" and c."SEQ_NO"=o."SEQ_NO" where %s and c."HOSP_ID"='0601160016' and (%s or %s or %s);"""%(schm, trgtOO, annCD, annOO, ageCnstrnt, ICD9Pttrn, ICD10Pttrn, reICD10Pttrn)	
	notice(CDvsOO)
	#execute(CDvsOO)

outputCD="""\copy (select "FEE_YM", "APPL_TYPE", NULL "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "CURE_ITEM_NO1", "CURE_ITEM_NO2", "CURE_ITEM_NO3", "CURE_ITEM_NO4", "FUNC_TYPE", "FUNC_DATE", "TREAT_END_DATE", left("ID_BIRTHDAY",6) "ID_BIRTHDAY", "ID_UUID" "ID", "CARD_SEQ_NO", "GAVE_KIND", "PART_NO", "ACODE_ICD9_1", "ACODE_ICD9_2", "ACODE_ICD9_3", "ICD_OP_CODE", "DRUG_DAY", "MED_TYPE", "PRSN_UUID" "PRSN_ID", "PHAR_UUID" "PHAR_ID", "DRUG_AMT", "TREAT_AMT", "TREAT_CODE", "DIAG_AMT", "DSVC_NO", "DSVC_AMT", "CASE_PAY_CODE", "T_AMT", "PART_AMT", "T_APPL_AMT", "ID_SEX", "TRANIN_UUID" "TRAN_IN_HOSP_ID", "PAT_TRAN_OUT", "APPL_CAUSE_MARK", "ICD_OP_CODE2", "CHR_DAYS", "ARNHIST_UUID" "ARNHIST", "ARNSECT" from %s."%s") to /tmp/%s.csv with(format csv, header);"""%(schm, trgtCD, trgtCD)
notice(outputCD)
#execute(outputCD)

outputOO="""\copy (select "FEE_YM", "APPL_TYPE", "HOSP_ID", "APPL_DATE", "CASE_TYPE", "SEQ_NO", "ORDER_TYPE", "DRUG_NO", "DRUG_USE", case when char_length("DRUGFRE_UUID")=44 then "DRUGFRE_UUID" else "DRUG_FRE" end "DRUG_FRE", "UNIT_PRICE", "TOTAL_QTY", "TOTAL_AMT", "REL_MODE", "EXE_S_DATE", "EXE_E_DATE", "PAY_RATE", "CURE_PATH", "ORDER_SEQ_NO", "CHR_MARK", "DRUG_PATH", "DRUG_DAY", "ID_UUID" "ARNHPAID", "ARNHROUT", "ARDDFLAG", "PFCATG2", "ARNHIPCD", "ARNHPNAM", "ARNHIREQ", "HIST_UUID" "ARNHIST" from %s."%s") to /tmp/%s.csv with(format csv, header);"""%(schm, trgtOO, trgtOO)
notice(outputOO)
#execute(outputOO)

$nhicd$ LANGUAGE plpython3u
