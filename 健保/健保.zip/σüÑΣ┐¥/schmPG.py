#!/usr/bin/env python
from subprocess import Popen, PIPE, run
from re import DOTALL, findall
from sys import argv
from os import system

tbl=argv[1]
cmd='pg_dump -U postgres postgres -t "%s" --schema-only'%tbl
out=Popen(cmd.split(), stdout=PIPE, stderr=PIPE)
dout, derr=out.stdout.read(), out.stderr.read()
output=findall('CREATE TABLE.*?;', dout.decode('utf-8'), DOTALL)[0]
fname='demo%s'%tbl
mkTbl=output.replace(tbl, fname).replace('CREATE TABLE', 'CREATE TABLE if not exists')
fout=open('%s.sql'%fname, 'w')
fout.write(mkTbl)
cmd="psql -X -U postgres postgres -f %s.sql"%fname
print(cmd)
#out=Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
run(cmd.split(), capture_output=True)#shell=True, check=True, 
#Popen.check_output()
#dout, derr=out.stdout.read(), out.stderr.read()
#output=findall('CREATE TABLE.*?;', dout.decode('utf-8'), DOTALL)[0]
#print(dout, derr)
