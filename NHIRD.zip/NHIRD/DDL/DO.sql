DROP TABLE "OLAP"."DO";
CREATE TABLE "OLAP"."DO" ("CASE_TYPE" character varying(2) COLLATE pg_catalog."default",
"APPL_TYPE" character varying(1) COLLATE pg_catalog."default",
"SEQ_NO" character varying(6) COLLATE pg_catalog."default",
"BIDNO" character varying(36) COLLATE pg_catalog."default",
"OESEQNO" character varying(5) COLLATE pg_catalog."default",
"ORDER_TYPE" character varying(1) COLLATE pg_catalog."default",
"ORDER_CODE" character varying(12) COLLATE pg_catalog."default",
"PAY_RATE" numeric(8,0),
"BDGDOS" character varying(6) COLLATE pg_catalog."default",
"DRUG_PATH" character varying(22) COLLATE pg_catalog."default",
"BOROPTMB" character varying(4) COLLATE pg_catalog."default",
"BOROPTME" character varying(4) COLLATE pg_catalog."default",
"ORDER_QTY" numeric(8,0),
"AA0" character varying(1) COLLATE pg_catalog."default",
"ORDER_PRICE" numeric(8,0),
"ORDER_AMT" numeric(8,0),
"PFKEY" character varying(8) COLLATE pg_catalog."default",
"BXLPARNO" character varying(2) COLLATE pg_catalog."default",
"FEE_YM" character varying(6) COLLATE pg_catalog."default",
"EXE_S_DATE" character varying(8) COLLATE pg_catalog."default",
"EXE_E_DATE" character varying(8) COLLATE pg_catalog."default"
)
WITH ( OIDS = FALSE)
TABLESPACE pg_default;
ALTER TABLE "OLAP"."DO" OWNER to trinity;
COMMENT ON COLUMN "OLAP"."DO"."CASE_TYPE" IS '案件分類';
COMMENT ON COLUMN "OLAP"."DO"."APPL_TYPE" IS '申報類別';
COMMENT ON COLUMN "OLAP"."DO"."SEQ_NO" IS '流水號';
COMMENT ON COLUMN "OLAP"."DO"."ORDER_TYPE" IS '醫令類別';
COMMENT ON COLUMN "OLAP"."DO"."ORDER_CODE" IS '醫令代碼';
COMMENT ON COLUMN "OLAP"."DO"."PAY_RATE" IS '支付成數';
COMMENT ON COLUMN "OLAP"."DO"."DRUG_PATH" IS '給藥途徑/作用部位';
COMMENT ON COLUMN "OLAP"."DO"."ORDER_QTY" IS '醫令數量';
COMMENT ON COLUMN "OLAP"."DO"."ORDER_PRICE" IS '醫令單價';
COMMENT ON COLUMN "OLAP"."DO"."ORDER_AMT" IS '醫令點數';
COMMENT ON COLUMN "OLAP"."DO"."FEE_YM" IS '費用年月';
COMMENT ON COLUMN "OLAP"."DO"."EXE_S_DATE" IS '執行起日';
COMMENT ON COLUMN "OLAP"."DO"."EXE_E_DATE" IS '執行迄日';
