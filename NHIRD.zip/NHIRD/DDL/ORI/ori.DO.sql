-- Table: "OLAP"."ori.DO"
-- DROP TABLE "OLAP"."ori.DO";
CREATE TABLE "OLAP"."ori.DO"
(
    "FEE_YM" character varying(6) COLLATE pg_catalog."default",
    "APPL_TYPE" character varying(1) COLLATE pg_catalog."default",
    "HOSP_ID" character varying(34) COLLATE pg_catalog."default",
    "APPL_DATE" character varying(8) COLLATE pg_catalog."default",
    "CASE_TYPE" character varying(2) COLLATE pg_catalog."default",
    "SEQ_NO" numeric(6,0),
    "ORDER_TYPE" character varying(1) COLLATE pg_catalog."default",
    "ORDER_CODE" character varying(12) COLLATE pg_catalog."default",
    "EXE_S_DATE" character varying(16) COLLATE pg_catalog."default",
    "EXE_E_DATE" character varying(16) COLLATE pg_catalog."default",
    "PAY_RATE" numeric(10,0),
    "ORDER_QTY" numeric(7,0),
    "ORDER_PRICE" numeric(10,0),
    "ORDER_AMT" numeric(8,0),
    "DRUG_FRE" character varying(18) COLLATE pg_catalog."default",
    "DRUG_PATH" character varying(4) COLLATE pg_catalog."default",
    "TW_DRGS_CALCU" numeric(18,0),
    "CURE_PATH" character varying(47) COLLATE pg_catalog."default",
    "ORDER_SEQ_NO" numeric(5,0),
    "RATE_TYPE" numeric(4,0)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;
ALTER TABLE "OLAP"."ori.DO" OWNER to trinity;
COMMENT ON TABLE "OLAP"."ori.DO" IS '健保-住院醫療費用醫令清單明細檔';
COMMENT ON COLUMN "OLAP"."ori.DO"."FEE_YM" IS '費用年月';
COMMENT ON COLUMN "OLAP"."ori.DO"."APPL_TYPE" IS '申報類別';
COMMENT ON COLUMN "OLAP"."ori.DO"."HOSP_ID" IS '醫事機構代號';
COMMENT ON COLUMN "OLAP"."ori.DO"."APPL_DATE" IS '申報日期';
COMMENT ON COLUMN "OLAP"."ori.DO"."CASE_TYPE" IS '案件分類';
COMMENT ON COLUMN "OLAP"."ori.DO"."SEQ_NO" IS '流水號';
COMMENT ON COLUMN "OLAP"."ori.DO"."ORDER_TYPE" IS '醫令類別';
COMMENT ON COLUMN "OLAP"."ori.DO"."ORDER_CODE" IS '醫令代碼';
COMMENT ON COLUMN "OLAP"."ori.DO"."EXE_S_DATE" IS '執行起日';
COMMENT ON COLUMN "OLAP"."ori.DO"."EXE_E_DATE" IS '執行迄日';
COMMENT ON COLUMN "OLAP"."ori.DO"."PAY_RATE" IS '支付成數';
COMMENT ON COLUMN "OLAP"."ori.DO"."ORDER_QTY" IS '醫令數量';
COMMENT ON COLUMN "OLAP"."ori.DO"."ORDER_PRICE" IS '醫令單價';
COMMENT ON COLUMN "OLAP"."ori.DO"."ORDER_AMT" IS '醫令點數';
COMMENT ON COLUMN "OLAP"."ori.DO"."DRUG_FRE" IS '藥品使用頻率';
COMMENT ON COLUMN "OLAP"."ori.DO"."DRUG_PATH" IS '給藥途徑/作用部位';
COMMENT ON COLUMN "OLAP"."ori.DO"."TW_DRGS_CALCU" IS 'Tw-DRGs計算';
COMMENT ON COLUMN "OLAP"."ori.DO"."CURE_PATH" IS '診療之部位';
COMMENT ON COLUMN "OLAP"."ori.DO"."ORDER_SEQ_NO" IS '醫令序號';
COMMENT ON COLUMN "OLAP"."ori.DO"."RATE_TYPE" IS '支付成數';
