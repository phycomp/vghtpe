-- Table: "OLAP"."ori.OO"
-- DROP TABLE "OLAP"."ori.OO";
CREATE TABLE "OLAP"."ori.OO"
(
    "FEE_YM" character varying(6) COLLATE pg_catalog."default",
    "APPL_TYPE" character varying(1) COLLATE pg_catalog."default",
    "HOSP_ID" character varying(34) COLLATE pg_catalog."default",
    "APPL_DATE" character varying(8) COLLATE pg_catalog."default",
    "CASE_TYPE" character varying(2) COLLATE pg_catalog."default",
    "SEQ_numeric(O" numeric(6,0),
    "ORDER_TYPE" character varying(1) COLLATE pg_catalog."default",
    "DRUG_numeric(O" character varying(12) COLLATE pg_catalog."default",
    "DRUG_FRE" character varying(18) COLLATE pg_catalog."default",
    "Unumeric(IT_PRICE" numeric(10,0),
    "TOTAL_QTY" numeric(7,0),
    "TOTAL_AMT" numeric(8,0),
    "ORDER_SEQ_numeric(O" numeric(5,0),
    "DRUG_USE" character varying(9) COLLATE pg_catalog."default",
    "REL_MODE" character varying(1) COLLATE pg_catalog."default",
    "EXE_S_DATE" character varying(16) COLLATE pg_catalog."default",
    "EXE_E_DATE" character varying(16) COLLATE pg_catalog."default",
    "PAY_RATE" numeric(10,0),
    "CURE_PATH" character varying(30) COLLATE pg_catalog."default"
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;
ALTER TABLE "OLAP"."ori.OO" OWNER to trinity;
COMMENT ON TABLE "OLAP"."ori.OO" IS '門診處方醫令明細檔';
COMMENT ON COLUMN "OLAP"."ori.OO"."FEE_YM" IS '費用年月';
COMMENT ON COLUMN "OLAP"."ori.OO"."APPL_TYPE" IS '申報類別';
COMMENT ON COLUMN "OLAP"."ori.OO"."HOSP_ID" IS '醫事機構代號';
COMMENT ON COLUMN "OLAP"."ori.OO"."APPL_DATE" IS '申報日期';
COMMENT ON COLUMN "OLAP"."ori.OO"."CASE_TYPE" IS '案件分類';
COMMENT ON COLUMN "OLAP"."ori.OO"."SEQ_numeric(O" IS '流水號';
COMMENT ON COLUMN "OLAP"."ori.OO"."ORDER_TYPE" IS '醫令類別';
COMMENT ON COLUMN "OLAP"."ori.OO"."DRUG_numeric(O" IS '葯品(項目)代號';
COMMENT ON COLUMN "OLAP"."ori.OO"."DRUG_FRE" IS '葯品使用頻率';
COMMENT ON COLUMN "OLAP"."ori.OO"."Unumeric(IT_PRICE" IS '單價';
COMMENT ON COLUMN "OLAP"."ori.OO"."TOTAL_QTY" IS '總量';
COMMENT ON COLUMN "OLAP"."ori.OO"."TOTAL_AMT" IS '點數';
COMMENT ON COLUMN "OLAP"."ori.OO"."ORDER_SEQ_numeric(O" IS '醫令序號';
COMMENT ON COLUMN "OLAP"."ori.OO"."DRUG_USE" IS '葯品用量';
COMMENT ON COLUMN "OLAP"."ori.OO"."REL_MODE" IS '調劑方式';
COMMENT ON COLUMN "OLAP"."ori.OO"."EXE_S_DATE" IS '執行時間-起';
COMMENT ON COLUMN "OLAP"."ori.OO"."EXE_E_DATE" IS '執行時間-迄';
COMMENT ON COLUMN "OLAP"."ori.OO"."PAY_RATE" IS '支付成數';
COMMENT ON COLUMN "OLAP"."ori.OO"."CURE_PATH" IS '診療之部位';
