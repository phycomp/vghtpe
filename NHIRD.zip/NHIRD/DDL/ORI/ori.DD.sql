-- Table: "OLAP"."ori.DD"
-- DROP TABLE "OLAP"."ori.DD";
CREATE TABLE "OLAP"."ori.DD"
(
    "FEE_YM" character varying(6) COLLATE pg_catalog."default",
    "APPL_TYPE" character varying(1) COLLATE pg_catalog."default",
    "HOSP_ID" character varying(34) COLLATE pg_catalog."default",
    "APPL_DATE" character varying(8) COLLATE pg_catalog."default",
    "CASE_TYPE" character varying(2) COLLATE pg_catalog."default",
    "SEQ_NO" numeric(6,0),
    "ID" character varying(32) COLLATE pg_catalog."default",
    "APPL_BEG_DATE" character varying(8) COLLATE pg_catalog."default",
    "APPL_END_DATE" character varying(8) COLLATE pg_catalog."default",
    "ID_BIRTHDAY" character varying(8) COLLATE pg_catalog."default",
    "GAVE_KIND" character varying(1) COLLATE pg_catalog."default",
    "TRAC_EVEN" character varying(1) COLLATE pg_catalog."default",
    "CARD_SEQ_NO" character varying(4) COLLATE pg_catalog."default",
    "FUNC_TYPE" character varying(2) COLLATE pg_catalog."default",
    "IN_DATE" character varying(8) COLLATE pg_catalog."default",
    "OUT_DATE" character varying(8) COLLATE pg_catalog."default",
    "E_BED_DAY" numeric(3,0),
    "S_BED_DAY" numeric(3,0),
    "PRSN_ID" character varying(32) COLLATE pg_catalog."default",
    "DRG_CODE" character varying(5) COLLATE pg_catalog."default",
    "EXT_CODE_1" character varying(15) COLLATE pg_catalog."default",
    "EXT_CODE_2" character varying(15) COLLATE pg_catalog."default",
    "TRAN_CODE" character varying(1) COLLATE pg_catalog."default",
    "ICD9CM_CODE" character varying(15) COLLATE pg_catalog."default",
    "ICD9CM_CODE_1" character varying(15) COLLATE pg_catalog."default",
    "ICD9CM_CODE_2" character varying(15) COLLATE pg_catalog."default",
    "ICD9CM_CODE_3" character varying(15) COLLATE pg_catalog."default",
    "ICD9CM_CODE_4" character varying(15) COLLATE pg_catalog."default",
    "ICD_OP_CODE" character varying(15) COLLATE pg_catalog."default",
    "ICD_OP_CODE_1" character varying(15) COLLATE pg_catalog."default",
    "ICD_OP_CODE_2" character varying(15) COLLATE pg_catalog."default",
    "ICD_OP_CODE_3" character varying(15) COLLATE pg_catalog."default",
    "ICD_OP_CODE_4" character varying(15) COLLATE pg_catalog."default",
    "DIAG_AMT" numeric(7,0),
    "ROOM_AMT" numeric(7,0),
    "MEAL_AMT" numeric(7,0),
    "AMIN_AMT" numeric(7,0),
    "RADO_AMT" numeric(7,0),
    "THRP_AMT" numeric(7,0),
    "SGRY_AMT" numeric(7,0),
    "PHSC_AMT" numeric(7,0),
    "HD_AMT" numeric(7,0),
    "BLOD_AMT" numeric(7,0),
    "ANE_AMT" numeric(7,0),
    "METR_AMT" numeric(7,0),
    "DRUG_AMT" numeric(7,0),
    "DSVC_AMT" numeric(7,0),
    "NRTP_AMT" numeric(7,0),
    "INJT_AMT" numeric(7,0),
    "BABY_AMT" numeric(7,0),
    "CHARG_AMT" numeric(7,0),
    "MED_AMT" numeric(8,0),
    "PART_AMT" numeric(7,0),
    "APPL_AMT" numeric(8,0),
    "EB_APPL30_AMT" numeric(8,0),
    "EB_PART30_AMT" numeric(7,0),
    "EB_APPL60_AMT" numeric(8,0),
    "EB_PART60_AMT" numeric(7,0),
    "EB_APPL61_AMT" numeric(8,0),
    "EB_PART61_AMT" numeric(7,0),
    "SB_APPL30_AMT" numeric(8,0),
    "SB_PART30_AMT" numeric(7,0),
    "SB_APPL90_AMT" numeric(8,0),
    "SB_PART90_AMT" numeric(7,0),
    "SB_APPL180_AMT" numeric(8,0),
    "SB_PART180_AMT" numeric(7,0),
    "SB_APPL181_AMT" numeric(8,0),
    "SB_PART181_AMT" numeric(7,0),
    "PART_MARK" character varying(3) COLLATE pg_catalog."default",
    "ID_SEX" character varying(1) COLLATE pg_catalog."default",
    "EXM_RESULT_DRG_1" character varying(5) COLLATE pg_catalog."default",
    "EXM_RESULT_MDC_1" character varying(2) COLLATE pg_catalog."default",
    "TW_DRGS" character varying(5) COLLATE pg_catalog."default",
    "APPL_CAUSE_MARK" character varying(1) COLLATE pg_catalog."default",
    "TW_DRGS_SUIT_MARK" character varying(1) COLLATE pg_catalog."default"
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;
ALTER TABLE "OLAP"."ori.DD" OWNER to trinity;
COMMENT ON TABLE "OLAP"."ori.DD" IS '健保-住院醫療費用清單明細檔';
COMMENT ON COLUMN "OLAP"."ori.DD"."FEE_YM" IS '費用年月';
COMMENT ON COLUMN "OLAP"."ori.DD"."APPL_TYPE" IS '申報類別';
COMMENT ON COLUMN "OLAP"."ori.DD"."HOSP_ID" IS '醫事機構代號';
COMMENT ON COLUMN "OLAP"."ori.DD"."APPL_DATE" IS '申報日期';
COMMENT ON COLUMN "OLAP"."ori.DD"."CASE_TYPE" IS '案件分類';
COMMENT ON COLUMN "OLAP"."ori.DD"."SEQ_NO" IS '流水號';
COMMENT ON COLUMN "OLAP"."ori.DD"."ID" IS '身分證統一編號';
COMMENT ON COLUMN "OLAP"."ori.DD"."APPL_BEG_DATE" IS '申報期間-起';
COMMENT ON COLUMN "OLAP"."ori.DD"."APPL_END_DATE" IS '申報期間-迄';
COMMENT ON COLUMN "OLAP"."ori.DD"."ID_BIRTHDAY" IS '出生年月';
COMMENT ON COLUMN "OLAP"."ori.DD"."GAVE_KIND" IS '給付類別';
COMMENT ON COLUMN "OLAP"."ori.DD"."TRAC_EVEN" IS '汽車交通事故';
COMMENT ON COLUMN "OLAP"."ori.DD"."CARD_SEQ_NO" IS '就醫序號';
COMMENT ON COLUMN "OLAP"."ori.DD"."FUNC_TYPE" IS '就醫科別';
COMMENT ON COLUMN "OLAP"."ori.DD"."IN_DATE" IS '入院年月日';
COMMENT ON COLUMN "OLAP"."ori.DD"."OUT_DATE" IS '出院年月日';
COMMENT ON COLUMN "OLAP"."ori.DD"."E_BED_DAY" IS '急性病床天數';
COMMENT ON COLUMN "OLAP"."ori.DD"."S_BED_DAY" IS '慢性病床天數';
COMMENT ON COLUMN "OLAP"."ori.DD"."PRSN_ID" IS '主治醫師代碼';
COMMENT ON COLUMN "OLAP"."ori.DD"."DRG_CODE" IS 'DRG參考碼';
COMMENT ON COLUMN "OLAP"."ori.DD"."EXT_CODE_1" IS '外因分類一';
COMMENT ON COLUMN "OLAP"."ori.DD"."EXT_CODE_2" IS '外因分類二';
COMMENT ON COLUMN "OLAP"."ori.DD"."TRAN_CODE" IS '轉歸代碼';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD9CM_CODE" IS '主診斷代碼';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD9CM_CODE_1" IS '次診斷代碼一';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD9CM_CODE_2" IS '次診斷代碼二';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD9CM_CODE_3" IS '次診斷代碼三';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD9CM_CODE_4" IS '次診斷代碼四';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD_OP_CODE" IS '主手術（處置）';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD_OP_CODE_1" IS '主手術（處置）一';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD_OP_CODE_2" IS '主手術（處置）二';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD_OP_CODE_3" IS '主手術（處置）三';
COMMENT ON COLUMN "OLAP"."ori.DD"."ICD_OP_CODE_4" IS '主手術（處置）四';
COMMENT ON COLUMN "OLAP"."ori.DD"."DIAG_AMT" IS '診察費';
COMMENT ON COLUMN "OLAP"."ori.DD"."ROOM_AMT" IS '病房費';
COMMENT ON COLUMN "OLAP"."ori.DD"."MEAL_AMT" IS '管灌膳食費';
COMMENT ON COLUMN "OLAP"."ori.DD"."AMIN_AMT" IS '檢查費';
COMMENT ON COLUMN "OLAP"."ori.DD"."RADO_AMT" IS '放射線診療費';
COMMENT ON COLUMN "OLAP"."ori.DD"."THRP_AMT" IS '治療處置費';
COMMENT ON COLUMN "OLAP"."ori.DD"."SGRY_AMT" IS '手術費';
COMMENT ON COLUMN "OLAP"."ori.DD"."PHSC_AMT" IS '復健治療費';
COMMENT ON COLUMN "OLAP"."ori.DD"."HD_AMT" IS '血液透析費';
COMMENT ON COLUMN "OLAP"."ori.DD"."BLOD_AMT" IS '血液血漿費';
COMMENT ON COLUMN "OLAP"."ori.DD"."ANE_AMT" IS '麻醉費';
COMMENT ON COLUMN "OLAP"."ori.DD"."METR_AMT" IS '特殊材料費';
COMMENT ON COLUMN "OLAP"."ori.DD"."DRUG_AMT" IS '葯費';
COMMENT ON COLUMN "OLAP"."ori.DD"."DSVC_AMT" IS '葯事服務費';
COMMENT ON COLUMN "OLAP"."ori.DD"."NRTP_AMT" IS '精神科治療費';
COMMENT ON COLUMN "OLAP"."ori.DD"."INJT_AMT" IS '注射技術費';
COMMENT ON COLUMN "OLAP"."ori.DD"."BABY_AMT" IS '嬰兒費';
COMMENT ON COLUMN "OLAP"."ori.DD"."CHARG_AMT" IS '代辦費';
COMMENT ON COLUMN "OLAP"."ori.DD"."MED_AMT" IS '醫療費用';
COMMENT ON COLUMN "OLAP"."ori.DD"."PART_AMT" IS '部份負擔點數';
COMMENT ON COLUMN "OLAP"."ori.DD"."APPL_AMT" IS '申請費用點數';
COMMENT ON COLUMN "OLAP"."ori.DD"."EB_APPL30_AMT" IS '醫療費用點數(急性病床1至30天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."EB_PART30_AMT" IS '部份負擔點數(急性病床1至30天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."EB_APPL60_AMT" IS '醫療費用點數(急性病床31至60天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."EB_PART60_AMT" IS '部份負擔點數(急性病床31至60天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."EB_APPL61_AMT" IS '醫療費用點數(急性病床61天以上)';
COMMENT ON COLUMN "OLAP"."ori.DD"."EB_PART61_AMT" IS '部份負擔點數(急性病床61天以上)';
COMMENT ON COLUMN "OLAP"."ori.DD"."SB_APPL30_AMT" IS '醫療費用點數(慢性病床1至30天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."SB_PART30_AMT" IS '部份負擔點數(慢性病床1至30天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."SB_APPL90_AMT" IS '醫療費用點數(慢性病床31至90天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."SB_PART90_AMT" IS '部份負擔點數(慢性病床31至90天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."SB_APPL180_AMT" IS '醫療費用點數(慢性病床91至180天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."SB_PART180_AMT" IS '部份負擔點數(慢性病床91至180天)';
COMMENT ON COLUMN "OLAP"."ori.DD"."SB_APPL181_AMT" IS '醫療費用點數(慢性病床181天以上)';
COMMENT ON COLUMN "OLAP"."ori.DD"."SB_PART181_AMT" IS '部份負擔點數(慢性病床181天以上)';
COMMENT ON COLUMN "OLAP"."ori.DD"."PART_MARK" IS '部份負擔註記';
COMMENT ON COLUMN "OLAP"."ori.DD"."ID_SEX" IS '性別';
COMMENT ON COLUMN "OLAP"."ori.DD"."EXM_RESULT_DRG_1" IS '審核結果DRG';
COMMENT ON COLUMN "OLAP"."ori.DD"."EXM_RESULT_MDC_1" IS '審核結果MDC';
COMMENT ON COLUMN "OLAP"."ori.DD"."TW_DRGS" IS 'TW_DRGS碼';
COMMENT ON COLUMN "OLAP"."ori.DD"."APPL_CAUSE_MARK" IS '補報原因註記';
COMMENT ON COLUMN "OLAP"."ori.DD"."TW_DRGS_SUIT_MARK" IS '不適用Tw-DRGs案件特殊註記';
