-- Table: "OLAP"."ori.CD"
-- DROP TABLE "OLAP"."ori.CD";
CREATE TABLE "OLAP"."ori.CD"
(
    "FEE_YM" character varying(6) COLLATE pg_catalog."default",
    "APPL_TYPE" character varying(1) COLLATE pg_catalog."default",
    "HOSP_ID" character varying(34) COLLATE pg_catalog."default",
    "APPL_DATE" character varying(8) COLLATE pg_catalog."default",
    "CASE_TYPE" character varying(2) COLLATE pg_catalog."default",
    "SEQ_NO" numeric(6,0),
    "CURE_ITEM_NO1" character varying(2) COLLATE pg_catalog."default",
    "CURE_ITEM_NO2" character varying(2) COLLATE pg_catalog."default",
    "CURE_ITEM_NO3" character varying(2) COLLATE pg_catalog."default",
    "CURE_ITEM_NO4" character varying(2) COLLATE pg_catalog."default",
    "FUNC_TYPE" character varying(2) COLLATE pg_catalog."default",
    "FUNC_DATE" character varying(8) COLLATE pg_catalog."default",
    "TREAT_END_DATE" character varying(8) COLLATE pg_catalog."default",
    "ID_BIRTHDAY" character varying(8) COLLATE pg_catalog."default",
    "ID" character varying(32) COLLATE pg_catalog."default",
    "CARD_SEQ_NO" character varying(4) COLLATE pg_catalog."default",
    "GAVE_KIND" character varying(1) COLLATE pg_catalog."default",
    "PART_NO" character varying(3) COLLATE pg_catalog."default",
    "ACODE_ICD9_1" character varying(5) COLLATE pg_catalog."default",
    "ACODE_ICD9_2" character varying(5) COLLATE pg_catalog."default",
    "ACODE_ICD9_3" character varying(5) COLLATE pg_catalog."default",
    "ICD_OP_CODE" character varying(4) COLLATE pg_catalog."default",
    "DRUG_DAY" numeric(2,0),
    "MED_TYPE" character varying(1) COLLATE pg_catalog."default",
    "PRSN_ID" character varying(32) COLLATE pg_catalog."default",
    "PHAR_ID" character varying(32) COLLATE pg_catalog."default",
    "DRUG_AMT" numeric(8,0),
    "TREAT_AMT" numeric(8,0),
    "TREAT_CODE" character varying(12) COLLATE pg_catalog."default",
    "DIAG_AMT" numeric(8,0),
    "DSVC_NO" character varying(12) COLLATE pg_catalog."default",
    "DSVC_AMT" numeric(8,0),
    "BY_PASS_CODE" character varying(2) COLLATE pg_catalog."default",
    "T_AMT" numeric(8,0),
    "PART_AMT" numeric(8,0),
    "T_APPL_AMT" numeric(8,0),
    "ID_SEX" character varying(1) COLLATE pg_catalog."default",
    "CASE_PAY_CODE" character varying(2) COLLATE pg_catalog."default",
    "TRAN_IN_HOSP_ID" character varying(34) COLLATE pg_catalog."default",
    "PAT_TRAN_OUT" character varying(1) COLLATE pg_catalog."default",
    "APPL_CAUSE_MARK" character varying(1) COLLATE pg_catalog."default"
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;
ALTER TABLE "OLAP"."ori.CD" OWNER to trinity;
COMMENT ON TABLE "OLAP"."ori.CD" IS '門診處方及治療明細檔';
COMMENT ON COLUMN "OLAP"."ori.CD"."FEE_YM" IS '費用年月';
COMMENT ON COLUMN "OLAP"."ori.CD"."APPL_TYPE" IS '申報類別';
COMMENT ON COLUMN "OLAP"."ori.CD"."HOSP_ID" IS '醫事機構代號';
COMMENT ON COLUMN "OLAP"."ori.CD"."APPL_DATE" IS '申報日期';
COMMENT ON COLUMN "OLAP"."ori.CD"."CASE_TYPE" IS '案件分類';
COMMENT ON COLUMN "OLAP"."ori.CD"."SEQ_NO" IS '流水號';
COMMENT ON COLUMN "OLAP"."ori.CD"."CURE_ITEM_NO1" IS '特定治療項目代號（一）';
COMMENT ON COLUMN "OLAP"."ori.CD"."CURE_ITEM_NO2" IS '特定治療項目代號（二）';
COMMENT ON COLUMN "OLAP"."ori.CD"."CURE_ITEM_NO3" IS '特定治療項目代號（三）';
COMMENT ON COLUMN "OLAP"."ori.CD"."CURE_ITEM_NO4" IS '特定治療項目代號（四）';
COMMENT ON COLUMN "OLAP"."ori.CD"."FUNC_TYPE" IS '就醫科別';
COMMENT ON COLUMN "OLAP"."ori.CD"."FUNC_DATE" IS '就醫日期';
COMMENT ON COLUMN "OLAP"."ori.CD"."TREAT_END_DATE" IS '治療結束日期';
COMMENT ON COLUMN "OLAP"."ori.CD"."ID_BIRTHDAY" IS '出生年月';
COMMENT ON COLUMN "OLAP"."ori.CD"."ID" IS '身份證統一編號';
COMMENT ON COLUMN "OLAP"."ori.CD"."CARD_SEQ_NO" IS '健保卡就醫序號';
COMMENT ON COLUMN "OLAP"."ori.CD"."GAVE_KIND" IS '給付類別';
COMMENT ON COLUMN "OLAP"."ori.CD"."PART_NO" IS '部分負擔代號';
COMMENT ON COLUMN "OLAP"."ori.CD"."ACODE_ICD9_1" IS '國際疾病分類號一';
COMMENT ON COLUMN "OLAP"."ori.CD"."ACODE_ICD9_2" IS '國際疾病分類號二';
COMMENT ON COLUMN "OLAP"."ori.CD"."ACODE_ICD9_3" IS '國際疾病分類號三';
COMMENT ON COLUMN "OLAP"."ori.CD"."ICD_OP_CODE" IS '主手術代碼';
COMMENT ON COLUMN "OLAP"."ori.CD"."DRUG_DAY" IS '給藥日份';
COMMENT ON COLUMN "OLAP"."ori.CD"."MED_TYPE" IS '處方調劑方式';
COMMENT ON COLUMN "OLAP"."ori.CD"."PRSN_ID" IS '醫師代號';
COMMENT ON COLUMN "OLAP"."ori.CD"."PHAR_ID" IS '藥師代號';
COMMENT ON COLUMN "OLAP"."ori.CD"."DRUG_AMT" IS '用藥明細點數小計';
COMMENT ON COLUMN "OLAP"."ori.CD"."TREAT_AMT" IS '診療明細點數小計';
COMMENT ON COLUMN "OLAP"."ori.CD"."TREAT_CODE" IS '診察費項目代號';
COMMENT ON COLUMN "OLAP"."ori.CD"."DIAG_AMT" IS '診察費';
COMMENT ON COLUMN "OLAP"."ori.CD"."DSVC_NO" IS '藥事服務費項目代號';
COMMENT ON COLUMN "OLAP"."ori.CD"."DSVC_AMT" IS '藥事服務費';
COMMENT ON COLUMN "OLAP"."ori.CD"."BY_PASS_CODE" IS 'DRG參考碼';
COMMENT ON COLUMN "OLAP"."ori.CD"."T_AMT" IS '合計點數';
COMMENT ON COLUMN "OLAP"."ori.CD"."PART_AMT" IS '部分負擔點數';
COMMENT ON COLUMN "OLAP"."ori.CD"."T_APPL_AMT" IS '申請點數';
COMMENT ON COLUMN "OLAP"."ori.CD"."ID_SEX" IS '性別';
COMMENT ON COLUMN "OLAP"."ori.CD"."CASE_PAY_CODE" IS '論病例計酬代碼';
COMMENT ON COLUMN "OLAP"."ori.CD"."TRAN_IN_HOSP_ID" IS '轉入院所代碼';
COMMENT ON COLUMN "OLAP"."ori.CD"."PAT_TRAN_OUT" IS '病患是否轉出';
COMMENT ON COLUMN "OLAP"."ori.CD"."APPL_CAUSE_MARK" IS '補報原因註記';
