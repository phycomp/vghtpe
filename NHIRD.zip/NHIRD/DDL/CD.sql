DROP TABLE "OLAP"."CD";
CREATE TABLE "OLAP"."CD" ("TRASID" character varying(2) COLLATE pg_catalog."default",
"HOSP_ID" character varying(10) COLLATE pg_catalog."default",
"APPL_TYPE" character varying(1) COLLATE pg_catalog."default",
"CASE_TYPE" character varying(2) COLLATE pg_catalog."default",
"SEQ_NO" character varying(6) COLLATE pg_catalog."default",
"CURE_ITEM_NO1" character varying(2) COLLATE pg_catalog."default",
"CURE_ITEM_NO2" character varying(2) COLLATE pg_catalog."default",
"CURE_ITEM_NO3" character varying(2) COLLATE pg_catalog."default",
"CURE_ITEM_NO4" character varying(2) COLLATE pg_catalog."default",
"FUNC_TYPE" character varying(2) COLLATE pg_catalog."default",
"ID" character varying(36) COLLATE pg_catalog."default",
"ARNHISNO" character varying(2) COLLATE pg_catalog."default",
"GAVE_KIND" character varying(1) COLLATE pg_catalog."default",
"PART_NO" character varying(3) COLLATE pg_catalog."default",
"TRAN_IN_HOSP_ID" character varying(10) COLLATE pg_catalog."default",
"PAT_TRAN_OUT" character varying(1) COLLATE pg_catalog."default",
"DRUG_DAY" numeric(8,0),
"MED_TYPE" character varying(1) COLLATE pg_catalog."default",
"CARD_SEQ_NO" character varying(4) COLLATE pg_catalog."default",
"ARNHBLK2" character varying(2) COLLATE pg_catalog."default",
"DRUG_AMT" numeric(8,0),
"TREAT_AMT" numeric(8,0),
"TREAT_CODE" character varying(12) COLLATE pg_catalog."default",
"DIAG_AMT" numeric(8,0),
"DSVC_NO" character varying(12) COLLATE pg_catalog."default",
"DSVC_AMT" numeric(8,0),
"T_AMT" numeric(8,0),
"PART_AMT" numeric(8,0),
"T_APPL_AMT" numeric(8,0),
"RESERVC2" character varying(2) COLLATE pg_catalog."default",
"RESERVP6" numeric(8,0),
"ARNHSTOT" character varying(2) COLLATE pg_catalog."default",
"ARNHIST" character varying(36) COLLATE pg_catalog."default",
"ARNSECT" character varying(3) COLLATE pg_catalog."default",
"ACODE_ICD9_1" character varying(8) COLLATE pg_catalog."default",
"ACODE_ICD9_2" character varying(8) COLLATE pg_catalog."default",
"ACODE_ICD9_3" character varying(8) COLLATE pg_catalog."default",
"ARNHIC94" character varying(8) COLLATE pg_catalog."default",
"ARNHIC95" character varying(8) COLLATE pg_catalog."default",
"ARNHOR" character varying(8) COLLATE pg_catalog."default",
"ARNHOR2" character varying(8) COLLATE pg_catalog."default",
"ARNHSPCD" character varying(2) COLLATE pg_catalog."default",
"PBNSEQX1" character varying(1) COLLATE pg_catalog."default",
"FEE_YM" character varying(6) COLLATE pg_catalog."default",
"FUNC_DATE" character varying(8) COLLATE pg_catalog."default",
"TREAT_END_DATE" character varying(8) COLLATE pg_catalog."default",
"ID_BIRTHDAY" character varying(8) COLLATE pg_catalog."default"
)
WITH ( OIDS = FALSE)
TABLESPACE pg_default;
ALTER TABLE "OLAP"."CD" OWNER to trinity;
COMMENT ON COLUMN "OLAP"."CD"."HOSP_ID" IS '醫事機構代號';
COMMENT ON COLUMN "OLAP"."CD"."APPL_TYPE" IS '申報類別';
COMMENT ON COLUMN "OLAP"."CD"."CASE_TYPE" IS '案件分類';
COMMENT ON COLUMN "OLAP"."CD"."SEQ_NO" IS '流水號';
COMMENT ON COLUMN "OLAP"."CD"."CURE_ITEM_NO1" IS '特定治療項目代號（一）';
COMMENT ON COLUMN "OLAP"."CD"."CURE_ITEM_NO2" IS '特定治療項目代號（二）';
COMMENT ON COLUMN "OLAP"."CD"."CURE_ITEM_NO3" IS '特定治療項目代號（三）';
COMMENT ON COLUMN "OLAP"."CD"."CURE_ITEM_NO4" IS '特定治療項目代號（四）';
COMMENT ON COLUMN "OLAP"."CD"."FUNC_TYPE" IS '就醫科別';
COMMENT ON COLUMN "OLAP"."CD"."ID" IS '身份證統一編號';
COMMENT ON COLUMN "OLAP"."CD"."GAVE_KIND" IS '給付類別';
COMMENT ON COLUMN "OLAP"."CD"."PART_NO" IS '部分負擔代號';
COMMENT ON COLUMN "OLAP"."CD"."TRAN_IN_HOSP_ID" IS '轉入院所代碼';
COMMENT ON COLUMN "OLAP"."CD"."PAT_TRAN_OUT" IS '病患是否轉出';
COMMENT ON COLUMN "OLAP"."CD"."DRUG_DAY" IS '給藥日份';
COMMENT ON COLUMN "OLAP"."CD"."MED_TYPE" IS '處方調劑方式';
COMMENT ON COLUMN "OLAP"."CD"."CARD_SEQ_NO" IS '健保卡就醫序號';
COMMENT ON COLUMN "OLAP"."CD"."DRUG_AMT" IS '用藥明細點數小計';
COMMENT ON COLUMN "OLAP"."CD"."TREAT_AMT" IS '診療明細點數小計';
COMMENT ON COLUMN "OLAP"."CD"."TREAT_CODE" IS '診察費項目代號';
COMMENT ON COLUMN "OLAP"."CD"."DIAG_AMT" IS '診察費';
COMMENT ON COLUMN "OLAP"."CD"."DSVC_NO" IS '藥事服務費項目代號';
COMMENT ON COLUMN "OLAP"."CD"."DSVC_AMT" IS '藥事服務費';
COMMENT ON COLUMN "OLAP"."CD"."T_AMT" IS '合計點數';
COMMENT ON COLUMN "OLAP"."CD"."PART_AMT" IS '部分負擔點數';
COMMENT ON COLUMN "OLAP"."CD"."T_APPL_AMT" IS '申請點數';
COMMENT ON COLUMN "OLAP"."CD"."ACODE_ICD9_1" IS '國際疾病分類號一';
COMMENT ON COLUMN "OLAP"."CD"."ACODE_ICD9_2" IS '國際疾病分類號二';
COMMENT ON COLUMN "OLAP"."CD"."ACODE_ICD9_3" IS '國際疾病分類號三';
COMMENT ON COLUMN "OLAP"."CD"."FEE_YM" IS '費用年月';
COMMENT ON COLUMN "OLAP"."CD"."FUNC_DATE" IS '就醫日期';
COMMENT ON COLUMN "OLAP"."CD"."TREAT_END_DATE" IS '治療結束日期';
COMMENT ON COLUMN "OLAP"."CD"."ID_BIRTHDAY" IS '出生年月';
