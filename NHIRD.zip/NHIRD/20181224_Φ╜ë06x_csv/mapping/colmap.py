#!/usr/bin/env python
from sys import argv
from os.path import splitext, basename
from glob import glob

#Usage: $prog columnMapping.csv, '../DDL/CD.CSV'
#1DD健保-住院醫療費用清單明細檔（適用 101 年以後資料）FEE_YM費用年月C6VGHTPE_DD北榮健保申報-住院醫療費用清單明細DISYYMM費用年月文字5
#2DD健保-住院醫療費用清單明細檔（適用 101 年以後資料）APPL_TYPE申報類別C1VGHTPE_DD北榮健保申報-住院醫療費用清單明細BRELAY申報類別文字1
#oriMap, CSVs=argv[1], glob('../DDL/*.CSV')
#TBL={}
CSV={}
for csv in glob('../DDL/*.CSV'):
	with open(csv) as fin:
		base, csv=splitext(basename(csv))
		for line in fin:
			colName=line.split('\t')[1]
			key='-'.join([base, colName])
			CSV[key]=colName
#print(CSV.keys())
for line in open('columnMapping.csv'):
	cols=line.strip('\n').split('\x06')
	oriTbl, oriCol, tblname, newCol=cols[1], cols[3], cols[7], cols[9]
	key='-'.join([oriTbl, oriCol])
	#print(key)
	newCol=CSV.get(key)
	if newCol:
		cols[7], cols[9]=oriTbl, newCol
		CSV.pop(key)
		#print(newCol)
	print('\x06'.join(cols))
print(CSV)
'''
old, new={}, {}
for line in open(oldColFname):
	cols=line.strip('\n').split('\x06')
	k, v=cols[0], cols[-1]
	old[k]=v
for line in open(newColFname):
	if line.startswith('\t'): continue
	cols=line.strip('\n').split('\t')
	newCol=cols[1]
	existedCol=old.get(newCol)
	print(newCol, existedCol)

==> CD.mapping <==
FEE_YMVGHTPE_CDYYYMM
APPL_TYPEVGHTPE_CDAPPLTYP
HOSP_IDVGHTPE_CDHOSID2
APPL_DATEVGHTPE_CD""
CASE_TYPEVGHTPE_CDARNHMANO
SEQ_NOVGHTPE_CD""
CURE_ITEM_NO1VGHTPE_CDARNHSUB1
CURE_ITEM_NO2VGHTPE_CDARNHSUB2
CURE_ITEM_NO3VGHTPE_CDARNHSUB3
CURE_ITEM_NO4VGHTPE_CDARNHSUB4

==> ../DDL/CD.CSV <==
	NAME	LENGTH	VARNUM	typei
1	TRASID	2	1	字串
2	HOSP_ID	10	2	字串
3	APPL_TYPE	1	3	字串
4	CASE_TYPE	2	4	字串
5	SEQ_NO	6	5	字串
6	CURE_ITEM_NO1	2	6	字串
7	CURE_ITEM_NO2	2	7	字串
8	CURE_ITEM_NO3	2	8	字串
9	CURE_ITEM_NO4	2	9	字串
'''
