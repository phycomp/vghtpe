DROP TABLE "DO";
CREATE TABLE "DO" ("CASE_TYPE" character varying(2) COLLATE pg_catalog."default",
"APPL_TYPE" character varying(1) COLLATE pg_catalog."default",
"SEQ_NO" character varying(6) COLLATE pg_catalog."default",
"BIDNO" character varying(36) COLLATE pg_catalog."default",
"OESEQNO" character varying(5) COLLATE pg_catalog."default",
"ORDER_TYPE" character varying(1) COLLATE pg_catalog."default",
"ORDER_CODE" character varying(12) COLLATE pg_catalog."default",
"PAY_RATE" numeric(8,0),
"BDGDOS" character varying(6) COLLATE pg_catalog."default",
"DRUG_PATH" character varying(22) COLLATE pg_catalog."default",
"BOROPTMB" character varying(4) COLLATE pg_catalog."default",
"BOROPTME" character varying(4) COLLATE pg_catalog."default",
"ORDER_QTY" numeric(8,0),
"AA0" character varying(1) COLLATE pg_catalog."default",
"ORDER_PRICE" numeric(8,0),
"ORDER_AMT" numeric(8,0),
"PFKEY" character varying(8) COLLATE pg_catalog."default",
"BXLPARNO" character varying(2) COLLATE pg_catalog."default",
"FEE_YM" character varying(6) COLLATE pg_catalog."default",
"EXE_S_DATE" character varying(8) COLLATE pg_catalog."default",
"EXE_E_DATE" character varying(8) COLLATE pg_catalog."default"
)
WITH ( OIDS = FALSE)
TABLESPACE pg_default;
ALTER TABLE "DO" OWNER to postgres;
