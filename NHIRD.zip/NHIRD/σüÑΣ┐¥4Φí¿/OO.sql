DROP TABLE "OO";
CREATE TABLE "OO" ("APPL_TYPE" character varying(1) COLLATE pg_catalog."default",
"CASE_TYPE" character varying(2) COLLATE pg_catalog."default",
"SEQ_NO" character varying(6) COLLATE pg_catalog."default",
"OESEQNO" character varying(5) COLLATE pg_catalog."default",
"ARNHPAID" character varying(36) COLLATE pg_catalog."default",
"RESERVE" character varying(2) COLLATE pg_catalog."default",
"DRUGDAYS" character varying(2) COLLATE pg_catalog."default",
"REL_MODE" character varying(1) COLLATE pg_catalog."default",
"ARNYESNO" character varying(1) COLLATE pg_catalog."default",
"ORDER_TYPE" character varying(1) COLLATE pg_catalog."default",
"DRUG_NO" character varying(12) COLLATE pg_catalog."default",
"DRUG_USE" numeric(8,0),
"DRUG_FRE" character varying(18) COLLATE pg_catalog."default",
"ARNHROUT" character varying(4) COLLATE pg_catalog."default",
"CURE_PATH" character varying(6) COLLATE pg_catalog."default",
"PAY_RATE" character varying(3) COLLATE pg_catalog."default",
"TOTAL_QTY" numeric(8,0),
"UNIT_PRICE" numeric(8,0),
"TOTAL_AMT" numeric(8,0),
"ARDDFLAG" character varying(1) COLLATE pg_catalog."default",
"PFCATG2" character varying(2) COLLATE pg_catalog."default",
"ARNHIPCD" character varying(8) COLLATE pg_catalog."default",
"ARNHPNAM" character varying(32) COLLATE pg_catalog."default",
"ARNHIREQ" character varying(7) COLLATE pg_catalog."default",
"FEE_YM" character varying(6) COLLATE pg_catalog."default"
)
WITH ( OIDS = FALSE)
TABLESPACE pg_default;
ALTER TABLE "OO" OWNER to postgres;
