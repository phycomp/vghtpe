vghcarLegendLabel <- function(input, cleanData) {
    cohortCount <- input$cohortCount
    if (is.null(cohortCount)) {
        return(NULL)
    }

    legendLabel <- NULL
    if (1 == cohortCount) {
        vghcarStratify <- input$vghcarStratify

        if (is.null(vghcarStratify)) {
            return(NULL)
        }

        if ("1" == vghcarStratify) {
            return(NULL)
        }

        legendLabel <- levels(factor(cleanData[,vghcarStratify]))
    } else {
        legendLabel <- levels(factor(cleanData[,"CohortNo"]))
    }
    return(legendLabel)
}