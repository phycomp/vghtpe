annualReportTable <- function(survivalFormulaText, cancerData, rownameLabel) {
    if (0 == count(cancerData)[[1]]) {
        return(NULL)
    }

    if (is.null(survivalFormulaText)) {
        return(NULL)
    }

    survivalFormula <- eval(parse(text = survivalFormulaText))

    survivalFit <- survfit(survivalFormula, data = cancerData, conf.type = "log-log")
    # ?summary.survfit
    annualSummary <- summary(survivalFit)
    rownameAnnual <- as.character(levels(annualSummary$strata))
    colnameAnnual <- c("1年 存活率(%)","2年 存活率(%)","3年 存活率(%)","4年 存活率(%)","5年 存活率(%)")

    # 針對不分層的報表特別做的
    if (is.null(nrow(annualSummary$table))) {
        annualReport <- data.frame(rbind(annualSummary$table[c("records","median")]))
    } else {
        annualReport <- data.frame(cbind(annualSummary$table[,c("records","median")]))
    }

    names(annualReport) <- c("個案數", "中位數 存活時間（月）")
    annualReport[,colnameAnnual] <- NA

    # 如果存活期小於 12 個月，則維持 NA 即可
    if (max(annualSummary$time) >= 12) {
        annualSummary <- summary(survivalFit, times=c(0, 12, 24, 36, 48, 60))
        # func + inner func
        if (length(rownameAnnual) > 0) {
            for(i in 1:length(rownameAnnual)) {
                annualTemp <- annualSummary$surv[annualSummary$strata %in% rownameAnnual[i]]
                if (length(annualTemp) > 0) {
                    annualReport[i,3:(2+length(annualTemp)-1)] <- annualTemp[2:length(annualTemp)] * 100
                }
            }
        } else {
            annualTemp <- annualSummary$surv
            if (length(annualTemp) > 0) {
                annualReport[1,3:(2+length(annualTemp)-1)] <- annualTemp[2:length(annualTemp)] * 100
            }
        }
    }

    if (length(rownameLabel) == length(rownameAnnual)) {
        row.names(annualReport) <- rownameLabel
    }

    # 只剩一筆資料的時候，若有給 label，就用它的吧
    if (1 == length(rownameLabel) && 0 == length(rownameAnnual)) {
        row.names(annualReport) <- rownameLabel
    }
    return(annualReport)
}