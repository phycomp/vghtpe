vghcarCurveOption <- function(input, isShow, mainTitle, type) {

    showSurvivalCurve <- buttonTypeRadioButton(
        inputId   = paste0(type, "ShowSurvivalCurve"),
        label     = tags$h6("Survival Curve"),
        inline    = TRUE,
        selected  = isShow,
        choices   = c(
            "Show" = "show",
            "Hide" = "hide"
        )
    )

    if (!is.null(isShow)) {
        if ("hide" == isShow) {
            ui <- showSurvivalCurve
            return(ui)
        }
    }

    curveTypeValue <- input[[paste0(type, "CurveType")]]
    if (is.null(curveTypeValue)) {
        curveTypeValue <- "KaplanMeier"
    }

    curveType <- buttonTypeRadioButton(
        inputId   = paste0(type, "CurveType"),
        label     = tags$h6("Curve Type"),
        inline    = FALSE,
        selected  = curveTypeValue,
        choices   = c(
            "Kaplan-Meier" = "KaplanMeier",
            "Nelson-Aalen" = "NelsonAalen"
        ),
        specialClass = " btn-group curveType"
    )

    showCensorData <- buttonTypeRadioButton(
        inputId   = paste0(type, "ShowCensorData"),
        label     = tags$h6("Censor Data"),
        inline    = TRUE,
        selected  = "hide",
        choices   = c(
            "Show" = "show",
            "Hide" = "hide"
        )
    )

    showConfidenceInterval <- buttonTypeRadioButton(
        inputId   = paste0(type, "ShowConfidenceInterval"),
        label     = tags$h6("CI 95%"),
        inline    = TRUE,
        selected  = "hide",
        choices   = c(
            "Show" = "show",
            "Hide" = "hide"
        )
    )

    showPvalue <- buttonTypeRadioButton(
        inputId   = paste0(type, "ShowPvalue"),
        label     = tags$h6("P value"),
        inline    = TRUE,
        selected  = "show",
        choices   = c(
            "Show" = "show",
            "Hide" = "hide"
        )
    )

    showRiskTable <- buttonTypeRadioButton(
        inputId   = paste0(type, "ShowRiskTable"),
        label     = tags$h6("Risk Table"),
        inline    = TRUE,
        selected  = "show",
        choices   = c(
            "Show" = "show",
            "Hide" = "hide"
        )
    )

    showLineType <- buttonTypeRadioButton(
        inputId   = paste0(type, "ShowLineType"),
        label     = tags$h6("Line Type"),
        inline    = TRUE,
        selected  = "strata",
        choices   = c("solid", "strata")
    )

    showSetTitle <- textInput(
        inputId   = paste0(type, "SetTitle"),
        label     = tags$h6("Set Title"),
        value     = mainTitle
    )

    showSetXLabel <- textInput(
        inputId   = paste0(type, "SetXLabel"),
        label     = tags$h6("Set X Label"),
        value     = "Time after diagnosis of cancer (Month)"
    )

    yLabel <- ""
    if (!is.null(curveTypeValue)) {
        if ("KaplanMeier" == curveTypeValue) {
            yLabel <- "Survival probability"
        } else if ("NelsonAalen" == curveTypeValue) {
            yLabel <- "Cumulative hazard"
        }
    }

    showSetYLabel <- textInput(
        inputId   = paste0(type, "SetYLabel"),
        label     = tags$h6("Set Y Label"),
        value     = yLabel
    )

    showSetRiskTableTitle <- textInput(
        inputId   = paste0(type, "SetRiskTableTitle"),
        label     = tags$h6("Set Risk Table Title"),
        value     = "Number of patients at risk:"
    )

    showLineSize <- sliderInput(
        inputId   = paste0(type, "ShowLineSize"),
        label     = tags$h6("Show Line Size"),
        min       = 0.5,
        max       = 2,
        value     = 1.2,
        step      = 0.1
    )

    showWindowWidthValue <- input[[paste0(type, "ShowWindowWidth")]]
    if (is.null(showWindowWidthValue)) {
        showWindowWidthValue <- "No"
    }

    showWindowWidth <- buttonTypeRadioButton(
        inputId   = paste0(type, "ShowWindowWidth"),
        label     = tags$h6("Show Window Width"),
        inline    = TRUE,
        selected  = showWindowWidthValue,
        choices   = c("Yes", "No")
    )

    if ("No" == showWindowWidthValue) {
        showCurveWidth <- sliderInput(
            inputId   = paste0(type, "ShowCurveWidth"),
            label     = tags$h6("Show Curve Width"),
            min       = 400,
            max       = 2400,
            value     = 1200,
            step      = 25
        )
    } else {
        showCurveWidth <- NULL
    }

    showCurveHeight <- sliderInput(
        inputId   = paste0(type, "ShowCurveHeight"),
        label     = tags$h6("Show Curve Height"),
        min       = 400,
        max       = 1600,
        value     = 675,
        step      = 25
    )

    ui <- tagList(
        tags$div(class = "col-lg-12", curveType),
        tags$div(class = "col-lg-6", showCensorData),
        tags$div(class = "col-lg-6", showPvalue),
        tags$div(class = "col-lg-6", showRiskTable),
        tags$div(class = "col-lg-6", showConfidenceInterval),
        tags$div(class = "col-lg-6", showLineType),
        tags$div(class = "col-lg-6", showSurvivalCurve),
        tags$div(class = "col-lg-12", showSetTitle),
        tags$div(class = "col-lg-12", showSetXLabel),
        tags$div(class = "col-lg-12", showSetYLabel),
        tags$div(class = "col-lg-12", showSetRiskTableTitle),
        tags$div(class = "col-lg-12", showLineSize),
        tags$div(class = "col-lg-12", showWindowWidth),
        tags$div(class = "col-lg-12", showCurveWidth),
        tags$div(class = "col-lg-12", showCurveHeight)
    )
    return(ui)
}
