vghcarCoxTable <- function(input, survivalFormulaText, dataset, variable, stratify, type) {
    if (is.null(dataset) |
        is.null(variable) |
        !is.null(variable["Error", "Error Message"]) |
        is.null(survivalFormulaText)
    ) {
        return(list(NULL, NULL))
    }

    survivalFormula <- eval(parse(text = survivalFormulaText))

    newDataset <- vghcarRelevelDataset(input, dataset, stratify, type)
	coxModel <- coxph(survivalFormula, newDataset)
    coxModelSummary <- summary(coxModel)
    coxInfo <- coxModelSummary$conf.int[,c("exp(coef)", "lower .95", "upper .95")]
    if (is.null(coxInfo)) {
        return(list(NULL, NULL))
    }

    coxTable <- transferCoxTable(coxInfo, coxModelSummary$coefficients[,c("Pr(>|z|)")])

    rowname <- transferCoxRowName(coxModel, variable)
    rownames(coxTable) <- rowname

    logrankTest <- round(as.numeric(coxModelSummary$sctest["test"]), 2)
    result <- list(coxTable, logrankTest)
    return(result)
}