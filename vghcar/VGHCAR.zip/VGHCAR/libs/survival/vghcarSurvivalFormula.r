vghcarSurvivalFormula <- function(input, overall) {
    cohortCount <- input$cohortCount
    if (is.null(cohortCount)) {
        return(NULL)
    }

    vghcarSurvivalType <- input$vghcarSurvivalType
    if (is.null(vghcarSurvivalType)) {
        return(NULL)
    }

    standardEvent <- paste0("Event", vghcarSurvivalType)
    eventColumnSet <- dplyr::filter(overall, Standard == "EventOS")
    originalEvent <- eventColumnSet$Colname

    if (1 == cohortCount) {
        vghcarStratify <- input$vghcarStratify
    } else {
        vghcarStratify <- "CohortNo"
    }

    formula <- paste0("Surv(Time", vghcarSurvivalType, " /365 *12, ", originalEvent, ") ~ ", vghcarStratify)

    return(formula)
}