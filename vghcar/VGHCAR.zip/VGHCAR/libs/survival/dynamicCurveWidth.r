dynamicCurveWidth <- function(input, type, isPx) {
    showWindowWidthValue <- input[[paste0(type, "ShowWindowWidth")]]
    showCurveWidthValue <- input[[paste0(type, "ShowCurveWidth")]]

    if (is.null(showWindowWidthValue) |
        is.null(showCurveWidthValue)
    ) {
        return(ifelse(isPx, "100%", 800))
    }

    if ("Yes" == showWindowWidthValue) {
        return(ifelse(isPx, "100%", 800))
    }

    return(ifelse(isPx, paste0(showCurveWidthValue, "px"), showCurveWidthValue))
}
