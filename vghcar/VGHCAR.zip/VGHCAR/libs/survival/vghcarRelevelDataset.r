vghcarRelevelDataset <- function(input, dataset, stratify, type) {
    if (is.null(dataset)) {
        return(NULL)
    }

    cohortCount <- input$cohortCount
    if (is.null(cohortCount)) {
        return(NULL)
    }

    termList <- ifelse((1 == cohortCount), stratify, c("CohortNo"))

    for (term in termList) {
        baseLevel <- input[[paste0(type, term, "CoxReferenceLevel")]]
        if (is.null(baseLevel)) {
            next
        }

        if (!is.ordered(dataset[,term])) {
            if (baseLevel %in% names(summary(dataset[,term]))) {
                dataset[,term] <- relevel(dataset[,term], ref = baseLevel)
            }
        }
    }
    return(dataset)
}
