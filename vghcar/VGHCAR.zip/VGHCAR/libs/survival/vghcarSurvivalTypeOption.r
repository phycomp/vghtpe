vghcarSurvivalTypeOption <- function() {
    typeChoices <- c(
        "LCR - Local Control Rate"                       = "LCR",
        "LRCR - Locoregional Control Rate"               = "LRCR",
        "DMCR - Distant Metastase Control Rate"          = "DMCR",
        "NCR - Nodal Control Rate"                       = "NCR",
        "OS - Overall Survival"                          = "OS",
        "DSS - Disease Specific Survival"                = "DSS",
        "PFS - Progression Free Survival"                = "PFS",
        "LPFS - Local Progression Free Survival"         = "LPFS",
        "LRPFS - Locoregional Progression Free Survival" = "LRPFS",
        "DMFS - Distant Metastase Free Survival"         = "DMFS"
    )

    ui <- selectizeInput(
        inputId   = "vghcarSurvivalType",
        label     = tags$h6("The type of survival"),
        selected  = "OS",
        choices   = typeChoices
    )

    return(ui)
}