vghcarSurvivalTitle <- function(input, dataset) {
    cohortCount <- input$cohortCount
    if (is.null(cohortCount)) {
        return(NULL)
    }

    survivalTitle <- NULL
    if (1 == cohortCount) {
        vghcarStratify <- input$vghcarStratify
        if (is.null(vghcarStratify)) {
            return(NULL)
        }

        stratifyTitle <- ""
        if ("AJCC_STAGE" == vghcarStratify) {
            stratifyTitle <- "按AJCC期別分布"
        } else if ("SEX" == vghcarStratify) {
            stratifyTitle <- "按性別分布"
        } else if ("AGE_RANGE" == vghcarStratify) {
            stratifyTitle <- "按年齡分布"
        } else if ("1" == vghcarStratify) {
            stratifyTitle <- ""
        }

        cohortDuration <- as.character(input$cohortDuration)
        cohortStart  <- cohortDuration[1]
        cohortEnd    <- cohortDuration[2]

        dataCount <- count(dataset)[[1]]

        survivalTitle <- paste0(
            cohortStart, "～", cohortEnd,
            " 病人", stratifyTitle, "之總體存活率 (n = ", dataCount, ")"
        )
    } else {
        # TODO: 之後改成三個以上的時候，再研究迴圈
        cohortDuration1 <- as.character(input$cohortDuration1)
        cohort1stStart  <- cohortDuration1[1]
        cohort1stEnd    <- cohortDuration1[2]
        cohortDuration2 <- as.character(input$cohortDuration2)
        cohort2ndStart  <- cohortDuration2[1]
        cohort2ndEnd    <- cohortDuration2[2]

        survivalTitle <- paste0(
            cohort1stStart, "～", cohort1stEnd,
            "(n1 = ", summary(dataset$CohortNo)[1], ") ",
            " 與 ", cohort2ndStart, "～", cohort2ndEnd,
            "(n2 = ", summary(dataset$CohortNo)[2], ") ",
            " 病人之總體存活率"
        )
    }
    return(survivalTitle)
}