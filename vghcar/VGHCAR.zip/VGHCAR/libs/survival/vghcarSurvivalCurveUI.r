vghcarSurvivalCurveUI <- function(width, height) {
    ui <- tags$fieldset(
        id = "vghcarSurvivalCurveFieldset",
        class = "singleLine",
        tags$legend(
            class = "singleLine",
            downloadUI <- downloadButton(
                outputId  = "downloadSurvivalCurve",
                label = tags$span("Survival Curve", class = "h4"),
                class = "btn-primary btn-block"
            )
        ),
        plotOutput(
            outputId = "vghcarSurvivalCurve",
            width = width,
            height = height
        )
    )

    return(ui)
}