vghcarStratificationOption <- function(input) {
    cohortCount <- input$cohortCount
    if (is.null(cohortCount)) {
        return(NULL)
    }

    if (1 == cohortCount) {
        ui <- buttonTypeRadioButton(
            inputId   = "vghcarStratify",
            label     = tags$h6("年報分類"),
            inline    = FALSE,
            selected  = "AJCC_STAGE",
            choices   = c(
                "AJCC 期別" = "AJCC_STAGE",
                "性別"      = "SEX",
                "年齡"      = "AGE_RANGE",
                "全部"      = "1"
            ),
            specialClass = " btn-group curveType"
        )
    } else {
        ui <- tags$span("期間比較模式",  class="h4")
    }

    return(ui)
}