vghcarCoxTableOption <- function(input, metadata, stratify, legendLabel, type) {
    variable <- metadata$Variable
    level <- metadata$Level

    if (is.null(variable) |
        is.null(level) |
        !is.null(variable["Error", "Error Message"]) |
        is.null(legendLabel)
    ) {
        return(NULL)
    }

    if (is.null(stratify)) {
        stratify = "CohortNo"
    }

    radioId <- paste0(type, stratify, "CoxReferenceLevel")

    title <- ""
    if ("AJCC_STAGE" == stratify) {
        title <- "AJCC 期別"
    } else if ("SEX" == stratify) {
        title <- "性別"
    } else if ("AGE_RANGE" == stratify) {
        title <- "年齡"
    } else if ("CohortNo" == stratify) {
        title <- "期間比較"
    }

    selected <- input[[radioId]]
    choices <- legendLabel
    radio <- .radioButtonAll(radioId, title, selected, choices)
    return(radio)
}

.radioButtonAll <- function(id, title, selected, choices) {
    choicesLength <- length(choices)
    if (is.null(selected)) {
        selected <- ifelse(2 == choicesLength, choices[2], choices[1])
    }

    ui <- radioButtons(
        inputId   = id,
        label     = title,
        inline    = TRUE,
        selected  = selected,
        choices   = choices
    )
    return(ui)
}
