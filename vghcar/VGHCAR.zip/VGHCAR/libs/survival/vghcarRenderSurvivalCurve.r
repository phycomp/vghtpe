vghcarRenderSurvivalCurve <- function (
    input, formula, legendLabel, dataset, type
) {
    if (is.null(dataset)) {
        return(NULL)
    }

    if (0 == count(dataset)[[1]]) {
        return(NULL)
    }
    withProgress(
        message = 'Render survival curve.',
        detail = "Read input value.",
        value = 0,
        expr = {
            curveType <- input[[paste0(type, "CurveType")]]
            showCensorData <- input[[paste0(type, "ShowCensorData")]]
            showConfidenceInterval <- input[[paste0(type, "ShowConfidenceInterval")]]
            showPvalue <- input[[paste0(type, "ShowPvalue")]]
            showRiskTable <- input[[paste0(type, "ShowRiskTable")]]
            showLineType <- input[[paste0(type, "ShowLineType")]]
            intervalType <- input[[paste0(type, "IntervalType")]]
            mainTitle <- input[[paste0(type, "SetTitle")]]
            xLabel <- input[[paste0(type, "SetXLabel")]]
            yLabel <- input[[paste0(type, "SetYLabel")]]
            riskTableTitle <- input[[paste0(type, "SetRiskTableTitle")]]
            showLineSize <- input[[paste0(type, "ShowLineSize")]]

            # for survival::Surv
            incProgress(0.2, detail = paste("Calculate survival fit."))

            survivalFit <- survival::survfit(
                formula = formula,
                data = dataset,
                conf.type = "log-log")

            survivalFitMinUpper <- min(survivalFit$upper, na.rm=TRUE)
            survivalFitMinLower <- min(survivalFit$lower, na.rm=TRUE)

            incProgress(0.2, detail = paste("Set curve parameters."))
            curveParams <- .defaultCurveParam()

            if (is.null(curveType)) {
            } else if ("KaplanMeier" == curveType) {
                verticalPosition <- 0.9
                if (survivalFitMinUpper > verticalPosition & survivalFitMinLower < verticalPosition) {
                    verticalPosition <- survivalFitMinLower - 0.1
                }
                curveParams$fun <- NULL
                curveParams$pval.coord <- c(0.9 * max(survivalFit$time), verticalPosition)
            } else if ("NelsonAalen" == curveType) {
                verticalPosition <- 0.1
                if ((1 - survivalFitMinUpper) < verticalPosition) {
                    verticalPosition <- (1 - survivalFitMinUpper) / 4
                }
                curveParams$fun <- "cumhaz"
                curveParams$pval.coord <- c(0.9 * max(survivalFit$time), verticalPosition)
            }

            curveParams$main <- mainTitle
            curveParams$xlab <- xLabel
            curveParams$ylab <- yLabel
            curveParams$risk.table.title <- riskTableTitle
            curveParams$censor <- .isShow(showCensorData, curveParams$censor)
            curveParams$conf.int <- .isShow(showConfidenceInterval, curveParams$conf.int)
            curveParams$pval <- .isShow(showPvalue, curveParams$pval)
            curveParams$risk.table <- .isShow(showRiskTable, curveParams$risk.table)
            curveParams$legend.labs <- legendLabel
            curveParams$size <- showLineSize

            if (!is.null(showLineType)) {
                curveParams$linetype <- showLineType
            }

            curveParams$break.time.by <- 12

            # curveParams$xlab <- .assembleXlable(realDurationUnit, datasetName)

            # pre-calculate p-value
            incProgress(0.2, detail = paste("Calculate p-value."))
            pvalue <- NULL
            if (length(levels(summary(survivalFit)$strata)) != 0) {
                pvalue <- getPvalue(formula, dataset)
            }

            incProgress(0.2, detail = paste("Render survival curve start."))
            curve <- .renderCurve(survivalFit, curveParams, pvalue)
            incProgress(0.2, detail = paste("Render survival curve down."))
        }
    )

    return(curve)
}

.renderCurve <- function(survivalFit, curveParams, pvalue) {
    curve <- vghcarGgSurvivalCurve(
        survivalFit,
        fun = curveParams$fun,
        size = curveParams$size, # line size
        linetype = curveParams$linetype,
        break.time.by = curveParams$break.time.by,
        conf.int = curveParams$conf.int,
        censor = curveParams$censor,
        pval = curveParams$pval,
        pval.coord = curveParams$pval.coord,
        pvalue = pvalue,
        risk.table = curveParams$risk.table,
        legend = curveParams$legend,
        legend.title = curveParams$legend.title,
        legend.labs = curveParams$legend.labs,
        risk.table.title = curveParams$risk.table.title,
        font.family = "Helvetica",
        font.main = c(24, "plain", "black"),
        font.x = c(20, "plain", "black"),
        font.y = c(20, "plain", "black"),
        font.tickslab = c(16, "plain", "black"),
        font.legend = c(16, "plain", "black"),
        risk.table.fontsize = 6,
        pval.size = 6,
        surv.scale = "percent",
        xlab = curveParams$xlab,
        ylab = curveParams$ylab,
        main = curveParams$main
    )

    return(curve)
}

.defaultCurveParam <- function() {
    curveParams <- NULL
    curveParams$fun <- NULL
    curveParams$linetype <- 1
    curveParams$break.time.by <- NULL
    curveParams$conf.int <- FALSE
    curveParams$censor <- FALSE
    curveParams$pval <- TRUE
    curveParams$pval.coord <- c(NULL, NULL)
    curveParams$risk.table <- TRUE
    curveParams$legend <- "top"
    curveParams$legend.title <- ""
    curveParams$risk.table.title <- "Number of patients at risk:"
    curveParams$xlab <- "Time after diagnosis"
    curveParams$ylab <- ""
    curveParams$main <- ""
    return(curveParams)
}

.isShow <- function(showOrHide, default) {
    isShow <- default
    if (!is.null(showOrHide)) {
        isShow <- switch(showOrHide,
            show = TRUE,
            hide = FALSE,
            default
        )
    }
    return(isShow)
}

.assembleXlable <- function(realDurationUnit, datasetName = "") {
    name <- ""
    if ("" != datasetName) {
        name <- paste0("of ", datasetName)
    }
    xLable <- paste0("Time after diagnosis ", name, " (", realDurationUnit, ")")
    return(xLable)
}
