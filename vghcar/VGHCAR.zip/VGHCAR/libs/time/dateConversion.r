

#make the date as a time series class from string or int
#====== function for convert int into date ============
dateConversion <- function(x) {
    # library(xts)
    # library(lubridate)

    stringX  <- as.character(x)
    # 先拿掉 "-"
    stringX  <- gsub("-", "", stringX)

    # 乘除很耗資源 ...
    # integerX <- as.numeric(stringX)

    # tempYear  <- as.integer(integerX / 10000)
    # tempMonth <- as.integer((integerX - tempYear * 10000) / 100)
    # tempDay   <- integerX - tempYear * 10000 - tempMonth * 100

    dateYear  <- substr(stringX, 1, 4)
    dateMonth <- substr(stringX, 5, 6)
    dateDay   <- substr(stringX, 7, 8)

    # 如果是 9999 年，一律換成 NA
    dateDay   <- ifelse("9999" == dateYear, NA, dateDay)
    dateMonth <- ifelse("9999" == dateYear, NA, dateMonth)
    dateYear  <- ifelse("9999" == dateYear, NA, dateYear)

    # 如果是 8888 年，一律換成 NA
    dateDay   <- ifelse("8888" == dateYear, NA, dateDay)
    dateMonth <- ifelse("8888" == dateYear, NA, dateMonth)
    dateYear  <- ifelse("8888" == dateYear, NA, dateYear)

    # 如果是 0000 年，一律換成 NA
    dateDay   <- ifelse("0000" == dateYear, NA, dateDay)
    dateMonth <- ifelse("0000" == dateYear, NA, dateMonth)
    dateYear  <- ifelse("0000" == dateYear, NA, dateYear)

    # # 如果月不詳，則調成 07-01
    # dateDay   <- ifelse("99" == dateMonth, "01", dateDay)
    # dateMonth <- ifelse("99" == dateMonth, "07", dateMonth)

    # 月不詳一律換成 NA
    dateDay   <- ifelse("99" == dateMonth, NA, dateDay)
    dateMonth <- ifelse("99" == dateMonth, NA, dateMonth)
    dateYear  <- ifelse("99" == dateMonth, NA, dateYear)

    # 日不詳調整成 15
    dateDay   <- ifelse("99" == dateDay, "15", dateDay)

    xDate <- paste(dateYear, dateMonth, dateDay, sep = "-")
    # NA 在組合的時候，會變成 "NA-NA-NA"，所以要換回 NA
    xDate <- gsub("NA-NA-NA", NA, xDate)
    # "" 在組合的時候，會變成 "--"，所以要換回 NA
    xDate <- gsub("--", NA, xDate)
    xDate <- as.Date(xDate)
    return(xDate)
}
