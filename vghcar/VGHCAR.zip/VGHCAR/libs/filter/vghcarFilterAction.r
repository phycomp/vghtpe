vghcarFilterAction <- function(input, dataset, variable, level) {
    if (is.null(dataset) |
        is.null(variable) |
        is.null(level) |
        !is.null(variable["Error", "Error Message"])
    ) {
        return(NULL)
    }

    exResult <- firstFilterResult(dataset)

    exResult <- vghcarClassifyFilter(input, exResult)

    exResult <- vghcarCohortFilter(input, exResult)

    exResult <- vghcarStageFilter(input, exResult)

    categorical <- allCategoricalFilter(variable)
    exResult <- categoricalCheckboxFilter(input, categorical, exResult, "upload")

    return(exResult)
}

.ajcc7Filter <- function(input, dataset) {
    expression <- "AJCC7 Chapter and Schema"
    dataset <- dataset %>%
            dplyr::filter(AJCC7_ID %in% input$AJCC7Chapter) %>%
            dplyr::filter(AJCC7_SUBID %in% input$AJCC7Schema)

    return(list(expression, dataset))
}

.vghtpeGroupFilter <- function(input, dataset) {
    expression <- "VGHTPE GROUP"
    dataset <- dplyr::filter(dataset, VGHTPE_GROUP %in% input$vghtpeGroup)

    return(list(expression, dataset))
}

.mainO3TFilter <- function(input, dataset) {
    expression <- "O3T Cancer Type"
    dataset <- dplyr::filter(dataset, MAIN_O3T == input$cancerType)
    return(list(expression, dataset))
}