vghcarETL <- function (input, dataset, metadata) {
    overall   <- metadata$Overall
    variable  <- metadata$Variable
    level     <- metadata$Level
    schema    <- metadata$Schema
    stageType <- input$stageType
    cohortCount <- input$cohortCount

    if (is.null(stageType) |
        is.null(dataset) |
        is.null(overall) |
        is.null(variable) |
        is.null(level) |
        is.null(schema) |
        !is.null(dataset["Error", "Error Message"]) |
        !is.null(overall["Error", "Error Message"]) |
        !is.null(variable["Error", "Error Message"]) |
        !is.null(level["Error", "Error Message"])
    ) {
        return(NULL)
    }

    withProgress(
        message = 'Extract-Load-Transform process.',
        detail = "Replace categorical or nominal label by layer 2 metadata.",
        value = 0,
        expr = {
            incProgress(0.2, detail = "Extend standard column by layer 1 metadata.")
            setting <- setNames(overall$Colname, overall$Standard)
            settingLength <- length(setting)
            for (row in 1:settingLength) {
                extendColumn <- overall$Standard[row]
                formula <- paste0("dplyr::mutate(dataset, ", extendColumn, " = ", setting[extendColumn], ")")
                dataset <- eval(parse(text = formula))
                if ("Event" == substr(extendColumn, 0, 5)) {
                    itemLabel <- dplyr::filter(level, Colname == extendColumn)
                    dataset[, extendColumn] <- factor(
                        dataset[, extendColumn],
                        levels = itemLabel$Value,
                        labels = itemLabel$Label
                    )
                }
            }

            incProgress(0.2, detail = "Replace categorical label by layer 3 metadata.")
            nominal <- dplyr::filter(variable, Type %in% c("Categorical"))
            dataset <- .transferNominal2Factor(dataset, nominal, level)

            if (cohortCount > 1) {
                # TODO: 之後改成三個以上的時候，再研究迴圈
                cohortDuration1 <- as.character(input$cohortDuration1)
                cohort1stStart  <- cohortDuration1[1]
                cohort1stEnd    <- cohortDuration1[2]
                cohortDuration2 <- as.character(input$cohortDuration2)
                cohort2ndStart  <- cohortDuration2[1]
                cohort2ndEnd    <- cohortDuration2[2]
                dataset[,"CohortNo"] <- factor(
                    dataset[,"CohortNo"],
                    levels = c("1", "2"),
                    labels = c(paste0(cohort1stStart, "~", cohort1stEnd), paste0(cohort2ndStart, "~", cohort2ndEnd))
                )
            }

            incProgress(0.2, detail = "Copy AJCC 7 stage.")
            if (stageType %in% c("Simple", "Simple_0")) {
                dataset <- dplyr::mutate(dataset, AJCC_STAGE = STAGE)
            } else {
                dataset <- dplyr::mutate(dataset, AJCC_STAGE = STAGE_4C)
            }
            dataset <- moveColumnToFirst(dataset, "AJCC_STAGE")

            incProgress(0.2, detail = "Transfer AJCC 7 chapter and schema.")
            colname <- "AJCC7_ID"
            itemLabel <- dplyr::filter(level, Colname == colname)
            dataset[,colname] <- factor(
                dataset[,colname],
                levels = itemLabel$Value,
                labels = itemLabel$Label
            )
            dataset[,colname] <- factor(dataset[,colname])

            colname <- "AJCC7_SUBID"
            dataset[,colname] <- factor(
                dataset[,colname],
                levels = schema$SchemaId,
                labels = schema$SchemaName
            )
            dataset[,colname] <- factor(dataset[,colname])

            incProgress(0.2, detail = "Reorder column.")
            dataset <- moveColumnToFirst(dataset, "AGE_RANGE")
            dataset <- moveColumnToFirst(dataset, "SEX")
            dataset <- moveColumnToFirst(dataset, "AJCC_STAGE")
            dataset <- moveColumnToFirst(dataset, "START_DATE")
            dataset <- moveColumnToFirst(dataset, "UNIQ_UUID")
        }
    )
    return(dataset)
}

.transferNominal2Factor <- function(dataset, nominal, level) {
    withProgress(
        message = 'Transfer nominal column into user-define label.',
        detail = "Count size of nominal list.",
        value = 0,
        expr = {
            nominalSize <- length(nominal$Colname)
            unitSize <- 1 / nominalSize
            for (colname in nominal$Colname) {
                incProgress(
                    amount = unitSize,
                    detail = paste("Convert ", colname, " column.")
                )
                itemLabel <- dplyr::filter(level, Colname == colname)
                dataset[,colname] <- factor(
                    dataset[,colname],
                    levels = itemLabel$Value,
                    labels = itemLabel$Label
                )
                dataset[,colname] <- factor(dataset[,colname])
            }
        }
    )
    return(dataset)
}
