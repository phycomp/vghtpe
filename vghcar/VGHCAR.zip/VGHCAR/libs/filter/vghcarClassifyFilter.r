vghcarClassifyFilter <- function(input, exResult) {
    classifyOption <- input$classifyOption
    if (is.null(classifyOption)) {
        return(exResult)
    }

    if ("AJCC7_ID" == classifyOption) {
        result <- filterTemplate(input, exResult, .ajcc7Filter)
        result <- .processAjcc7Data(result)
    } else if ("VGHTPE_GROUP" == classifyOption) {
        result <- filterTemplate(input, exResult, .vghtpeGroupFilter)
        result <- .processVghtpeGroupData(result)
    } else if ("MAIN_O3T" == classifyOption) {
        result <- filterTemplate(input, exResult, .mainO3TFilter)
        result <- .processMainO3TData(result)
    }

    return(result)
}

.processAjcc7Data <- function(result) {
    data <- result[[1]]
    data <- data[,-match(c("VGHTPE_GROUP", "MAIN_O3T"), colnames(data))]
    data <- moveColumnToFirst(data, "AJCC7_SUBID")
    data <- moveColumnToFirst(data, "AJCC7_ID")
    result[[1]] <- data
    return(result)
}

.processVghtpeGroupData <- function(result) {
    data <- result[[1]]
    data <- data[,-match(c("AJCC7_ID", "AJCC7_SUBID", "MAIN_O3T"), colnames(data))]
    data <- moveColumnToFirst(data, "VGHTPE_GROUP")
    result[[1]] <- data
    return(result)
}

.processMainO3TData <- function(result) {
    data <- result[[1]]
    data <- data[,-match(c("AJCC7_ID", "AJCC7_SUBID", "VGHTPE_GROUP"), colnames(data))]
    data <- moveColumnToFirst(data, "MAIN_O3T")
    result[[1]] <- data
    return(result)
}

.ajcc7Filter <- function(input, dataset) {
    expression <- "AJCC7 Chapter and Schema"

    dataset <- dataset %>%
            dplyr::filter(AJCC7_ID %in% input$AJCC7Chapter) %>%
            dplyr::filter(AJCC7_SUBID %in% input$AJCC7Schema)

    dataset <- moveColumnToFirst(dataset, "AJCC7_SUBID")
    dataset <- moveColumnToFirst(dataset, "AJCC7_ID")

    return(list(expression, dataset))
}

.vghtpeGroupFilter <- function(input, dataset) {
    expression <- "VGHTPE GROUP"

    dataset <- dplyr::filter(dataset, VGHTPE_GROUP %in% input$vghtpeGroup)
    dataset <- moveColumnToFirst(dataset, "VGHTPE_GROUP")
    return(list(expression, dataset))
}

.mainO3TFilter <- function(input, dataset) {
    expression <- "O3T Cancer Type"

    dataset <- dplyr::filter(dataset, MAIN_O3T == input$cancerType)
    dataset <- moveColumnToFirst(dataset, "MAIN_O3T")
    return(list(expression, dataset))
}