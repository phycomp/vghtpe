vghcarClassifyOptions <- function(classifyOption, metadata, ajcc7ChapterValue) {
    ui <- NULL
    carLayer3 <- metadata$Level
    schemaLevel <- metadata$Schema

    options <- .pickupOptions(carLayer3, classifyOption)
    if ("AJCC7_ID" == classifyOption) {
        chapterOptions <- options
        schemaOptions  <- .ajcc7SchemaOptions(schemaLevel, ajcc7ChapterValue)
        ui <- .ajcc7(ajcc7ChapterValue, chapterOptions, schemaOptions)
    } else if ("VGHTPE_GROUP" == classifyOption) {
        ui <- .vghtpeGroup(options)
    } else if ("MAIN_O3T" == classifyOption) {
        ui <- .cancerType(options)
    }

    return(ui)
}

.ajcc7 <- function(ajcc7ChapterValue, chapterOptions, schemaOptions) {
    ui <- tagList(
        selectizeInput(
            inputId   = "AJCC7Chapter",
            label     = "AJCC7 Chapter",
            selected  = ajcc7ChapterValue,
            multiple  = TRUE,
            choices   = chapterOptions
        ),
        selectizeInput(
            inputId   = "AJCC7Schema",
            label     = "AJCC7 Schema",
            selected  = schemaOptions,
            multiple  = TRUE,
            choices   = schemaOptions
        )
    )
    return(ui)
}

.vghtpeGroup <- function(options) {
    ui <- selectizeInput(
        inputId   = "vghtpeGroup",
        label     = "VGHTPE GROUP",
        multiple  = TRUE,
        selected  = "",
        choices   = options
    )
    return(ui)
}

.cancerType <- function(options) {
    ui <- selectizeInput(
        inputId   = "cancerType",
        label     = "O3T Cancer Type",
        selected  = "C22",
        choices   = options
    )
    return(ui)
}

.pickupOptions <- function(carLayer3, choosedName) {
    if (is.null(carLayer3)) {
        return(NULL)
    }
    choosedLayer <- dplyr::filter(carLayer3, choosedName == Colname)
    options <- setNames(choosedLayer$Value, choosedLayer$Label)
    return(options)
}

.ajcc7SchemaOptions <- function (schemaLevel, ChapterIdList = NULL) {
    if (is.null(ChapterIdList)) {
        return(NULL)
    }

    schemaLevel <- dplyr::filter(schemaLevel, ChapterId %in% ChapterIdList)
    options <- setNames(schemaLevel$SchemaId, schemaLevel$SchemaName)

    return(options)
}
