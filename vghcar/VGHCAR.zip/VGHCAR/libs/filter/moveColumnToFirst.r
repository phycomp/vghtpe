moveColumnToFirst <- function(data, firstColname) {
    dataColumns <- colnames(data)
    newColnames <- c(firstColname, dataColumns[-match(firstColname, dataColumns)])
    newData <- data[,newColnames]

    return(newData)
}