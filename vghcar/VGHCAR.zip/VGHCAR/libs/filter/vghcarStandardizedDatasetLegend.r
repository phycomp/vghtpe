vghcarStandardizedDatasetLegend <- function(input) {
    downloadUI <- downloadButton(
        outputId  = "downloadStandardDataset",
        label = tags$span("Standardized Dataset", class = "h4"),
        class = "btn-primary btn-block"
    )

    totalUI <- tagList(downloadUI)

    return(totalUI)
}