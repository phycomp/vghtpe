vghcarStageFilter <- function(input, exResult) {
    stageType <- input$stageType
    if (is.null(stageType)) {
        return(exResult)
    }

    if ("Simple" == stageType) {
        result <- checkboxFilter(
            exResult     = exResult,
            filterColumn = "STAGE",
            valueList    = c('1', '2', '3', '4'),
            expression   = "Stage I, II, III, IV"
        )
    } else if ("Stage4C" == stageType) {
        result <- checkboxFilter(
            exResult     = exResult,
            filterColumn = "STAGE_4C",
            valueList    = c('1', '2', '3', '4', 'C'),
            expression   = "Stage I, II, III, IV/IVA/IVB, IVC"
        )
    } else if ("Simple_0" == stageType) {
        result <- checkboxFilter(
            exResult     = exResult,
            filterColumn = "STAGE",
            valueList    = c('0', '1', '2', '3', '4'),
            expression   = "Stage O, I, II, III, IV"
        )
    } else if ("Stage4C_0" == stageType) {
        result <- checkboxFilter(
            exResult     = exResult,
            filterColumn = "STAGE_4C",
            valueList    = c('0', '1', '2', '3', '4', 'C'),
            expression   = "Stage O, I, II, III, IV/IVA/IVB, IVC"
        )
    } else if ("allStage" == stageType) {
        result <- exResult
    }

    return(result)
}