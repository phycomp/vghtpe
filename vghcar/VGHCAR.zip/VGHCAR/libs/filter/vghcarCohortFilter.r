vghcarCohortFilter <- function(input, exResult) {
    cohortCount <- input$cohortCount
    if (1 == cohortCount) {
        result <- filterTemplate(input, exResult, .oneCohortFilter)
    } else if (2 == cohortCount) {
        result <- .multipleCohortResult(input, exResult)
    }

    return(result)
}

.singleCohortFilter <- function(cohortDuration, dataset) {
    cohortDurationChar <- as.character(cohortDuration)
    cohortStart <- cohortDurationChar[1]
    cohortEnd   <- cohortDurationChar[2]

    expression <- paste0(">>> in cohort ", cohortStart, " ~ ", cohortEnd)

    dataset <- dataset %>%
        dplyr::filter(START_DATE >= cohortStart) %>%
        dplyr::filter(START_DATE <= cohortEnd)

    return(list(expression, dataset))
}

.oneCohortFilter <- function(input, dataset) {
    return(.singleCohortFilter(input$cohortDuration, dataset))
}

.firstCohortFilter <- function(input, dataset) {
    return(.singleCohortFilter(input$cohortDuration1, dataset))
}

.secondCohortFilter <- function(input, dataset) {
    return(.singleCohortFilter(input$cohortDuration2, dataset))
}

.multipleCohortResult <- function(input, exResult) {
    # TODO: 之後改成三個以上的時候，再研究迴圈
    nowExResult <- exResult
    firstExResult <- filterTemplate(input, exResult, .firstCohortFilter)
    secondExResult <- filterTemplate(input, exResult, .secondCohortFilter)

    firstData <- firstExResult[[1]] %>% dplyr::mutate(CohortNo = 1)
    firstData <- moveColumnToFirst(firstData, "CohortNo")
    firstTable <- firstExResult[[2]][[1]]

    secondData <- secondExResult[[1]] %>% dplyr::mutate(CohortNo = 2)
    secondData <- moveColumnToFirst(secondData, "CohortNo")
    secondTable <- secondExResult[[2]][[1]]

    concateFilterTable <- exResult[[2]][[1]]
    concateFilterCount <- exResult[[2]][[2]]

    concateData <- rbind(firstData, secondData)
    concateDataCount <- count(concateData)[[1]]

    concateFilterCount <- concateFilterCount + 1
    concateFilterTable[concateFilterCount, "Expression"] <- ">>> multiple cohort table <<<"
    concateFilterTable[concateFilterCount, "Before"] <- 0
    concateFilterTable[concateFilterCount, "Difference"] <- 0
    concateFilterTable[concateFilterCount, "After"] <- 0

    concateFilterCount <- concateFilterCount + 1
    concateFilterTable[concateFilterCount,] <- firstTable[2,]
    concateFilterCount <- concateFilterCount + 1
    concateFilterTable[concateFilterCount,] <- secondTable[2,]

    concateFilterCount <- concateFilterCount + 1
    concateFilterTable[concateFilterCount, "Expression"] <- ">>> concate cohort table <<<"
    concateFilterTable[concateFilterCount, "Before"] <- 0
    concateFilterTable[concateFilterCount, "Difference"] <- 0
    concateFilterTable[concateFilterCount, "After"] <- concateDataCount
    concateNote <- list(concateFilterTable, concateFilterCount)


    result <- list(concateData, concateNote, concateDataCount)
    return(result)
}