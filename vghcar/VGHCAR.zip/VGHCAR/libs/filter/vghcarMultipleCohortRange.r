vghcarMultipleCohortRange <- function(cohortCount) {
    ui <- NULL

    if (1 == cohortCount) {
        ui <- dateRangeInput(
            inputId   = "cohortDuration",
            label     = "Cohort",
            start     = "2011-01-01",
            end       = "2015-12-31",
            startview = "year"
        )
    } else if (2 == cohortCount) {
        # TODO: 之後改成三個以上的時候，再研究迴圈
        ui <- tagList(
            dateRangeInput(
                inputId   = "cohortDuration1",
                label     = "First Cohort",
                start     = "2007-01-01",
                end       = "2011-12-31",
                startview = "year"
            ),
            dateRangeInput(
                inputId   = "cohortDuration2",
                label     = "Second Cohort",
                start     = "2011-01-01",
                end       = "2015-12-31",
                startview = "year"
            )
        )
    }

    return(ui)
}