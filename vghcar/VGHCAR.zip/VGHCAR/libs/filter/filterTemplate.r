filterTemplate <- function(input, exResult, filterFunction) {
    dataset <- exResult[[1]]
    beforeFilterCount <- count(dataset)[[1]]

    # callback function
    filterResult <- filterFunction(input, dataset)
    expression <- filterResult[[1]]
    filteredDataset <- filterResult[[2]]
    # callback function end

    afterFilterCount <- count(filteredDataset)[[1]]
    differenceCount <- beforeFilterCount - afterFilterCount

    exFilterNote <- exResult[[2]]
    filterNote <- recordFilterNote(exFilterNote, expression, beforeFilterCount, afterFilterCount, differenceCount)

    result <- list(filteredDataset, filterNote, afterFilterCount)

    return(result)
}