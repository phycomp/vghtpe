vghcarContingencyTableXaxis <- function (axis, value, type) {
    ui <- selectInput(
        inputId   = paste0(type, "ContingencyTableXaxis"),
        label     = tags$h6("Column label"),
        width     = "400px",
        selected  = value,
        choices   = axis
    )
    return(ui)
}
