vghcarCategoricalAxis <- function(variable, showStandard = FALSE, showOverall = FALSE) {
    if (!is.null(variable)) {
        variable <- dplyr::filter(variable, Type %in% c("Categorical", "Nominal", "Ordinal"))
        axis <- setNames(variable$Colname, variable$Label)

        if (showOverall) {
            overallClassChoices <- c("Overall" = "OverallClassChoices")
        } else {
            overallClassChoices <- NULL
        }

        if (showStandard) {
            standardClassChoices <- c(
                "LCR - Local Control Rate"                       = "EventLCR",
                "LRCR - Locoregional Control Rate"               = "EventLRCR",
                "DMCR - Distant Metastase Control Rate"          = "EventDMCR",
                "NCR - Nodal Control Rate"                       = "EventNCR",
                "OS - Overall Survival"                          = "EventOS",
                "DSS - Disease Specific Survival"                = "EventDSS",
                "PFS - Progression Free Survival"                = "EventPFS",
                "LPFS - Local Progression Free Survival"         = "EventLPFS",
                "LRPFS - Locoregional Progression Free Survival" = "EventLRPFS",
                "DMFS - Distant Metastase Free Survival"         = "EventDMFS"
            )
        } else {
            standardClassChoices <- NULL
        }

        if (showOverall | showStandard) {
            axis <- list(
                "Overall" = overallClassChoices,
                "Standard Column" = standardClassChoices,
                "Dataset Column" = axis
            )
        }
    } else {
        axis <- c(" ")
    }

    return(axis)
}
