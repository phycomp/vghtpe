# 這一隻純粹是用來產生 AJCC7.csv 的程式

AJCC7_Chapter <- read.csv("D:/MCC/libs/AJCC7/AJCC7_Chapter.csv",
                  encoding = "utf8",
                  strip.white = TRUE,
                  stringsAsFactors = FALSE
)

AJCC7_Schema <- read.csv("D:/MCC/libs/AJCC7/AJCC7_Schema.csv",
                  encoding = "utf8",
                  strip.white = TRUE,
                  stringsAsFactors = FALSE
)

AJCC7_O3T <- read.csv("D:/MCC/libs/AJCC7/AJCC7_O3T.csv",
                  encoding = "utf8",
                  strip.white = TRUE,
                  stringsAsFactors = FALSE
)

AJCC7_O3M <- read.csv("D:/MCC/libs/AJCC7/AJCC7_O3M.csv",
                  encoding = "utf8",
                  strip.white = TRUE,
                  stringsAsFactors = FALSE
)

AJCC7 <- left_join(AJCC7_Schema, AJCC7_Chapter, by = "ChapterId") %>%
    left_join(AJCC7_O3T, by = "SchemaId") %>%
    left_join(AJCC7_O3M, by = "ChapterId") %>%
    mutate(O3MBegin = ifelse(is.na(O3MBegin), 0, O3MBegin)) %>%
    mutate(O3MEnd = ifelse(is.na(O3MEnd), 9999, O3MEnd))


# 產生半成品後，再自行新增特例
# 特例：chapter 10, 36, 37, 47, 57A, 57B
write.csv(AJCC7, file = "D:/MCC/libs/AJCC7/AJCC7.csv", row.names = FALSE, eol = "\n")
