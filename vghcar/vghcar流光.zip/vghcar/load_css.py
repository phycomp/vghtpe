from streamlit import markdown as stMarkdown

def local_css(file_name):
  with open(file_name) as fin:
    cssInfo=fin.read()
    stMarkdown(f'<style>{cssInfo}</style>', unsafe_allow_html=True)
