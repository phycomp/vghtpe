MENUs=['資料庫', 'Filter', 'Profiling', 'CSV', 'SurvivalAnalysis', 'cncrCLMN', 'nuvStage', 'StartDate',  'AJCC期別', 'fullStage完整期別', 'CLG/PSG期別值', 'HPA整併期別']   #[step1, step2, step3, step4]=vghcarAna='AllCancer', 

def run():
  #try: from vghcar.sdbrWdgt import Sdbr
  #except: from sdbrWdgt import Sdbr

  #from vghcar.sdbrWdgt import Sdbr
  #sdbr=Sdbr()
  from streamlit import sidebar
  '''
  try:
    sdbr=session_state['sdbr']
    print('session_state', sdbr.option)
  except:
    sdbr=Sdbr()
    session_state['sdbr']=sdbr
    print('sdbr instance')
  '''

  #stWrite(sdbr.schm)
  option=sidebar.radio('', MENUs)
  if option==MENUs[-7]:
    'cncrCLMN'
    from streamlit import dataframe, session_state, radio as stRadio, write as stWrite
    stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between}</style>', unsafe_allow_html=True)
    cncrCLMN=session_state['cncrCLMN']
    clmn=stRadio('', cncrCLMN)
    allCncr=session_state['AllCancer']
    dataframe(allCncr[clmn].unique())
  elif option==MENUs[-6]:
    'nuvStage'
    from vghcar.mergeStage import nuvStage
    from streamlit import dataframe, session_state, write as stWrite
    cncrCLMN=session_state['cncrCLMN']
    allCncr=session_state['AllCancer']
    ndxPRIST=cncrCLMN.index('TCDB_PRIST')
    ndxCLM=cncrCLMN.index('TCDB_CLM')
    ndxCLG=cncrCLMN.index('TCDB_CLG')
    ndxPAN=cncrCLMN.index('TCDB_PAN')
    ndxPAM=cncrCLMN.index('TCDB_PAM')
    ndxPSG=cncrCLMN.index('TCDB_PSG')
    ndxPSD=cncrCLMN.index('TCDB_PSD')
    ndxDOMSUPS=cncrCLMN.index('TCDB_DOMSUPS')
    ndxSPPSTF=cncrCLMN.index('TCDB_SPPSTF')
    allCncr['FullStage']=allCncr.apply(nuvStage, axis=1, args=(ndxPRIST, ndxCLM, ndxCLG, ndxPAN, ndxPAM, ndxPSG, ndxPSD, ndxDOMSUPS, ndxSPPSTF))
    stWrite(allCncr.FullStage[allCncr['FullStage']=='888'])
  elif option==MENUs[-5]:
    'StartDate'
    from streamlit import write as stWrite, dataframe, session_state
    from vghcar.開始日期 import rtrvStartDate
    allCncr=session_state['AllCancer']
    cncrCLMN=session_state['cncrCLMN']
    #clmnInfo=allCncr.columns.to_list()
    ndxDOID=cncrCLMN.index('TCDB_DOID')
    ndxDOFC=cncrCLMN.index('TCDB_DOFC')
    ndxPB3TDATE=cncrCLMN.index('PBC_PB3TDATE')
    allCncr['StartDate']=None
    #allCncr.StartDate=allCncr.apply(rtrvStartDate, args=(ndxDOID, ndxDOFC))
    allCncr.apply(rtrvStartDate, axis=1, args=(ndxDOID, ndxDOFC, ndxPB3TDATE))
    #dataframe(allCncr.query('TCDB_DOID.notna()').TCDB_DOID)    #isnotna()==TCDB_DOID
    #def nullStartDate(x): nullStartdate 
    stWrite(len(allCncr.StartDate.apply(lambda x: None if not x.strip('') else x)))    #[allCncr.StartDate!='']isnotna()==TCDB_DOID
    #allCncr.query("AJCC7_ID=='14' & START_DATE >='2010-01-01' & START_DATE<='2017-12-31' & VGHTPE_GROUP==VGHTPE_GROUP & STAGE=='1'")
  elif option==MENUs[-4]:
    from vghcar.整併期別 import AJCC期別
    from streamlit import write as stWrite, dataframe, session_state
    from vghcar.loaddata import loadData
    try:
      allCncr=session_state['AllCancer']
      ajcc7=session_state['ajcc7']
      ajcc7Gndr=session_state['ajcc7Gndr']
      #ajcc7=session_state['ajcc7']
    except:
      ajcc7=loadData('AJCC7/AJCC7.csv') #, Profile
      ajcc7Gndr=loadData('AJCC7/AJCC7_Gender.csv')  #, Profile
      session_state['ajcc7']=ajcc7
      session_state['ajcc7Gndr']=ajcc7Gndr
    allCncrClmns=allCncr.columns.to_list()
    stWrite(allCncrClmns)
    sexNdx=allCncrClmns.index('TCDB_SEX')
    pristNdx=allCncrClmns.index('TCDB_PRIST')
    O3Mndx=allCncrClmns.index('TCDB_HISTGY')
    allCncr['ajccID']=None
    allCncr['ajccTitle']=None
    allCncr['ajccSchmID']=None
    allCncr['ajccSchmTitle']=None
    allCncr.apply(AJCC期別, axis=1, args=(ajcc7, ajcc7Gndr, sexNdx, pristNdx, O3Mndx))
    dataframe(allCncr[['ajccID', 'ajccTitle', 'ajccSchmID', 'ajccSchmTitle']])
  elif option==MENUs[-3]:
    from vghcar.整併期別 import rtrvFullStage
    from streamlit import write as stWrite, dataframe, session_state
    allCncr=session_state['AllCancer']
    cncrCLMN=session_state['cncrCLMN']
    allCncr['fullStage']=None
    #allCncr['AJCC期別']=None
    #clmnInfo=allCncr.columns.to_list()
    #dataframe(allCncr.columns)
    #dataframe(allCncr[['CLG_VALUE', 'PSG_VALUE']])
    ndxCLG=cncrCLMN.index('CLG_VALUE')
    ndxPSG=cncrCLMN.index('PSG_VALUE')
    allCncr.apply(rtrvFullStage, axis=1, args=(ndxCLG, ndxPSG))
    stWrite(allCncr['fullStage'].unique())
  elif option==MENUs[-2]:
    'CLG/PSG期別值'
    from streamlit import dataframe, session_state
    from vghcar.整併期別 import rdcCLG
    allCncr=session_state['AllCancer']
    allCncr['CLG_VALUE']=rdcCLG(allCncr['TCDB_CLG'])
    allCncr['PSG_VALUE']=rdcCLG(allCncr['TCDB_PSG'])
    #dataframe(allCncr[['CLG_VALUE', 'PSG_VALUE']])
  elif option==MENUs[-1]:
    'HPA整併期別'
    from vghcar.整併期別 import 整併期別
    #from vghcar.整併期別 import 合併期別
    from streamlit import write as stWrite, dataframe, session_state

    allCncr=session_state['AllCancer']
    cncrCLMN=session_state['cncrCLMN']
    #cncrClmns=allCncr.columns.to_list()
    #dataframe(cncrClmns)
    ndxCM, ndxPM=cncrCLMN.index("TCDB_CLM"), cncrCLMN.index("TCDB_PAM")
    ndx原發部位, ndx手術類別, ndx手術日期=cncrCLMN.index("TCDB_PRIST"), cncrCLMN.index("TCDB_SPPSTF"), cncrCLMN.index("TCDB_DOMSUPS")

    ndx癌症, ndx臨床, ndx病理, ndx字根=cncrCLMN.index('PBC_PGROUP1'), cncrCLMN.index('TCDB_CLG'), cncrCLMN.index('TCDB_PSG'), cncrCLMN.index('TCDB_PSD')  #43 PBC_PGROUP1, 129 TCDB_CLG, 135 TCDB_PSG, 136 TCDB_PSD
    allCncr['HPA期別']=None
    #allCncr.apply(合併期別, axis=1, args=(ndx癌症, ndx臨床, ndx病理, ndx字根))
    allCncr.apply(整併期別, axis=1, args=(ndx癌症, ndx臨床, ndx病理, ndx字根, ndx原發部位, ndx手術類別, ndx手術日期, ndxCM, ndxPM))
    stWrite(allCncr['HPA期別'].unique())
    #stWrite(len(df['HPA期別']))
  #elif option==MENUs[0]:
  #  from vghcar.cncrProfile import rtrvCncr
  #  rtrvCncr()
  elif option==MENUs[0]:#first
    #from vghcar.queryTCDB import queryTCDB
    from dbMnpl.strmltPGconn import runQuery
    from pandas import DataFrame
    from streamlit import session_state, dataframe, write as stWrite #cache as stCache, write as stWrite, pyplot, altair_chart, text as stText#plotly_chart
    from re import findall
    #from plotly.graph_objs import Figure, Scatter
    #from streamlit.components.v1 import html#, declare_component
    #from vghcar.loaddata import loadData
    #p."PDESC" "PBAB_PDESC", p."PLSTVDT" "PBAS_PLSTVDT", p."PMEDSTAT" "PBAS_PMEDSTAT", 
    #cncrClmns=["PBC_PGROUP1", "PBC_TFLAG", "PBC_TDATE", "PBC_NFLAG", "PBC_NDATE", "PBC_MFLAG", "PBC_MDATE", "PBC_DFSDATE", "PBC_PB3MDATE", "PBC_PB3TDATE", "TCDB_DOFC", "TCDB_CISTCSER", "TCDB_DATATYPE", "TCDB_PHISTNUM", "TCDB_SEX", "TCDB_DISAGE", "TCDB_PRIST", "TCDB_HISTGY", "TCDB_PSG", "TCDB_CLG", "TCDB_PSD", "TCDB_CLT", "TCDB_CLN", "TCDB_CLM", "TCDB_PAT", "TCDB_PAN", "TCDB_PAM", "TCDB_VOTHSTG", "TCDB_COTHSTG", "TCDB_DOID", "TCDB_DLCOD", "TCDB_COAOD", "TCDB_VITSS", "TCDB_SPPSTF", "TCDB_DOMSUPS"]
    #tcdbGndr, tcdbPRIST, icdO3M=row.name
    fullQuery='''select distinct p."PGROUP1" "PBC_PGROUP1", p."TFLAG" "PBC_TFLAG", p."TDATE" "PBC_TDATE", p."NFLAG" "PBC_NFLAG", p."NDATE" "PBC_NDATE", p."MFLAG" "PBC_MFLAG", p."MDATE" "PBC_MDATE", p."DFSDATE" "PBC_DFSDATE", p."PB3MDATE" "PBC_PB3MDATE", p."PB3TDATE" "PBC_PB3TDATE", c."DOFC" "TCDB_DOFC", c."CISTCSER" "TCDB_CISTCSER", c."DATATYPE" "TCDB_DATATYPE", c."PHISTNUM" "TCDB_PHISTNUM", c."SEX" "TCDB_SEX", c."DISAGE" "TCDB_DISAGE", c."PRIST" "TCDB_PRIST", c."HISTGY" "TCDB_HISTGY", c."PSG" "TCDB_PSG", c."CLG" "TCDB_CLG", c."PSD" "TCDB_PSD", c."CLT" "TCDB_CLT", c."CLN" "TCDB_CLN", c."CLM" "TCDB_CLM", c."PAT" "TCDB_PAT", c."PAN" "TCDB_PAN", c."PAM" "TCDB_PAM", c."VOTHSTG" "TCDB_VOTHSTG", c."COTHSTG" "TCDB_COTHSTG", c."DOID" "TCDB_DOID", c."DLCOD" "TCDB_DLCOD", c."COAOD" "TCDB_COAOD", c."VITSS" "TCDB_VITSS", c."SPPSTF" "TCDB_SPPSTF", c."DOMSUPS" "TCDB_DOMSUPS" from "VGHLNXTS"."CISTCRM"c inner join "VGHLNXTS"."PBCANCER"p on trim(p."PHISTNUM") <> '' AND trim(p."PHISTNUM")=trim(c."PHISTNUM") and p."PBCSEQNO"=c."PBCSEQNO" and p."PBCFLAG"=1 and (p."PTRTST01" in ('1', '2') OR c."CLASS" in ('1', '2')) and NOT ((p."PBCRSTUS"='2' OR p."PBCRSTUS"='1') AND p."PBCFLAG"=0) AND p."PBCFLAG"!=2 and (SUBSTR(p."PBICD9",1,3)!='225' AND SUBSTR(p."PBICD9",1,3)!='227') and p."PHISTNUM"<>'113' and trim(p."PGROUP1")<>'' ;''' #limit 10000
    cncrClmns=findall('\w+_\w+', fullQuery)
    try:
      cncrDFrm=session_state['AllCancer']
      cncrCLMN=session_state['cncrCLMN']
    except:
      rsltTCDB=runQuery(fullQuery, db='bdprod')
      cncrDFrm=DataFrame(data=rsltTCDB, columns=cncrClmns, dtype='str')
      session_state['AllCancer']=cncrDFrm
      session_state['cncrCLMN']=cncrClmns
    '''
    rsltTCDB=runQuery(fullQuery, db='bdprod')
    cncrDFrm=DataFrame(data=rsltTCDB, columns=cncrClmns, dtype='str')
    session_state['AllCancer']=cncrDFrm
    session_state['cncrCLMN']=cncrClmns
    '''
    stWrite(cncrDFrm.columns)
    stWrite(len(cncrDFrm))
    dataframe(cncrDFrm)
  elif option==MENUs[1]:
    from vghcar.filter import rtrvAJCC
    rtrvAJCC()
  elif option==MENUs[2]:
    from vghcar.plotsurvival import SrvvlPlot
    SrvvlPlot()
  elif option==MENUs[3]:
    #df, dfProfile = loadData()  #df.profile_report()
    from streamlit import dataframe as stDataframe, session_state, subheader, markdown
    from base64 import b64encode
    df=session_state['AllCancer']
    subheader('Download')
    stDataframe(df)
    encdData=b64encode(df.to_csv(index=False).encode()).decode()
    markdown(f'<a href="data:file/csv;base64,{encdData}" download="data.csv">Download CSV</a>', unsafe_allow_html=True)
    #rmst_exp = restricted_mean_survival_time(kmf_exp, t=time_limit)t=time_limit, 
    #pyplot( kmf.plot())
    #plotly_chart( kmf.plot())
  elif option==MENUs[4]:
    from vghcar.srvvlana import SurvivalAnalysis
    SurvivalAnalysis()
__all__=['MENUs']
