from lifelines import KaplanMeierFitter
from matplotlib.pyplot import subplot, gcf
import matplotlib
from streamlit import session_state

def SrvvlPlot():
    matplotlib.use('Agg')
    #df, dfProfile = loadData()  #df.profile_report()
    df=session_state['AllCancer']
    from lifelines.plotting import rmst_plot
    #ax = subplot(31)
    ax = subplot(311)
    #rmst_plot(kmf_con, t=time_limit, ax=ax)
    #ax = subplot(313)
    #rmst_plot(kmf_exp, model2=kmf_con, t=time_limit, ax=ax)

    kmf = KaplanMeierFitter(label="VGHCAR")
    df=df.dropna()
    kmfExp=kmf.fit(df['OverallSurvivalDuration'], event_observed=df['OverallSurvivalEvent'], label='exp')
    #ax.figure.savefig('dummy.png')
    kmfExp.plot(title='OverallSurvivalDuration vs OverallSurvivalEvent ')
    KMF = gcf()
    pyplot(KMF)#.plot(ax=ax)rmst_plot(kmfExp, ax=ax))
