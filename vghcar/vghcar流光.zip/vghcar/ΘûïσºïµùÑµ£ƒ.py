from streamlit import session_state
def rtrvStartDate(row, ndxDOID, ndxDOFC, ndxPB3TDATE):
    rowNdx, TCDB_DOID, TCDB_DOFC, PB3TDATE=row.name, row[ndxDOID], row[ndxDOFC], row[ndxPB3TDATE]
    if TCDB_DOID.strip(''): startDate=TCDB_DOID
    elif TCDB_DOFC.strip(''): startDate=TCDB_DOFC
    else: startDate=PB3TDATE
    allCncr=session_state['AllCancer']
    allCncr['StartDate'][rowNdx]=startDate
