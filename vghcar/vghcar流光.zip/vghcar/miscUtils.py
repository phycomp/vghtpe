from re import search, sub as reSub
#from numpy import array, std, mean, float as npfloat
def vldtDate(indate):
  if search('-', indate): year, month, day=indate.split('-')      #indate.find('-')
  elif len(indate)==8:
    #dateYear=DOB[:4] dateMonth=DOB[4:6] dateDay=DOB[6:]
    dateYear, dateMonth, dateDay=indate[:4], indate[4:6], indate[6:]
    if dateYear in ['8888', '9999', '0000']: dateYear='NA'
    if dateDay=='99': dateDay='15'
    cncrDate='-'.join([dateYear, dateMonth, dateDay])
    if cncrDate.find('NA-NA-NA')!=-1: cncrDate=reSub('NA-NA-NA', 'NA', cncrDate)
    if cncrDate.find('--')!=-1: cncrDate=reSub('--', 'NA', cncrDate)
    return cncrDate
  '''
  else:
    #if year=='9999':year='NA'
    elif month=='99':month='07'
    elif day=='99':day='15'
    elif indate.find('-')!=-1: indate=indate.replace('-', '')
  return ''.join([year, month, day])

  '''
