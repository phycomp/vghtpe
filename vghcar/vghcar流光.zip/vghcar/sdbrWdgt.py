from streamlit import sidebar, subheader, write as stWrite, empty, session_state#, text_input
from pandas import DataFrame, read_csv, concat
from re import search
#from pathlib import PATH
from pathlib import Path
from vghcar.load_css import local_css
from vghcar import MENUs

absPath=Path(__file__).parent
local_css(absPath/'style.css')
#absPath=fPath
#stWrite(absPath)
#print(PROJECT_ROOT, PACKAGE_ROOT)
chptrPath, schmPath=f'{absPath}/AJCC7_Chapter.csv', f'{absPath}/AJCC7_Schema.csv'
ajcc7Chptr=read_csv(chptrPath, dtype='str', comment='#')
ajcc7Schm=read_csv(schmPath, dtype='str', comment='#')
session_state['ajcc7Chptr']=ajcc7Chptr
session_state['ajcc7Schm']=ajcc7Schm
#chptr=read_csv('AJCC7_Chapter.csv', comment='#')
#schm=read_csv('AJCC7_Schema.csv', comment='#')
#MENUs=['AllCancer', 'Filter', 'Profiling', 'CSV', 'SurvivalAnalysis']
class Sdbr:
  def filterSchm(self, schm):
    if self.chptr:
      #Chptrs=filter(lambda x:search('\d+', x).group(1), self.chptr)
      Chptrs=map(lambda x:search('\d+', x).group(0), self.chptr)
      Chptrs=list(Chptrs)
      tmpSchm=[]
      for chp in Chptrs:
        tmp=schm[schm['ChapterId']==int(chp)]
        #schm[['SchemaId', 'SchemaName']]
        print(tmp[['SchemaName', 'SchemaId']])
        tmpSchm.extend([chp+v+str(vv) for v,vv in tmp[['SchemaName', 'SchemaId']].values])
        #tmpSchm=schm[]
        #print(schm['SchemaName'][schm['ChapterId']==Chptrs])
      #dfSchm=DataFrame(tmpSchm, columns=['chptr', 'Schema'])
      #print(dfSchm)
      return sidebar.multiselect('', tmpSchm, default=tmpSchm)#, format_func=lambda x:','.join(x)) #concat()['SchemaName']tmpSchm[]['AJCC7']
    else: return None
  def __init__(self):
    #header = sidebar.header('')
    #self.ann = sidebar.text_input('input', value=0)
    self.option=sidebar.radio('', MENUs)
    if self.option==MENUs[0]:
      'AllCancer'
    elif self.option==MENUs[1]:
      chptrTitle=ajcc7Chptr['ChapterTitle']
      dfltChptr=chptrTitle[0] if chptrTitle.any() else None
      if dfltChptr: self.chptr=sidebar.multiselect('', chptrTitle, default=dfltChptr) #['AJCC7']
      else: self.chptr=sidebar.multiselect('', chptrTitle)
      stage=['0', '1', '2', '3', '4']
      stage4C=['0', '1', '2', '3', '4', 'C']
      stageT=['0', '1', '2', '3', '4', 'X']
      stageN=['0', '1', '2', '3', 'X']
      stageM=['0', '1', 'X']
      self.schm=self.filterSchm(ajcc7Schm)
      self.isFirst=sidebar.checkbox('isFirst')
      self.isChild=sidebar.checkbox('isChild')
      self.stage=sidebar.multiselect('stage', stage, default=stage)
      self.stage4C=sidebar.multiselect('stage4C', stage4C, default=stage4C)
      self.stageT=sidebar.multiselect('stageT', stageT, default=stageT)
      self.stageN=sidebar.multiselect('stageN', stageN, default=stageN)
      self.stageM=sidebar.multiselect('stageM', stageM, default=stageM)
      #self.stageT=sidebar.multiselect('stageT', options=[1, 2])
    elif self.option==MENUs[2]:
      #from lifelines import KaplanMeierFitter
      'KaplanMeierFitter'
    elif self.option==MENUs[3]:
      'Download'
    elif self.option==MENUs[4]:
      'PLOTLY'
      #self.NM=sidebar.button('NM', key='PLOT')#, option=True
      #self.KM=sidebar.button('KM', key='PLOT')#, option=True
      stWrite('<style>div.element-container.css-1e5imcs.e1tzin5v1> div{flex-direction:row}</style>', unsafe_allow_html=True)
      self.PLOT=sidebar.radio('PLOT', ['Kaplan-Meier', 'Nelson-Aalen'])#, key='PLOT')#, option=True
      session_state['PLOT']=self.PLOT
      #self.PLOT = sidebar.radio_set('PLOT', ['NM', 'KM'])
      #self.KM=sidebar.button('KM', ['KM'])#, option=True
    #sdbr.mltslct=df #AJCC7.keys()
    #self.userInput = text_input("", 'defaultText')
    #self.symbl=sidebar.radio('', SYMBLs)
    #self.btnAdd=sidebar.button('add')
    #self.option=sidebar.selectbox("", ('twitter', 'wallstreetbets', 'stocktwits', 'chart', 'pattern'), 3)
    #self.author_input = sidebar.text_input("by author name")
    #self.user_input = sidebar.text_area("by paper title") # User search
    #self.num_results = sidebar.slider("Number of search results", 10, 150, 10)

    #symblStatus=sidebar.radio('', symbl)
#sdbr=Sidebar()
#__all__=[Sdbr]
