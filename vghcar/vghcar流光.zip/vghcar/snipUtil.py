snipRaw=open('/home/josh/.vim/plugged/vim-snippets/UltiSnips/python.snippets').read()
print(snipRaw)
from re import findall, DOTALL
allSnip=findall('snippet (.*?) ', snipRaw);print(allSnip)
#if __name__ == "__main__": main()
