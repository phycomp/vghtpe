'''
from streamlit import session_state
try: sdbr=session_state['sdbr']
except:
  from vghcar.sdbrWdgt import Sdbr
  sdbr=Sdbr()
  session_state['sdbr']=sdbr
'''
from re import search
from streamlit import dataframe as stDataframe, session_state, dataframe, sidebar
from pandas import read_csv, concat
from pathlib import Path
from vghcar.loaddata import loadData

def filterSchm(chptr, schm):
  if chptr:
    Chptrs=map(lambda x:search('\d+', x).group(0), chptr)
    Chptrs=list(Chptrs)
    tmpSchm=[]
    for chp in Chptrs:
      tmp=schm[schm['ChapterId']==chp]
      tmpSchm.extend([chp+v+str(vv) for v,vv in tmp[['SchemaName', 'SchemaId']].values])
    return sidebar.multiselect('', tmpSchm, default=tmpSchm)

def rtrvAJCC():
    try:
      ajcc7Chptr=session_state['ajcc7Chptr']  #=ajcc7Chptr
      ajcc7Schm=session_state['ajcc7Schm']
      AJCC=session_state['AJCC']
      gndrAJCC=session_state['gndrAJCC']
      allCncr=session_state['AllCancer']
    except:
      absPath=Path(__file__).parent
      chptrPath, schmPath, ajccPath, gndrAJCCPath=f'{absPath}/AJCC7_Chapter.csv', f'{absPath}/AJCC7_Schema.csv', f'{absPath}/AJCC7/AJCC7.csv', f'{absPath}/AJCC7/AJCC7_Gender.csv'
      ajcc7Chptr=read_csv(chptrPath, dtype='str', comment='#')
      ajcc7Schm=read_csv(schmPath, dtype='str', comment='#')
      AJCC=read_csv(ajccPath, dtype='str', comment='#')
      gndrAJCC=read_csv(gndrAJCCPath, dtype='str', comment='#')
      session_state['ajcc7Chptr']=ajcc7Chptr
      session_state['ajcc7Schm']=ajcc7Schm
      session_state['AJCC']=AJCC
      session_state['gndrAJCC']=gndrAJCC
      allCncr=session_state['AllCancer']
      #allCncr=loadData(fname='newAllCancer2021.csv')   #.read()AllCancer2021-09-07.csv , profileDF

    from mkStageAJCC import stageAJCC
    allCncr[['ajccID', 'ajccTitle', 'ajccSchmID', 'ajccSchmTitle']]=None
    allCncr.apply(stageAJCC, axis=1, args=(allCncr, AJCC, gndrAJCC))  #, args=(df, allCncr))
    dataframe(allCncr)
    #dataframe(allCncr.query("ajccID='57' and ajccSchmID='163'")[]) allCncr['ajccID']=='57' & allCncr['ajccSchmID']=='163' 
    chptrTitle=ajcc7Chptr['ChapterTitle']
    dfltChptr=chptrTitle[0] if chptrTitle.any() else None
    if dfltChptr: chptr=sidebar.multiselect('', chptrTitle, default=dfltChptr) #['AJCC7']
    else: chptr=sidebar.multiselect('', chptrTitle)
    dataframe(allCncr)
    dataframe(ajcc7Schm)
    #allCncr.apply(stageAJCC, axis=1, args=(allCncr, ajcc7Chptr, ajcc7Schm))
    tmp=allCncr.copy(deep=True)
    tmpDF=[]
    ajccSchm=filterSchm(chptr, ajcc7Schm)
    for chptrSchm in ajccSchm:
      chptr, schm=search('(\d+).*?(\d+)', chptrSchm).groups()
      print('chptr, schm', chptr, schm)
      tmpDF.append(tmp.query(f"ajccID=='{chptr}' and ajccSchmID=='{schm}'"))#['ajccID']==chptr & tmp['ajccSchmID']==schm ])
      #tmpDF.append(allCncr[ajcc7Schm['ChapterId']==chptr & ajcc7Schm['SchemaId']==schm])
    #是將smartCarData 取出要看的資料subset
    #print(tmpDF)
    mergeDF=concat(tmpDF)
    #if sidebar.isChild:mergeDF=mergeDF[mergeDF['IS_CHILD']==1]
    #if sidebar.isFirst:mergeDF=mergeDF[mergeDF['IS_FIRST']==1]
    stDataframe(mergeDF)
    session_state['mergeDF']=mergeDF
    #df, dfProfile = loadData()  #df.profile_report()
    #st_profile_report(dfProfile)
    #html(dfProfile.to_html(), width=500, height=700)#unsafe_allow_html=True)
    #html(dfProfile.to_widgets())
