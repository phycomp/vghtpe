from streamlit import radio, sidebar, container, columns, dataframe, session_state, write as stWrite
from .mnplSeries import rdcCLG
from vghcar.loaddata import loadData

def rtrvCncr(): #'AllCancer'
    try:
      allCncr=session_state['AllCancer']
    except:
      fnameAllCncr=session_state['AllCancerFname']='newAllCancer2021.csv'
      allCncr, profileDF=loadData(fname=fnameAllCncr)   #.read()AllCancer2021-09-07.csv
      session_state['AllCancer']=allCncr
    期別=['CLG', 'PSG']
    stage=sidebar.radio('期別', 期別)
    startYear=sidebar.text_input('startCohort', value='2010')
    endYear=sidebar.text_input('endCohort', value='2017')
    #dataframe(dFrame[f'TCDB_{stage}'].unique())
    #dataframe(df[(df['TCDB_YEAR']>=startYear) | (df['TCDB_YEAR']<=endYear) ])
    #startYear, endYear=float(startYear), float(endYear)
    #psudoDF=df[df['TCDB_YEAR']<startYear]#.dropna()#df[]
    #dataframe(psudoDF)
    #psudoVOT=df['TCDB_VOTHSTG'].astype(str)#df[]
    #dataframe(psudoVOT)
    '''
    tcdbYEAR=df['TCDB_YEAR']
    psudoDF=df[tcdbYEAR.between(startYear, endYear)]#str.strip().astype(str)..dropna(axis='TCDB_YEAR')str.strip().
    stWrite(len(psudoDF))
    #df['Gender'].str.strip()tcdbYEAR.max(), inplace=True.fillna('')
    dataframe(psudoDF)  #.astype(str))
    print(psudoDF['PBC_PGROUP1'].unique())
    PGROUP1=df['PBC_PGROUP1'].unique()
    pgroup1=sidebar.radio('PGROUP1', PGROUP1)
    leftPane, rightPane=columns((1, 1))
    PGROUP2=df['PBC_PGROUP2'].unique()
    pgroup2=leftPane.multiselect('PGROUP2', PGROUP2)   #selectbox
    #psdPG=psudoDF['PBC_PGROUP2']
    rsltDF=psudoDF[psudoDF['PBC_PGROUP2'].isin(pgroup2)]
    dataframe(psudoDF[['TCDB_CLG', 'TCDB_PSG']])
    psudoDF['newTCDB_PSG']=rdcCLG(psudoDF['TCDB_PSG'])
    psudoDF['newTCDB_CLG']=rdcCLG(psudoDF['TCDB_CLG'])
    rightPane.dataframe(psudoDF[['newTCDB_CLG', 'newTCDB_PSG']])
    #for pgItm in pgroup2:
    #  pgItm=pgItm.strip()
    #  psdPG=psdPG.map(items=pgItm)
    #df['col_3'] = df.apply(lambda x: f(x.col_1, x.col_2), axis=1)
    #pgroup2=map(lambda x:x.strip(), pgroup2)
    #print('psdPG', psdPG)
    #df.apply(lambda x: [1, 2], axis=1, result_type='expand')
    #strpFnctn=map(lambda x:psudoDF['PBC_PGROUP2']==x.strip(), pgroup2)
    fullTAG='|'.join(pgroup2)+str( len(rsltDF))
    rightPane.info(fullTAG)
    #rightPane.text(len(psudoDF[psudoDF['PBC_PGROUP2']==pgroup2]))
    '''
