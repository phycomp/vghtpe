from dbMnpl.strmltPGconn import runQuery
from streamlit import dataframe, write as stWrite
def queryTCDB():
  fullQuery=''''select "PBAB_PDESC", "PBAS_PLSTVDT", "PBAS_PMEDSTAT", "PBC_PGROUP1", "PBC_TFLAG", "PBC_TDATE", "PBC_NFLAG", "PBC_NDATE", "PBC_MFLAG", "PBC_MDATE", "PBC_DFSDATE", "PBC_PB3MDATE", "PBC_PB3TDATE", "TCDB_DOFC", "TCDB_CISTCSER", "TCDB_DATATYPE", "TCDB_PHISTNUM", "TCDB_SEX", "TCDB_DISAGE", "TCDB_PRIST", "TCDB_HISTGY", "TCDB_PSG", "TCDB_CLG", "TCDB_PSD", "TCDB_CLT", "TCDB_CLN", "TCDB_CLM", "TCDB_VOTHSTG", "TCDB_COTHSTG", "TCDB_DOID", "TCDB_DLCOD", "TCDB_COAOD", "TCDB_VITSS" from "VGHLNXTS"."CISTCRM" limit 10;'''
  qryTCDB=runQuery(fullQuery, db='bdprod')
  dataframe(qryTCDB)
__all__=['queryTCDB']
