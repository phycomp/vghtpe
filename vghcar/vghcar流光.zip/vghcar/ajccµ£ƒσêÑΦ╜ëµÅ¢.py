#!/usr/bin/env python
# coding: utf-8

# In[178]:


from pandas import read_csv
AJCC=read_csv('AJCC7/AJCC7.csv')
gndrAJCC=read_csv('AJCC7/AJCC7_Gender.csv')
allCncr=read_csv('newAllCancer2021.csv',  encoding='big5')#AllCancer2021-09-07.csv', encoding='big5')#newAllCancer2021
#anthrCncr=read_csv('newAllCancer2021.csv',  encoding='big5')


# In[3]:


from pandas import read_csv
dfEye=read_csv('/tmp/眼科SOAP.csv')


# In[221]:


from re import search
from pandas import Series, NA, DataFrame, concat

def rtrvCncr(row):
    rowNdx, tcdbGndr, tcdbPRIST, icdO3M=row.name, row[104], row[113], row[115]    #TCDB_HISTGY
    mainO3T, trailO3T=tcdbPRIST[:2], tcdbPRIST[3]
    icdO3T=f'{mainO3T}.{trailO3T}'
    fltrAJCC=AJCC[AJCC.O3T.apply(lambda vl:(not search('C7[012]', mainO3T) and vl =='LymphomaNotBrain') or vl!='LymphomaNotBrain')] #"C70", "C71", "C72"
    rsltAJCC=fltrAJCC.query(f'O3MBegin<={icdO3M} & O3MEnd>={icdO3M}')
    if len(rsltAJCC)==1:
        ajccID=rsltAJCC.ChapterId.values[0]
        ajccTitle=rsltAJCC.ChapterTitle.values[0]
        ajccSchmID=rsltAJCC.SchemaId.values[0]
        ajccSchmTitle=rsltAJCC.SchemaName.values[0]
        allCncr['ajccID'][rowNdx]=f"{ajccID}"#Series(data=f"{ajccID}", index=[rowNdx])
        allCncr['ajccTitle'][rowNdx]=f"{ajccTitle}"#Series(data=f"{ajccTitle}", index=[rowNdx])
        allCncr['ajccSchmID'][rowNdx]=f"{ajccSchmID}"#Series(data=f"{ajccSchmID}", index=[rowNdx])
        allCncr['ajccSchmTitle'][rowNdx]=f"{ajccSchmTitle}"#Series(data=f"{ajccSchmTitle}", index=[rowNdx])
        #print('rowNdx',allCncr['ajccTitle'][rowNdx])
        #print('rsltAJCC existed', rowNdx)
        #print('rsltAJCC existed', rowNdx, ajccID, ajccTitle, ajccSchmID, ajccSchmTitle)
        '''
        return ajccID, ajccTitle, ajccSchmID, ajccSchmTitle
        try:
            #allCncr.insert(lastClmn, 'ajccID', Series(ajccID, index=[rowNdx]))
            allCncr['ajccID']=Series(data=ajccID, index=[rowNdx])
        except:
            allCncr.insert(lastClmn, 'ajccID', '')
            allCncr.ajccID[0]=ajccID
        #print('AJCC', ajccID)
        #print('rsltAJCC', '|'.join(map(lambda x:str(len(x)), [ajccID, ajccTitle, ajccSchmID, ajccSchmTitle])))
        '''
    else:
        if tcdbGndr==2:
            rsltGndrAJCC=gndrAJCC.query(f'ChapterId==37 and O3T=="{icdO3T}" and O3MBegin<={icdO3M} and O3MEnd>={icdO3M}')
        else:
            rsltGndrAJCC=gndrAJCC.query(f'ChapterId==28 and O3T=="{icdO3T}" and O3MBegin<={icdO3M} and O3MEnd>={icdO3M}')
            #rsltGndrAJCC=gndrAJCC.apply(lambda vl:True if vl.ChapterId=='28' and vl.O3T==icdO3M and vl.O3MBegin<=icdO3M<=vl.O3MEnd')
        #allCncr.ajccID=rsltGndrAJCC.ChapterId
        #allCncr.ajccTitle=rsltGndrAJCC.ChapterTitle
        #allCncr.ajccSchmID=rsltGndrAJCC.SchemaId
        #allCncr.ajccSchmTitle=rsltGndrAJCC.SchemaName
        if len(rsltGndrAJCC)==1:
            ajccID=rsltGndrAJCC.ChapterId.values[0]
            ajccTitle=rsltGndrAJCC.ChapterTitle.values[0]
            ajccSchmID=rsltGndrAJCC.SchemaId.values[0]
            ajccSchmTitle=rsltGndrAJCC.SchemaName.values[0]
            allCncr['ajccID'][rowNdx]=f"{ajccID}"#Series(data=f"{ajccID}", index=[rowNdx])
            allCncr['ajccTitle'][rowNdx]=f"{ajccTitle}"#Series(data=f"{ajccTitle}", index=[rowNdx])
            allCncr['ajccSchmID'][rowNdx]=f"{ajccSchmID}"#Series(data=f"{ajccSchmID}", index=[rowNdx])
            allCncr['ajccSchmTitle'][rowNdx]=f"{ajccSchmTitle}"#Series(data=f"{ajccSchmTitle}", index=[rowNdx])
            print('rsltGndrAJCC existed', rowNdx, ajccID, ajccTitle, ajccSchmID, ajccSchmTitle)
            '''
            try:
                #allCncr.insert(lastClmn, 'ajccID', Series(ajccID, index=[rowNdx]))
                allCncr['ajccID']=Series(data=ajccID, index=[rowNdx])
            except:
                #allCncr.insert(lastClmn, 'ajccID', '')
                allCncr['ajccID']=Series(data=ajccID, index=[rowNdx])
                allCncr.ajccID[0]=ajccID
            return ajccID, ajccTitle, ajccSchmID, ajccSchmTitle
            #print('gndrAJCC', ajccID)
            #print('genderAJCC', ajccID, ajccTitle, ajccSchmID, ajccSchmTitle)
            #print('genderAJCC', '|'.join(map(lambda x:str(len(x)), [ajccID, ajccTitle, ajccSchmID, ajccSchmTitle])))
            '''
        else:
            #allCncr.insert(0, 'ajccID', None)
            allCncr['ajccID'][rowNdx]='False'#Series(data=False, index=[rowNdx])
            allCncr['ajccTitle'][rowNdx]='False'#Series(data=False, index=[rowNdx])
            allCncr['ajccSchmID'][rowNdx]='False'#Series(data=False, index=[rowNdx])
            allCncr['ajccSchmTitle'][rowNdx]='False'#Series(data=False, index=[rowNdx])
            #print('NA existed')
            '''
            try:
                #allCncr.insert(lastClmn, 'ajccID', Series('', index=[rowNdx]))
                allCncr['ajccID']=Series(data=ajccID, index=[rowNdx])
            except: allCncr.insert(lastClmn, 'ajccID', '')
            return None, None, None, None
            print(len(allCncr.ajccID))
            '''
    #allCncr=concat(allCncr, df)
#del allCncr.ajccID
#df=DataFrame()
anthrCncr.apply(rtrvCncr, axis=1)#, args=(df, allCncr))
allCncr


# In[34]:


for vl in allCncr['ajccID']:
    if vl:print(vl)
#from re import search
#search('C7[012]', 'C72')


# In[67]:


from numpy import nan
allCncr.ajccID[allCncr.ajccID.apply(lambda x:x is not nan)]


# In[258]:


#AJCC.ChapterId.values
#allCncr.query('ajccTitle!=False')#allCncr.ajccTitle[]#=Series(data='dkjkfd', index=[1656])
#df['qieji']=Series(data='qieuiqz', index=[2,])
allCncr['fullStage'][0]='9'


# In[144]:


from numpy import nan
#allCncr['ajccTitle']
allCncr.ajccSchmTitle[allCncr.ajccSchmTitle.apply(lambda x:True if str(x).find('\n')!=-1 else False)]#allCncr.ajccTitle[]#allCncr.ajccTitle[where()]#['ajccTitle'!=allCncr['ajccTitle'].isnull()]#


# In[220]:


#allCncr['ajccTitle' ==allCncr.ajccTitle.isnull().any()]
def rtrvValid(vl):
    if vl: print(vl)
allCncr['ajccSchmTitle'].apply(rtrvValid)#lambda x:'None' if not x else x)#.notnull().values#allCncr.ajccTitle[]


# In[234]:


#from pandas import DataFrame, concat
#df=DataFrame()
#from .mnplSeries import rdcCLG
import mnplSeries
allCncr['CLG_VALUE']=mnplSeries.rdcCLG(allCncr['TCDB_CLG'])
allCncr['PSG_VALUE']=mnplSeries.rdcCLG(allCncr['TCDB_PSG'])


# In[296]:


#df['dkjkfd']=Series(data=[1, 2])
def rtrvStage(row, allCncr):
    rmvTags=['8','B','9','N','-']
    rowNdx, TCDB_CLT, TCDB_CLN, TCDB_CLM, TCDB_CLG, TCDB_PSG, TCDB_PSD, TCDB_COTHSTG, ajccID, CLG_VALUE, PSG_VALUE=row.name, row[126], row[127], row[128], row[129], row[135], row[136], row[141], row[330], row[334], row[335], 
    if TCDB_PSD in ['4', '6']:
        fullStage=TCDB_CLG if CLG_VALUE > PSG_VALUE else TCDB_PSG
    else: 
        fullStage=TCDB_PSG if TCDB_CLG in ['BBB','999','888','OC','-9','NA',''] else TCDB_CLG
    fullStage='' if fullStage in ['BBB','999','888','OC','-9','NA',''] else fullStage
    fullStage=TCDB_COTHSTG if '57' == ajccID and not fullStage else fullStage
    fullStage='' if fullStage in ['0000', '8888', '9999'] else fullStage
    tStage=TCDB_CLT[0] if TCDB_CLT is not nan else TCDB_CLT
    nStage=TCDB_CLN[0] if TCDB_CLN is not nan else TCDB_CLN
    mStage=TCDB_CLM[0] if TCDB_CLM is not nan else TCDB_CLM
    #print('fullStage', fullStage)
    if fullStage and fullStage is not nan:
        firstStage=fullStage[0]
        simpleStage='' if firstStage in rmvTags else firstStage
        stage4C='C' if firstStage in ["4C ", "4C"] else firstStage
        stage4C='' if stage4C in rmvTags else stage4C
        allCncr['fullStage'][rowNdx]=fullStage
        allCncr['simpleStage'][rowNdx]=simpleStage
        allCncr['stage4C'][rowNdx]=stage4C
    if tStage and tStage is not nan:
        tStage='' if tStage in rmvTags else tStage
        allCncr['tStage'][rowNdx]=tStage
    if nStage and nStage is not nan:
        nStage='' if nStage in rmvTags else nStage
        allCncr['nStage'][rowNdx]=nStage
    if mStage and mStage is not nan:
        mStage='' if mStage in rmvTags else mStage
        allCncr['mStage'][rowNdx]=mStage
allCncr['fullStage']=None
allCncr['simpleStage']=None
allCncr['stage4C']=None
allCncr['tStage']=None
allCncr['nStage']=None
allCncr['mStage']=None
allCncr.apply(rtrvStage, axis=1, args=(allCncr,))
stageInfo='''
    rawData <- rawData %>%
        # 3-14 病理分期字根/字首* (TCDB_PSD)
        # 4_Y-首次治療期間或治療後進行的病理分期
        # 6_M&Y-多原發腫瘤併首次治療期間進行之病理分期
        mutate(FullStage = if_else((TCDB_PSD %in% c('4', '6')), if_else((CLG_VALUE > PSG_VALUE), TCDB_CLG, TCDB_PSG), if_else((TCDB_CLG %in% c('BBB','999','888','OC','-9','NA','')), TCDB_PSG, TCDB_CLG))) %>%
        # 不屬於期別的，清空
        mutate(FullStage = if_else(FullStage %in% c('BBB','999','888','OC','-9','NA',''), '', FullStage)) %>%
        # 3-19 其他分期系統期別(臨床分期)* (Lymphoma 才要)
        mutate(FullStage = if_else(('57' == AJCC7_ID & '' == FullStage), TCDB_COTHSTG, FullStage)) %>%
        # 不屬於期別的，清空
        mutate(FullStage = if_else(FullStage %in% c('0000', '8888', '9999'), '', FullStage))

    # 定義癌症期別 Stage I, II, III, IV
    rawData <- rawData %>%
        # 只取第一碼
        mutate(SimpleStage = substr(FullStage, 1, 1)) %>%
        # 不屬於期別的，清空
        mutate(SimpleStage = if_else(SimpleStage %in% c('8','B','9','','N','-'), '', SimpleStage))

    # 定義癌症期別 Stage I, II, III, IV/IVA/IVB, IVC
    rawData <- rawData %>%
        # 4C 獨立，其餘只取第一碼
        mutate(Stage4C = if_else(("4C" == FullStage | "4C " == FullStage), 'C', substr(FullStage,1,1))) %>%
        # 不屬於期別的，清空
        mutate(Stage4C = if_else(Stage4C %in% c('8','B','9','','N','-'), '', Stage4C))

    rawData <- rawData %>%
        # 只取第一碼
        mutate(tStage = substr(TCDB_CLT, 1, 1)) %>%
        # 不屬於期別的，清空
        mutate(tStage = if_else(tStage %in% c('8','B','9','','N','-'), '', tStage))

    rawData <- rawData %>%
        # 只取第一碼
        mutate(nStage = substr(TCDB_CLN, 1, 1)) %>%
        # 不屬於期別的，清空
        mutate(nStage = if_else(nStage %in% c('8','B','9','','N','-'), '', nStage))

    rawData <- rawData %>%
        # 只取第一碼
        mutate(mStage = substr(TCDB_CLM, 1, 1)) %>%
        # 不屬於期別的，清空
        mutate(mStage = if_else(mStage %in% c('8','B','9','','N','-'), '', mStage))
'''


# In[272]:


#allCncr['ajccTitle']!=False[1656]
#llCncr.fullStage[allCncr['fullStage']!='']
#llCncr['simpleStage']
df['kdjkjqipjeirje']=None


# In[295]:


allCncr.TCDB_CLT[allCncr.TCDB_CLT.apply(lambda x:isinstance(x, float))]#.columns.to_list().index('TCDB_CLT')


# In[343]:


allCncr.columns.to_list().index('PBC_MFLAG')


# In[7]:


from re import findall
def rtrvODOS(columns):
    chartid, mrn1, mrn2, sdate, outcome=columns
    for vl in findall('Va:\s(.*?)\n', outcome):print(chartid, mrn1, mrn2, sdate, vl)
dfEye.apply(rtrvODOS, axis=1)


# In[315]:


#isinstance(4.8, float)
search('院外死亡日期[：:](.*)', '院外死亡日期:1922/02/23').group(1)


# In[323]:


from re import search
from pandas import NA
def rtrvSrvvl(row):
    rowNdx, outDie, PBAS_PLSTVDT, PBAS_PMEDSTAT, TCDB_DATATYPE, TCDB_DOID, TCDB_DLCOD, TCDB_VITSS=row.name, row[1], row[2], row[3], row[97], row[112], row[194], row[195]
    startDate, PBC_DFSDATE, PBC_TDATE, PBC_NDATE=TCDB_DOID, row[82], row[84], row[86]
    
    #print('outDie', outDie)
    if outDie is not nan:
        mtch=search('院外死亡日期[：:](.*)', outDie)
        outDie=mtch.group(1) if mtch else None
    endDate=TCDB_DLCOD if TCDB_DLCOD in ['1', '4'] and TCDB_VITSS in ['0','2'] else None
    if not endDate: endDate=outDie
    if not endDate and PBAS_PMEDSTAT==3: endDate=PBAS_PLSTVDT
    if not endDate: endDate=TCDB_DLCOD
    if not endDate and PBAS_PMEDSTAT!=3: endDate=PBAS_PLSTVDT
    allCncr['endDate'][rowNdx]=endDate
    EndDateInVgh = TCDB_DLCOD if TCDB_DLCOD>PBAS_PLSTVDT else PBAS_PLSTVDT
    EndDateInVghThenOutdie = LV_OUTDIE if LV_OUTDIE and EndDateInVgh < LV_OUTDIE else EndDateInVgh
    EndDateInVghThenOutdieThenVgh = PBAS_PLSTVDT if EndDateInVghThenOutdie < PBAS_PLSTVDT else EndDateInVghThenOutdie
    if not EndDateInVghThenOutdieThenVgh: EndDateInVghThenOutdieThenVgh = TCDB_DLCOD
    maxPossibleLiveDate, recurrentDate, tRecurrentDate, nRecurrentDate=HPA_DATE, PBC_DFSDATE, PBC_TDATE, PBC_NDATE #國健署日期
    maxPossibleLiveDate = TCDB_DLCOD if TCDB_DLCOD and TCDB_DLCOD> maxPossibleLiveDate else maxPossibleLiveDate   #癌登的最後日期
    maxPossibleLiveDate = PBAS_PLSTVDT if PBAS_PLSTVDT and PBAS_PLSTVDT>maxPossibleLiveDate else maxPossibleLiveDate #最後就診日
    #maxPossibleLiveDate =  DTA_DTPDATE if DTA_DTPDATE and DTA_DTPDATE> maxPossibleLiveDate else maxPossibleLiveDate #門診記錄日期 
    deathDate = EndDateInVghThenOutdie    #找死亡日期
    recurrentDuration=int(recurrentDate-startDate) if recurrentDate else NA
    if recurrentDuration<0: recurrentDuration=0
    tDuration=int(tRecurrentDate-startDate) if tRecurrentDate else NA
    if tDuration<0: tDuration=0
    nDuration=int(nRecurrentDate-startDate) if nRecurrentDate else NA
    if nDuration<0: nDuration=0
    mDuration=int(mRecurrentDate-startDate) if mRecurrentDate else NA
    if mDuration<0: mDuration=0
    deathDuration = int(deathDate - startDate)
    deathDuration = 0 if deathDuration < 0 else deathDuration
    lrControlDuration = tDuration if tDuration < nDuration else nDuration
    lrControlDuration = int(lrControlDuration)
    lrControlDuration = 0 if lrControlDuration < 0 else lrControlDuration
    LocalControlRateDuration = tDuration if tDuration else deathDuration
    
    LocoregionalControlRateDuration = lrControlDuration if lrControlDuration else deathDuration
    LocoregionalControlRateDuration = LocalControlRateDuration if LocoregionalControlRateDuration > LocalControlRateDuration else LocoregionalControlRateDuration
    LocoregionalControlRateDuration = deathDuration if LocoregionalControlRateDuration else LocoregionalControlRateDuration
    DistantMetastaseControlRateDuration = mDuration if mDuration else deathDuration # DistantMetasis Control rate
    NodalControlRateDuration = nDuration if nDuration else deathDuration #nodal Control Rate
    OverallSurvivalDuration = deathDuration
    
    LocoregionalControlRateDuration = lrControlDuration if lrControlDuration else deathDuration
    LocoregionalControlRateDuration = LocalControlRateDuration if LocoregionalControlRateDuration > LocalControlRateDuration else LocoregionalControlRateDuration
    if LocoregionalControlRateDuration: LocoregionalControlRateDuration = deathDuration #else LocoregionalControlRateDuration
    DistantMetastaseControlRateDuration = mDuration if mDuration else deathDuration # DistantMetasis Control rate
    NodalControlRateDuration = nDuration if nDuration else deathDuration #nodal Control Rate
    DiseaseSpecificSurvivalDuration = deathDuration # Disease-Specific Survival
    ProgressionFreeSurvivalDuration = recurrentDuration if recurrentDuration else deathDuration # Progression Free Survival
    LocalProgressionFreeSurvivalDuration = LocalControlRateDuration # Local Progression Free Survival
    LocoregionalProgressionFreeSurvivalDuration = LocoregionalControlRateDuration # Locoregional Progression Free Survival
    DistantMetastaseFreeSurvivalDuration = DistantMetastaseControlRateDuration # Distant Metastase Free Survival


allCncr['endDate']=None
allCncr.apply(rtrvSrvvl, axis=1)     #args=(allCncr,))
endDateInfo='''
rawData <- rawData %>% mutate(StartDate = dateConversion(TCDB_DOID))
        rawData <- rawData %>% mutate(LV_OUTDIE = gsub("院外死亡日期[：:]", "", PBAB_PDESC))
        mutate(EndDate = if_else(TCDB_DLCOD %in% c('1', '4') & TCDB_VITSS %in% c('0','2'), dateConversion(TCDB_DLCOD), NULL)) %>%
        # 醫師註記院外死亡   (2nd)
        mutate(EndDate = if_else(is.na(EndDate), dateConversion(LV_OUTDIE), EndDate)) %>%
        # 院內註記死亡日期   (3rd) (PMEDSTAT = '3')
        mutate(EndDate = if_else(is.na(EndDate) & 3 == PBAS_PMEDSTAT, dateConversion(PBAS_PLSTVDT), EndDate)) %>%
        # 如果沒有值，放癌登的最後日期，當做 Lost Follow-Up
        mutate(EndDate = if_else(is.na(EndDate), dateConversion(TCDB_DLCOD), EndDate)) %>%
        # 如果還是沒有值，就去看看他有沒有掛其他科
        mutate(EndDate = if_else(is.na(EndDate) & 3 != PBAS_PMEDSTAT, dateConversion(PBAS_PLSTVDT), EndDate))
            rawData <- rawData %>%
        # 院內註記日期
        mutate(EndDateInVgh = if_else(dateConversion(TCDB_DLCOD) > dateConversion(PBAS_PLSTVDT), dateConversion(TCDB_DLCOD), dateConversion(PBAS_PLSTVDT)))
        mutate(EndDateInVghThenOutdie = if_else('' != LV_OUTDIE & EndDateInVghThenOutdie < dateConversion(LV_OUTDIE), dateConversion(LV_OUTDIE), EndDateInVghThenOutdie))
    rawData <- rawData %>% mutate(startDate = dateConversion(TCDB_DOID))
    # 復發日期
    rawData <- rawData %>% mutate(recurrentDate  = dateConversion(PBC_DFSDATE))
    rawData <- rawData %>% mutate(tRecurrentDate = dateConversion(PBC_TDATE))
    rawData <- rawData %>% mutate(nRecurrentDate = dateConversion(PBC_NDATE))
    rawData <- rawData %>% mutate(mRecurrentDate = dateConversion(PBC_MDATE))

'''


# In[324]:


allCncr.endDate


# In[375]:


from miscUtils import vldtDate
def rtrvEvent(row):
    rowNdx, LV_OUTDIE, PBAS_PLSTVDT, PBAS_PMEDSTAT, TCDB_DATATYPE, TCDB_DOID, TCDB_DLCOD, TCDB_VITSS=row.name, row[1], row[2], row[3], row[97], row[112], row[194], row[195]
    TCDB_COAOD, TCDB_PRIST, PBC_TFLAG, PBC_NFLAG, PBC_MFLAG=row[197], row[113], row[83], row[85], row[87]
    #tcdbGndr, icdO3M=row[104], row[115]    #TCDB_HISTGY
    VitalStatus = 0 if LV_OUTDIE else TCDB_VITSS  #院外死亡日 註記死亡
    VitalStatus = 0 if PBAS_PLSTVDT and 3 == PBAS_PMEDSTAT else VitalStatus #院內死亡日 註記死亡
    VitalStatus = 1 if not VitalStatus else VitalStatus # 沒有存活的資料，假設他還活著
    VitalStatusInVgh = 0 if not PBAS_PLSTVDT and 3 == PBAS_PMEDSTAT else 1 # 院內存活狀態
    VitalStatusInVghThenOutdie = 0 if PBAS_PLSTVDT and 3 == PBAS_PMEDSTAT else 1 # 院內註記日期
    VitalStatusInVghThenOutdie = 0 if LV_OUTDIE else VitalStatusInVghThenOutdie # 醫師註記院外死亡
    try:
        if LV_OUTDIE is not nan:
            mtch=search('院外死亡日期[：:](.*)', LV_OUTDIE)
            LV_OUTDIE=mtch.group(1) if mtch else None
            LV_OUTDIE=vldtDate(LV_OUTDIE)
            if LV_OUTDIE < str(PBAS_PLSTVDT):
                VitalStatusInVghThenOutdieThenVgh=0 if PBAS_PLSTVDT and 3==PBAS_PMEDSTAT else 1 # 院內註記日期
    except:
        print('LV_OUTDIE, PBAS_PLSTVDT', LV_OUTDIE, PBAS_PLSTVDT)
    deathByCancer = 1 if TCDB_COAOD==TCDB_PRIST else 0
    deathByOthers = 1  if TCDB_COAOD!= TCDB_PRIST else 0
    deathByOthers = 0  if "0000" == TCDB_COAOD else deathByOthers
    deathByOthers = 0 if "0" == TCDB_COAOD else deathByOthers
    tRecurrence = 1 if PBC_TFLAG in ['1', '2'] else 0
    nRecurrence = 1 if PBC_NFLAG in ['1', '2'] else 0
    mRecurrence = 1 if PBC_MFLAG in ['1', '2'] else 0
    LocalControlRateEvent = 1 if '1' == tRecurrence else 0
    LocoregionalControlRateEvent = 1  if '1' == tRecurrence or '1' == nRecurrence else 0
    DistantMetastaseControlRateEvent = 1  if '1' == mRecurrence else 0
    NodalControlRateEvent = 1 if '1'==nRecurrence else 0

    #OverallSurvivalEvent = 1  if '0' == VitalStatusInVghThenOutdie else 0 #舊的年報的方法 反向就正常了
    DiseaseSpecificSurvivalEvent = 1 if '1' == deathByCancer else 0 
    ProgressionFreeSurvivalEvent = 1 if '1' == deathByCancer or '1' == deathByOthers or '1' == tRecurrence or '1' == nRecurrence or '1' == mRecurrence else 0 
    LocalProgressionFreeSurvivalEvent = 1 if '1' == deathByCancer or '1' == deathByOthers or '1' == tRecurrence else 0 
    LocoregionalProgressionFreeSurvivalEvent = 1 if '1' == deathByCancer or '1' == deathByOthers or '1' == tRecurrence or '1' == nRecurrence else 0 
    DistantMetastaseFreeSurvivalEvent = 1 if '1' == deathByCancer or '1' == deathByOthers or '1' == mRecurrence else 0 
    allCncr["LocalControlRateDuration"][rowNdx]=LocalControlRateDuration
    allCncr["LocalControlRateEvent"][rowNdx]=LocalControlRateEvent
    allCncr["LocoregionalControlRateDuration"][rowNdx]=LocoregionalControlRateDuration
    allCncr["LocoregionalControlRateEvent"][rowNdx]=LocoregionalControlRateEvent
    allCncr["DistantMetastaseControlRateDuration"][rowNdx]=DistantMetastaseControlRateDuration
    allCncr["DistantMetastaseControlRateEvent"][rowNdx]=DistantMetastaseControlRateEvent
    allCncr["NodalControlRateDuration"][rowNdx]=NodalControlRateDuration
    allCncr["NodalControlRateEvent"][rowNdx]=NodalControlRateEvent
    allCncr["OverallSurvivalDuration"][rowNdx]=OverallSurvivalDuration
    allCncr["OverallSurvivalEvent"][rowNdx]=OverallSurvivalEvent
    allCncr["DiseaseSpecificSurvivalDuration"][rowNdx]=DiseaseSpecificSurvivalDuration
    allCncr["DiseaseSpecificSurvivalEvent"][rowNdx]=DiseaseSpecificSurvivalEvent
    allCncr["ProgressionFreeSurvivalDuration"][rowNdx]=ProgressionFreeSurvivalDuration
    allCncr["ProgressionFreeSurvivalEvent"][rowNdx]=ProgressionFreeSurvivalEvent
    allCncr["LocalProgressionFreeSurvivalDuration"][rowNdx]=LocalProgressionFreeSurvivalDuration
    allCncr["LocalProgressionFreeSurvivalEvent"][rowNdx]=LocalProgressionFreeSurvivalEvent
    allCncr["LocoregionalProgressionFreeSurvivalDuration"][rowNdx]=LocoregionalProgressionFreeSurvivalDuration
    allCncr["LocoregionalProgressionFreeSurvivalEvent"][rowNdx]=LocoregionalProgressionFreeSurvivalEvent
    allCncr["DistantMetastaseFreeSurvivalDuration"][rowNdx]=DistantMetastaseFreeSurvivalDuration
    allCncr["DistantMetastaseFreeSurvivalEvent"][rowNdx]=DistantMetastaseFreeSurvivalEvent
    
#allCncr
#allCncr['endDate']=None
allCncr["LocalControlRateDuration"]=None
allCncr["LocalControlRateEvent"]=None
allCncr["LocoregionalControlRateDuration"]=None
allCncr["LocoregionalControlRateEvent"]=None
allCncr["DistantMetastaseControlRateDuration"]=None
allCncr["DistantMetastaseControlRateEvent"]=None
allCncr["NodalControlRateDuration"]=None
allCncr["NodalControlRateEvent"]=None
allCncr["OverallSurvivalDuration"]=None
allCncr["OverallSurvivalEvent"]=None
allCncr["DiseaseSpecificSurvivalDuration"]=None
allCncr["DiseaseSpecificSurvivalEvent"]=None
allCncr["ProgressionFreeSurvivalDuration"]=None
allCncr["ProgressionFreeSurvivalEvent"]=None
allCncr["LocalProgressionFreeSurvivalDuration"]=None
allCncr["LocalProgressionFreeSurvivalEvent"]=None
allCncr["LocoregionalProgressionFreeSurvivalDuration"]=None
allCncr["LocoregionalProgressionFreeSurvivalEvent"]=None
allCncr["DistantMetastaseFreeSurvivalDuration"]=None
allCncr["DistantMetastaseFreeSurvivalEvent"]=None
allCncr.apply(rtrvEvent, axis=1)     #args=(allCncr,))


# In[333]:


TAGs='''
        "LocalControlRateDuration",
        "LocalControlRateEvent",
        "LocoregionalControlRateDuration",
        "LocoregionalControlRateEvent",
        "DistantMetastaseControlRateDuration",
        "DistantMetastaseControlRateEvent",
        "NodalControlRateDuration",
        "NodalControlRateEvent",
        "OverallSurvivalDuration",
        "OverallSurvivalEvent",
        "DiseaseSpecificSurvivalDuration",
        "DiseaseSpecificSurvivalEvent",
        "ProgressionFreeSurvivalDuration",
        "ProgressionFreeSurvivalEvent",
        "LocalProgressionFreeSurvivalDuration",
        "LocalProgressionFreeSurvivalEvent",
        "LocoregionalProgressionFreeSurvivalDuration",
        "LocoregionalProgressionFreeSurvivalEvent",
        "DistantMetastaseFreeSurvivalDuration",
        "DistantMetastaseFreeSurvivalEvent"
'''
TAGinfo=TAGs.split(',')
for tinfo in TAGinfo:
    tinfo=tinfo.replace(' ','').strip('\n')
    print(f"allCncr[{tinfo}]=None")


# In[374]:


#from miscUtils import vldtDate
#smartCar=DataFrame(col=[len(allCncr)])
allCncr.LocalControlRateDuration.notnull().sum()#.any()
#help(DataFrame)


# In[365]:


smartCar


# In[ ]:




