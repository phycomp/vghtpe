from streamlit import session_state, cache as stCache
from re import search
from pathlib import Path
from pandas import read_csv
#from streamlit_pandas_profiling import st_profile_report
#from pandas_profiling import ProfileReport

@stCache(allow_output_mutation=True, hash_funcs={"_thread.RLock": lambda _: None})
def loadData(fname=None): #nrows
    absPath=Path(__file__).parent
    fullCSV=absPath/fname
    try: df=read_csv(fullCSV, dtype='str')   #.read()
    except: df=read_csv(fullCSV, encoding='big5', dtype='str')
    #profile=df.profile_report()
    try: df=df.drop(columns=['UNIQ_UUID'])
    except: pass
    #profile=ProfileReport(df, title="SmartCar Profiling Report", explorative=True)
    #data = pd.read_csv(DATA_URL, nrows=nrows)
    #def lowercase(x): return str(x).lower()
    #data.rename(lowercase, axis='columns', inplace=True)
    #data[DATE_COLUMN] = pd.to_datetime(data[DATE_COLUMN])
    return df#, profile
__all__=['loadData']
