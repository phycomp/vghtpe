def nuvStage(row, ndxPRIST, ndxCLM, ndxCLG, ndxPAN, ndxPAM, ndxPSG, ndxPSD, ndxDOMSUPS, ndxSPPSTF):
    rowNdx, tcdbPRIST, tcdbCLM, tcdbCLG=row.name, row[ndxPRIST], row[ndxCLM], row[ndxCLG]
    tcdbPAN, tcdbPAM, tcdbPSG=row[ndxPAN], row[ndxPAM], row[ndxPSG]
    tcdbPSD, tcdbDOMSUPS, tcdbSPPSTF=row[ndxPSD], row[ndxDOMSUPS], row[ndxSPPSTF]
    if tcdbPSD in ['4', '6']:
      if tcdbCLG in ['888','BBB']: FullStage=tcdbPSG
      elif tcdbSPPSTF=='00' and tcdbCLM[0]=='0' and tcdbPAM[0]=='1' and tcdbPSG[0]=='4': FullStage=tcdbPSG
      else: FullStage=tcdbCLG
    elif (tcdbSPPSTF and tcdbDOMSUPS not in ['','00000000','99999999']) and (tcdbSPPSTF>='20' and tcdbSPPSTF<='99' and not (tcdbSPPSTF in ['21','22','23','25'] and tcdbPRIST=='C619') or (tcdbPRIST=='C220' and tcdbSPPSTF=='13')):
        if tcdbPAN in ['X','0','99'] and tcdbPSD == '999': FullStage=tcdbCLG    #not tcdbPSD and 
        elif tcdbPSD in ['888','BBB']: FullStage=tcdbCLG
        else: FullStage=tcdbPSG
    else: FullStage=tcdbCLG
    return FullStage
