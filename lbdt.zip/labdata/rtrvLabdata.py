from datetime import datetime
for line in fin:
	cols=line.split('\x06')
	ORBGNDT=datetime.strptime(cols[1], '%Y-%m-%d') 
