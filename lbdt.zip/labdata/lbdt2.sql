\copy (select trim(O."ORHISTNO"), trim(O."ORDSEQCN"), trim(O."ORREQNO"), O."ORTMSTMP", trim(R."RSRTSYM"), trim(R."RSPFKEY"), trim(R."RSVALUE"), R."RSTMSTMP", trim(PF."PFNATNA"), trim(PF."PFNATNAC"), trim(PF."PFUNIT1"), trim(PF."PFPROCED"), trim(PF."PFNHICD"), trim(PR."PFRSYMBL"), trim(PR."PFRSINIT"), trim(PR."PFRSTTL"), trim(PR."PFRSTTLC"), trim(PR."PFRSUNIT"), trim(PR."PFREFER") FROM "RESULT" R
LEFT JOIN "ORDER3" O on O."ORHISTNO"=R."RSHISTNO" AND O."ORDSEQCN"=R."RSSEQCN" AND O."ORREQNO"=R."RSREQNO" and O."ORTMSTMP"<R."RSTMSTMP" 
LEFT JOIN  "PFRSLT" PR on R."RSPFKEY"=PR."PFKEY" and R."RSRTSYM"=PR."PFRSYMBL" 
LEFT JOIN  "PFILE" PF on  R."RSPFKEY"=PF."PFKEY"
where PR."PFKEY"=PF."PFKEY" AND O."ORSTATUS" >= '64' AND O."ORSTATUS" <='68') to /mnt/isilon/order3LBDT.tsv with(format csv, delimiter E'\x06');
