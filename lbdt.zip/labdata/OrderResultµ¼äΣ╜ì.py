OrderResult={}
fin=open('OrderResult')
for line in fin:
    k, v=line.strip('\n').split('\t')
    OrderResult[k]=v
cat /tmp/headerLABDATA.csv
labdata=open('/tmp/headerLABDATA.csv').readline()
cols=labdata.strip('\n').split('\t')
for col in cols:
    chn=OrderResult.get(col)
    if chn: print(col, chn)
    else: print('no chn', col)
